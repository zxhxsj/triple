var r = require('express').Router();
const db = require('../app/Database');
const Middleware = require('../app/Middleware');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const Chat = require('../app/Chat');

r.post('/sendMessage', Middleware.auth, Middleware.deposit, Chat.createMessage);
r.post('/get', async(req, res) => {
    return res.json(await Chat.getList());
});
r.post('/ban', Middleware.moder, Chat.banUser);
r.post('/delete', Middleware.moder, Chat.deleteMessage);

module.exports = r;