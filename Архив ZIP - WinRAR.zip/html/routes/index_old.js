var r = require('express').Router();
const db = require('../app/Database');
const Roulette = require('../app/Roulette');
const Middleware = require('../app/Middleware');
const Redis = require('redis').createClient();
const Chat = require('../app/Chat');
const Url = require('url');
const Crypto = require('crypto');
const DateFormat = require('dateformat');
const Request = require('requestify');
const Admin = require('../app/Admin');
const Edge = require('express-edge');

r.get('/', async function(req, res) {
    if(!req.isAuthenticated() && typeof req.query.r != 'undefined') return res.redirect('/login?r=' + req.query.r);

    if(isNaN(parseInt(req.query.room))) req.query.room = undefined;

    if(req.query.room == undefined)
    {
        roomID = (req.cookies.room != undefined) ? req.cookies.room : false;
        // roomID = 1;
        if(roomID) 
        {
            room = await db.Rooms.findById(roomID);
            if(!room) roomID = false;
        }
        if(!roomID)
        {
            room = await db.Rooms.find({order:[['id', 'desc']]});
            roomID = room.id;
        }
        return res.redirect('/?room=' + roomID);
    }
    
    room = await db.Rooms.find(({where:{'id' : req.query.room}}));
    if(!room) return res.redirect('/');

    res.cookie('room', req.query.room, {maxAge : 9999999, httpOnly : false});

    // Index render
    return res.render('pages/index', {
        user : req.user,
        rcontents : await Roulette.getRoomsContent(),
        game : await Roulette.lastGame(req.query.room),
        myInfo : (req.isAuthenticated()) ? await Roulette.getMyInfo(req.query.room, req.user.id) : {chance : 0, bet : 0},
        room : room,
        timer : Roulette.getTimer(room.timer),
        info : await Roulette.globalInfo(),
        lastWinner : await Roulette.getLastWinner(req.query.room),
        mates : (req.isAuthenticated()) ? await Roulette.getMyMates(req.user.id, req.query.room) : [],
        title : await Roulette.getTitle(req.query.room),
        min_bet : Roulette.numberFormat(room.min_bet),
        max_bet : Roulette.numberFormat(room.max_bet),
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/fair/:id', async(req, res) => {
    var game = await db.Games.findById(req.params.id);
    if(!game || game.randomOrg === null) return res.redirect('/');

    return res.render('pages/fair', {
        result : JSON.stringify(game.randomOrg.result.random),
        signature : game.randomOrg.result.signature,
        status : game.status
    });
});

r.get('/fairgame/:game', async(req, res) => {
    game = await db.Games.findById(parseInt(req.params.game));
    if(!game) return res.redirect('/');

    return res.json({
        result : game.randomOrg.result.random,
        signature : game.randomOrg.result.signature
    });
});

r.post('/sendMateNotify', Middleware.auth, Roulette.mateNotify);
r.post('/acceptMateNotify', Middleware.auth, Roulette.acceptMateNotify);
r.post('/sendMoney', Middleware.auth, Roulette.sendMoney);

r.post('/getInfo', async(req, res) => {
    room = await db.Rooms.find({where:{id : req.body.room}});
    if(!room) return res.json({
        success : false,
        msg : 'Не удалось найти комнату #' + req.body.room
    });

    game = await Roulette.lastGame(room.id);
    if(!game) return res.json({
        success : false,
        msg : 'Не удалось найти последнюю игру в комнате #' + room.id
    });

    bets = await Roulette.getBets(room.id);

    return res.json({
        success : true,
        room : {
            timer : Roulette.getTimer(room.timer),
            name : room.name
        },
        game : {
            price : Roulette.numberFormat(game.price),
            id : game.id
        },
        bets : bets
    });
});

r.get('/balance', Middleware.auth, async(req, res) => {
    var deps = await db.Deposit.findAll({
        where : {
            user_id : req.user.id
        },
        order : [['id', 'desc']],
        limit : 15
    });

    var list = [];

    for(var i in deps)
    {
        let status = deps[i].status;
        if((new Date(deps[i].updatedAt).getTime() < (new Date().getTime()-10*60*1000)) && deps[i].status == 0) 
        {
            status = 2;
            deps[i].status = 2;
            await deps[i].save();
        }
        
        
        list.push({
            order_id : deps[i].order_id,
            amount : Roulette.numberFormat(deps[i].amount),
            date : await Admin.getDatev2(new Date(deps[i].updatedAt).getTime()),
            status : status
        });
    }

    return res.render('pages/balance', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        title : '- Пополнение счета',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg(),
        deps : Roulette.sort(list, 'order_id', 'desc')
    });
});

r.get('/withdrawal', Middleware.auth, async(req, res) => {
    return res.render('pages/withdrawal', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        withdraws : await db.Withdraw.findAll({
            where : {
                user_id : req.user.id
            },
            order : [['id', 'DESC']],
            limit : 10
        }),
        title : '- Вывод средств',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/send', Middleware.auth, async(req, res) => {
    var sends = await db.Send.findAll({
        where : {
            user_id : req.user.id
        },
        limit : 15,
        order : [['id', 'desc']]
    });

    var history = [];
    for(var i in sends) history.push({
        id : sends[i].id,
        to : sends[i].to,
        value : Roulette.numberFormat(sends[i].value),
        date : sends[i].date
    });

    return res.render('pages/send', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        history : history,
        title : '- Перевод средств',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/news', async(req, res) => {
    return res.render('pages/news',{
        user : req.user,
        info : await Roulette.globalInfo(),
        title : 'Новости',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/myhistory', Middleware.auth, async function(req, res) {
    return res.render('pages/myhistory', {
        user : req.user,
        info : await Roulette.globalInfo(),
        res : await Roulette.myHistory(req.user.id),
        rcontents : await Roulette.getRoomsContent(),
        title : '- История ставок',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    }); 
});

r.get('/top', async(req, res) => {
    return res.render('pages/top', {
        user : req.user,
        info : await Roulette.globalInfo(),
        users : await Roulette.getTop(false),
        winners : await Roulette.getTopWinners(),
        rcontents : await Roulette.getRoomsContent(),
        title : '- Топ игроков',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/deposit', Middleware.auth, async(req, res) => {

    cfg = await db.cfg();

    lastOrder = await db.Deposit.find({
        order : [['id', 'desc']]
    });

    if(lastOrder) lastOrder = lastOrder.order_id+1; else lastOrder = 1;

    pay = {
        secret : Crypto.createHash('md5').update(cfg.fk_id+':'+req.query.amount+':'+cfg.fk_secret+':' + lastOrder).digest('hex'),
        merchant_id : cfg.fk_id,
        order_id : lastOrder,
        amount : req.query.amount,
        user_id : req.user.id
    }

    await db.Deposit.create(pay);

    return res.redirect('https://www.free-kassa.ru/merchant/cash.php?m=' + pay.merchant_id + '&oa=' + pay.amount + '&o=' + pay.order_id + '&s=' + pay.secret);
});

r.post('/deposit/fail', async(req, res) => {
    if(req.headers.origin != 'https://www.free-kassa.ru') return;
    return res.json(req.body);
});

r.post('/deposit/success', async(req, res) => {
    if(req.headers.origin != 'https://www.free-kassa.ru') return res.send('Ошибка при проверке, ответ пришел не от FreeKassa');

    merch = await db.Deposit.find({
        where : {
            order_id : req.body['MERCHANT_ORDER_ID']
        }
    });

    if(!merch) return res.send('Не удалось найти заказ #' + req.body['MERCHANT_ORDER_ID']);

    if(merch.status == 1) return res.redirect('/');

    user = await db.Users.findById(merch.user_id);
    if(!user) return res.send('Не удалось найти пользователь!');

    user.balance = parseFloat((user.balance+merch.amount).toFixed(2));

    await user.save();

    merch.status = 1;
    await merch.save();

    return res.redirect('/');
});

r.get('/sendWithdraw', Middleware.auth, async(req, res) => {
    amount = parseFloat(req.query.amount);
    if(!amount || isNaN(amount)) return res.redirect('/withdrawal');

    user = await db.Users.findById(req.user.id);
    if(!user) return res.redirect('/withdrawal');

    if(amount < 0) return res.send('Сумма вывода введена неверно!');

    if(user.balance < amount) return res.send('Недостаточно баланса!');

    user.balance = parseFloat((user.balance-amount).toFixed(2));
    await user.save();

    await db.Withdraw.create({
        user_id : user.id,
        user : {
            id : user.id,
            username : user.username,
            avatar : user.avatar,
            vk : user.vk_id
        },
        amount : amount,
        wallet : req.query.wallet,
        wallet2 : req.query.wallet2,
        type : req.query.system,
        date : Roulette.getDate()
    });

    return res.redirect('/withdrawal');
});

r.get('/history', async(req, res) => {
    games = await db.Games.findAll({
        where : {
            status : 3
        },
        limit : 15,
        order : [['id', 'DESC']]
    });
    list = [];
    for(var i = 0; i < games.length; i++) if(games[i].randomOrg !== null) list.push({
        id : games[i].id,
        room : games[i].room,
        price : Roulette.numberFormat(games[i].price),
        random : Roulette.numberFormat(games[i].random),
        status : games[i].status,
        secret : games[i].secret,
        randomOrg : games[i].randomOrg,
        winner : games[i].winner,
        winner_id : games[i].winner_id,
        comissionPrice : Roulette.numberFormat(games[i].comissionPrice),
        result : JSON.stringify(games[i].randomOrg.result.random)
    });
    return res.render('pages/history', {
        user : req.user,
        info : await Roulette.globalInfo(),
        games : list,
        rcontents : await Roulette.getRoomsContent(),
        title : '- История игр',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/about', async(req, res) => {
    return res.render('pages/about', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        title : '- Помощь',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.get('/ref', Middleware.auth, async(req, res) => {
    return res.render('pages/ref', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        count : await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }),
        balance : Roulette.numberFormat(req.user.balance),
        rewards : Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })),
        title : '- Партнерская программа',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        })) : false,
        cfg : await db.cfg()
    });
});

r.post('/addBet', Middleware.auth, Middleware.time, async(req, res) => {
    return res.json(await Roulette.createBet(parseInt(req.body.room), req.user.id, req.body.value));
});

r.post('/changeUsername', Middleware.auth, async(req, res) => {
    var user = await db.Users.findById(req.user.id),
        cfg = await db.cfg();

    if(user.balance < cfg.rename_price) return res.json({
        success : false,
        msg : 'Недостаточно баланса!'
    });

    if(typeof req.body.username == 'null' || typeof req.body.username == 'undefined' || req.body.username.length < 1) return res.json({
        success : false,
        msg : 'Вы не ввели новое имя!'
    });

    if(req.body.username.length > 15) return res.json({
        success : false,
        msg : 'Максимальная длина нового имени - 15 символов'
    });

    if(req.body.username.length < 5) return res.json({
        success : false,
        msg : 'Минимальная длина нового имени - 5 символов'
    });

    var needCheck = ['(', ')', '[', ']', '{', '}', '<', '>'];
    for(var i in needCheck) if(req.body.username.indexOf(needCheck[i]) > -1) return res.json({
        success : false,
        msg : 'Ваше новое имя не должно содержать символы префиксов ('+needCheck[i]+')'
    });

    var alreadyUsed = await db.Users.find({
        where : {
            username : req.body.username
        }
    });

    if(alreadyUsed) return res.json({
        success : false,
        msg : 'Это имя уже занято!'
    });

    user.balance = parseFloat((user.balance-cfg.rename_price).toFixed(2));
    user.username = req.body.username;
    await user.save();

    await db.pLog(cfg.rename_price, 'Пользователь #' + user.id + ' сменил имя!', true, Roulette.getDate());

    Roulette.updateBalance(user.id);

    return res.json({
        success : true,
        msg : 'Ваше новое имя - ' + user.username,
        username : user.username
    });
});

module.exports = r;