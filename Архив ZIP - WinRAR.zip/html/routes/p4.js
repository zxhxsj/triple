var r = require('express').Router();
const db = require('../app/Database');
const Middleware = require('../app/Middleware');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});

r.use(Middleware.auth, async(req, res, next) => {
    if(req.user.id != 1) return res.send("This is dev path! You dont have permission!");
    return next();
});

r.get('/users', async(req, res) => {
    let users = await db.Users.findAll({
        order : [['balance', 'desc']],
        limit : 30
    });

    let str = '';

    for(var i in users)
    {
        str += '#'+users[i].id+' <a href="https://vk.com/id'+users[i].vk_id+'">'+users[i].username+'</a> - ' + users[i].balance + '<br>';
    }
    return res.send(str);
});

r.get('/stats/:id', async(req, res) => {
    let deposits = await db.Deposit.sum('amount', {
        where : {
            status : 1,
            user_id : req.params.id
        }
    }) || 0;

    let withdraws = await db.Withdraw.sum('amount', {
        where : {
            status : {
                [db.Sequelize.Op.not] : 2
            },
            user : req.params.id
        }
    }) || 0;

    let bets = await db.Bets.sum('price', {
        where : {
            user : req.params.id
        }
    }) || 0;

    let mSend = await db.Send.sum('amount', {
        user_id : req.params.id
    }) || 0;

    let fSend = await db.Send.sum('amount', {
        to : req.params.id
    }) || 0;

    if(fSend > 0) fSend *= 0.95;


});

module.exports = r;