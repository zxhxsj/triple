const Route = require('express').Router();
const Middleware = require('../app/Middleware');
const db = require('../app/Database');
const ws = require('../app/WebSockets');
const Roulette = require('../app/Roulette');
const DateFormat = require('dateformat');
const Crypto = require('crypto');
const redis = require('redis').createClient({
  path : '../../../../../../var/run/redis/redis.sock'
});

Route.use(Middleware.auth);

// STATUS
// 0 - line
// 1 - result

Route.post('/get', async(req, res) => {
  let game = await db.Fishing.findOne({
    where: {
      user_id: req.user.id,
      status: 0
    }
  });

  return res.json({
    success: (game) ? true : false,
    price: (game) ? game.price : 0,
    id: (game) ? game.id : 0
  });
});


Route.post('/play', async(req, res) => {
  if(req.user.is_admin < 1) return res.json({
    success: false,
    msg: 'Технические работы!'
  });
  // let t = await db.getTransaction();
  try {
    let game = await db.Fishing.findOne({
      where: {
        user_id: req.user.id,
        status: 0
      }
    });
  
    if(game)
    {
      if(req.body.line < 5 || req.body.line > 95 || req.body.fish > 95)
      {
        await db.Fishing.update({
          fish: null,
          result: 0,
          final: (game.price*-1),
          line: req.body.line,
          status: 1
        }, {
          where: {
            id: game.id
          }
        });
        

        req.user.fish_profit += game.price;
        await db.Users.update({
          fish_profit: req.user.fish_profit
        }, {
          where: {
            id: req.user.id
          }
        });
  
        redis.publish('fishing', JSON.stringify({
          game: {
            user: game.user,
            bet: game.price,
            multiplier: 0,
            result: 0 // (game.price*-1)
          }
        }));
        
        if(req.body.line > 95) return res.json({
          success: false,
          msg: 'Рыба сорвалась с удочки(',
          type: 'new_'
        });
        
        if(req.body.line < 5) return res.json({
          success: false,
          msg: 'Перетянули, порвалась леска!',
          type: 'new_'
        }); 
  
        if(req.body.fish > 95) return res.json({
          success: false,
          msg: 'Леска порвалась!',
          type: 'new_'
        });
      }
  
      if(req.body.fish > -95) 
      {
        return res.json({
          success: false,
          msg: 'Ошибка!',
          type: 'new_'
        });
      }
  
  
      let cfg = await db.Config.findOne({
        order: [['id', 'desc']]
      });

      /*
        0.x - 50%
        1.1x - 30%
        2x - 10%
        x - 8%
        50% банка - 2%

      */
      
     let list = [], num = 1;
     while(num <= 100)
     {
       let key = Math.floor(Math.random()*100);
       if(typeof list[key] == 'undefined')
       {
         list[key] = num;
         num++;
       }
     }

     let isWin = (list[Math.floor(Math.random()*list.length)] <= 40) ? true : false,
         multiplier = 0;
     if(isWin)
     {
      let fish = await db.Fish.findOne({
        where: {
          min: {
            [db.Op.gte]: 1
          }
        }
      });

      if(!fish) multiplier = false;

      if(fish)
      {
        multiplier = parseFloat(((Math.random()*(fish.max-fish.min))+fish.min).toFixed(2));
        let profit = await db.Users.sum('fish_profit');
        if((profit*0.3) < (game.price*multiplier)) multiplier = false;
      }
     }

     if(!isWin || !multiplier) multiplier = parseFloat(Math.random().toFixed(2));
     if(multiplier === 1) multiplier -= 0.01;
     if(multiplier === 0) multiplier = parseFloat(Math.random().toFixed(2));

      let fishs = await db.Fish.findAll({
        where: {
          min: {
            [db.Op.lte]: multiplier
          },
          max: {
            [db.Op.gte]: multiplier
          }
        }
      });

      let fish = fishs[Math.floor(Math.random()*fishs.length)] || false;
  
      if(!fish) 
      {
        return res.json({
          success: false,
          msg: 'Ошибка, попробуйте чуть позже!',
          type: 'new_'
        });
      }
  
      fish.multiplier = parseFloat(multiplier.toFixed(2));
  
      let result = game.price*multiplier,
          // final = result; // result-game.price
          final = parseFloat((result-game.price).toFixed(2));
      // if(result < game.price) result = result-game.price;

      
  
      await db.Fishing.update({
        fish: {
          img: fish.img,
          name: fish.name,
          multiplier: multiplier
        },
        result: result,
        final: final,
        line: req.body.line,
        status: 1
      }, {
        where: {
          id: game.id
        }
      });

      if(req.user.rate_date == '' || req.user.rate_date != DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
      {
        req.user.rate_date = DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')
        req.user.rate = 0;
      }

      req.user.rate += result;
      req.user.fish_profit += final*-1;

      
      console.log(req.user.fish_profit);

      await db.Users.update({
        balance: db.Sequelize.literal('"balance"+'+result.toFixed(2)),
        rate: parseFloat(req.user.rate.toFixed(2)),
        rate_date: req.user.rate_date,
        fish_profit: req.user.fish_profit
      }, {
        where: {
          id: req.user.id
        }
      });
  
      await db.pLog(result, 'Рыбалка от игрока ' + req.user.username, true, Roulette.getDate());
  
      Roulette.updateBalance(req.user.id);
  
      redis.publish('fishing', JSON.stringify({
        game: {
          user: game.user,
          bet: game.price,
          multiplier: multiplier,
          result: final
        },
        global: await Roulette.globalInfo()
      }));

      await db.Fishing.destroy({
        where: {
          updatedAt: {
            [db.Op.lt]: DateFormat((new Date().getTime() - (3*24*60*60*1000)), 'yyyy-mm-dd')
          }
        }
      })
  
      // сила натяжения
      return res.json({
        success: true,
        msg: 'Конец игры!',
        result: {
          fish: {
            img: fish.img,
            name: fish.name,
            multiplier: multiplier
          },
          result: result,
          final: final,
          multiplier: multiplier
        },
        line: req.body.line,
        type: 'new'
      });
    }
  
    let amount = parseFloat(parseFloat(req.body.amount).toFixed(2));
  
    if(amount < 1) return res.json({
      success: false,
      msg: 'Минимальная ставка - 1 монета.'
    });
  
    if(amount > req.user.balance) return res.json({
      success: false,
      msg: 'Недостаточно баланса!'
    });
  
  
    game = await db.Fishing.create({
      user_id: req.user.id,
      user: {
        id: req.user.id,
        username: req.user.username,
        avatar: req.user.avatar,
        vk: req.user.vk_id
      },
      fish: {},
      price: amount,
      result: 0,
      final: 0
    });
  
    game = await game.get({plain: true});
  
    await db.Users.update({
      balance: db.Sequelize.literal('"balance"-'+amount)
    }, {
      where: {
        id: req.user.id
      }
    });
  
    Roulette.updateBalance(req.user.id);
  
    // await t.commit();

    // новая игра
    return res.json({
      success: true,
      msg: 'Игра началась!',
      type: 'line',
      id: game.id
    });
  } catch(e) {
    console.log(e);
    return res.json({
      success: false,
      msg: 'Ошибка! Попробуйте чуть позже...'
    });
  }
});

Route.get('/', async(req, res) => {
  let history = await db.Fishing.findAll({
    where: {
      status: 1
    },
    order: [['id', 'desc']],
    limit: 10
  });
  return res.render('pages/fishing', {
    user : req.user,
    rcontents : await Roulette.getRoomsContent(),
    rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
        where : {
            winner_id : req.user.id,
            updatedAt : {
                [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
            }
        }
    }) || 0)+await db.Fishing.sum('result', {
      where: {
        user_id: req.user.id,
        updatedAt : {
          [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
      }
      }
    })) : false,
    cfg : await db.cfg(),
    count : (req.isAuthenticated()) ? await db.Users.findAll({
        where : {
            ref_id : req.user.id
        }
    }) : 0,
    rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
        where : {
            user_id : req.user.id
        }
    })) : 0,
    title : '- 🐟 Рыбалка (Beta)',
    refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
    info : await Roulette.globalInfo(),
    history: history
  });
});

module.exports = Route;