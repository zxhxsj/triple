var r = require('express').Router();
const db = require('../app/Database');
const Roulette = require('../app/Roulette');
const Middleware = require('../app/Middleware');
const Redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const Chat = require('../app/Chat');
const Url = require('url');
const Crypto = require('crypto');
const DateFormat = require('dateformat');
const Request = require('requestify');
const Admin = require('../app/Admin');
const Edge = require('express-edge');
const FreeKassa = require('../app/FreeKassa');
const Promo = require('../app/Promo');
const Mates = require('../app/Mates');
const Send = require('../app/Send');

r.post('/registerPromo', Middleware.auth, Promo.register);
r.post('/activePromo', Middleware.auth, Promo.activate);
r.post('/sendMateNotify', Middleware.auth, Mates.sendNotify);
r.post('/acceptMateNotify', Middleware.auth, Mates.acceptNotify);
r.post('/sendMoney', Middleware.auth, Send.sendMoney);

r.use(async function(req, res, next) {
    if(req.path == '/getInfo') return next();
    if(req.method != 'POST') return next();
    if(!req.isAuthenticated()) return res.json({
        success : false,
        msg : 'Вам необходимо авторизироваться!'
    });

    let cfg = await db.cfg();
    if(cfg.technical && req.user.is_admin < 1) return res.json({
        success : false,
        msg : 'На сайте ведутся технические работы!'
    });

    return next();
});

r.get('/fishing_tst', Middleware.auth, async(req, res) => {
    if(req.user.is_admin < 1) return res.send('Режим находиться в разработке!');
    return res.render('pages/fishing', {
        user : req.user,
        rcontents : await Roulette.getRoomsContent(),
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        cfg : await db.cfg(),
        count : (req.isAuthenticated()) ? await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }) : 0,
        rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })) : 0,
        title : '- 🐟 Fishing (Beta)',
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        info : await Roulette.globalInfo(),
    });
});

async function roomsInit() {
    var rooms = await db.Rooms.findAll();
    for(var i in rooms) 
        if(rooms[i].short_url !== null) 
            r.get(rooms[i].short_url, async(req, res) => {
                var room = await db.Rooms.find({
                    where : {
                        short_url : req.path
                    }
                });

                if(!room) return res.redirect('/');

                res.cookie('room', room.short_url, {maxAge : 9999999, httpOnly : false});

                return res.render('pages/jackpot', {
                    user : req.user,
                    rcontents : await Roulette.getRoomsContent(),
                    game : await Roulette.lastGame(room.id),
                    myInfo : (req.isAuthenticated()) ? await Roulette.getMyInfo(room.id, req.user.id) : {chance : 0, bet : 0},
                    room : room,
                    timer : Roulette.getTimer(room.timer),
                    info : await Roulette.globalInfo(),
                    lastWinner : await Roulette.getLastWinner(room.id),
                    mates : (req.isAuthenticated()) ? await Roulette.getMyMates(req.user.id, room.id) : [],
                    title : await Roulette.getTitle(room.id),
                    min_bet : Roulette.numberFormat(room.min_bet),
                    max_bet : Roulette.numberFormat(room.max_bet),
                    rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
                        where : {
                            winner_id : req.user.id,
                            updatedAt : {
                                [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                            }
                        }
                    }) || 0)+await db.Fishing.sum('result', {
                      where: {
                        user_id: req.user.id,
                        updatedAt : {
                          [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                      }
                      }
                    })) : false,
                    cfg : await db.cfg(),
                    count : (req.isAuthenticated()) ? await db.Users.findAll({
                        where : {
                            ref_id : req.user.id
                        }
                    }) : 0,
                    rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
                        where : {
                            user_id : req.user.id
                        }
                    })) : 0,
                    refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
                });
            });
}
roomsInit();

r.get('/rules', async(req, res) => {
    return res.render('pages/rules', {
        user : req.user,
        rcontents : await Roulette.getRoomsContent(),
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        cfg : await db.cfg(),
        count : (req.isAuthenticated()) ? await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }) : 0,
        rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })) : 0,
        title : '- Правила',
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        info : await Roulette.globalInfo(),
    })
});



r.get('/', async function(req, res) {
    if(!req.isAuthenticated() && typeof req.query.r != 'undefined') return res.redirect('/login?r=' + req.query.r);

    if(typeof req.cookies.room != 'undefined')
    {
        let room = await db.Rooms.find({
            where : {
                short_url : req.cookies.room
            }
        });

        if(room) return res.redirect(room.short_url);
    }
    let room = await db.Rooms.find();
    if(!room) return res.send('Комната не найдена! Добавьте комнату!');
    return res.redirect(room.short_url);
});

r.get('/fair/:id', async(req, res) => {
    var game = await db.Games.findById(req.params.id);
    if(!game || game.randomOrg === null) return res.redirect('/');

    return res.render('pages/fair', {
        result : JSON.stringify(game.randomOrg.result.random),
        signature : game.randomOrg.result.signature,
        status : game.status
    });
});

r.post('/getInfo', async(req, res) => {
    room = await db.Rooms.find({where:{id : req.body.room}});
    if(!room) return res.json({
        success : false,
        msg : 'Не удалось найти комнату #' + req.body.room
    });

    game = await Roulette.lastGame(room.id);
    if(!game) return res.json({
        success : false,
        msg : 'Не удалось найти последнюю игру в комнате #' + room.id
    });

    bets = await Roulette.getBets(room.id);

    return res.json({
        success : true,
        room : {
            timer : Roulette.getTimer(room.timer),
            name : room.name
        },
        game : {
            price : Roulette.numberFormat(game.price),
            id : game.id
        },
        bets : bets
    });
});

// r.get('/balance', Middleware.auth, async(req, res) => {
//     var deps = await db.Deposit.findAll({
//         where : {
//             user_id : req.user.id
//         },
//         order : [['id', 'desc']],
//         limit : 15
//     });

//     var list = [];

//     for(var i in deps)
//     {
//         let status = deps[i].status;
        
//         list.push({
//             order_id : deps[i].order_id,
//             amount : Roulette.numberFormat(deps[i].amount),
//             date : await Admin.getDatev2(new Date(deps[i].updatedAt).getTime()),
//             status : status
//         });
//     }

//     return res.render('pages/balance', {
//         user : req.user,
//         info : await Roulette.globalInfo(),
//         rcontents : await Roulette.getRoomsContent(),
//         title : '- Пополнение счета',
//         rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
//             where : {
//                 winner_id : req.user.id,
//                 updatedAt : {
//                     [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
//                 }
//             }
//         }) || 0) : false,
//         cfg : await db.cfg(),
//         refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
//         deps : Roulette.sort(list, 'order_id', 'desc')
//     });
// });

// r.get('/withdrawal', Middleware.auth, async(req, res) => {
//     return res.render('pages/withdrawal', {
//         user : req.user,
//         info : await Roulette.globalInfo(),
//         rcontents : await Roulette.getRoomsContent(),
//         withdraws : await db.Withdraw.findAll({
//             where : {
//                 user_id : req.user.id
//             },
//             order : [['id', 'DESC']],
//             limit : 10
//         }),
//         title : '- Вывод средств',
//         rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
//             where : {
//                 winner_id : req.user.id,
//                 updatedAt : {
//                     [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
//                 }
//             }
//         }) || 0) : false,
//         refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
//         cfg : await db.cfg()
//     });
// });

// r.get('/send', Middleware.auth, async(req, res) => {
//     var sends = await db.Send.findAll({
//         where : {
//             user_id : req.user.id
//         },
//         limit : 15,
//         order : [['id', 'desc']]
//     });

//     var history = [];
//     for(var i in sends) history.push({
//         id : sends[i].id,
//         to : sends[i].to,
//         value : Roulette.numberFormat(sends[i].value),
//         date : sends[i].date
//     });

//     return res.render('pages/send', {
//         user : req.user,
//         info : await Roulette.globalInfo(),
//         rcontents : await Roulette.getRoomsContent(),
//         history : history,
//         title : '- Перевод средств',
//         rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
//             where : {
//                 winner_id : req.user.id,
//                 updatedAt : {
//                     [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
//                 }
//             }
//         }) || 0) : false,
//         refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
//         cfg : await db.cfg()
//     });
// });

r.get('/clans', async(req, res) => {
    return res.render('pages/clans',{
        user : req.user,
        info : await Roulette.globalInfo(),
        title : '- Кланы',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        cfg : await db.cfg(),
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        rcontents : await Roulette.getRoomsContent()
    });
});

// r.get('/myhistory', Middleware.auth, async function(req, res) {
//     return res.render('pages/myhistory', {
//         user : req.user,
//         info : await Roulette.globalInfo(),
//         res : await Roulette.myHistory(req.user.id),
//         rcontents : await Roulette.getRoomsContent(),
//         title : '- История ставок',
//         rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
//             where : {
//                 winner_id : req.user.id,
//                 updatedAt : {
//                     [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
//                 }
//             }
//         }) || 0) : false,
//         refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
//         cfg : await db.cfg()
//     }); 
// });

r.get('/top', async(req, res) => {
    return res.render('pages/top', {
        user : req.user,
        info : await Roulette.globalInfo(),
        users : await Roulette.getTop(false),
        winners : await Roulette.getTopWinners(),
        rcontents : await Roulette.getRoomsContent(),
        title : '- Топ игроков',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        cfg : await db.cfg(),
        count : await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }),
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        rewards : Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })),
    });
});

r.get('/deposit', Middleware.auth, async(req, res) => {

    // if(req.user.is_admin < 1) return res.send('Пополнения временно недоступны!');

    let deps = await db.Deposit.findAll({
        where : {
            user_id : req.user.id,
            status : 0
        }
    });
    let count = 0;

    for(var i in deps)
    {
        let time = new Date(deps[i].createdAt).getTime()+(5*60*1000);
        if(time < new Date().getTime())
        {
            // 5 минут прошло
            await db.Deposit.update({
                status : 2
            }, {
                where : {
                    id : deps[i].id
                }
            });
        } else {
            count++;
        }
    }

    if(count >= 3) return res.send('Дождитесь, пока ваши заявки на пополнение отменятся или оплатятся!');

    cfg = await db.cfg();

    lastOrder = await db.Deposit.find({
        order : [['id', 'desc']]
    });

    if(lastOrder) lastOrder = lastOrder.order_id+1; else lastOrder = 1;

    pay = {
        secret : Crypto.createHash('md5').update(cfg.fk_id+':'+req.query.amount+':'+cfg.fk_secret+':' + lastOrder).digest('hex'),
        merchant_id : cfg.fk_id,
        order_id : lastOrder,
        amount : req.query.amount,
        user_id : req.user.id
    }

    await db.Deposit.create(pay);

    if(isNaN(req.user.balance)) return res.send('Неверный баланс!');

    return res.redirect('https://www.free-kassa.ru/merchant/cash.php?m=' + pay.merchant_id + '&oa=' + pay.amount + '&o=' + pay.order_id + '&s=' + pay.secret);
});

r.post('/deposit/fail', async(req, res) => {
    if(req.headers.origin != 'https://www.free-kassa.ru') return;
    return res.json(req.body);
});

r.post('/deposit/success', async(req, res) => {
    // console.log(req.headers);
    // if(req.headers.origin != 'https://www.free-kassa.ru' && req.headers.origin != 'http://www.free-kassa.ru' && req.headers.origin != 'http://free-kassa.ru' && req.headers.origin != 'https://free-kassa.ru') return res.send('Ошибка при проверке, ответ пришел не от FreeKassa');

    // merch = await db.Deposit.find({
    //     where : {
    //         order_id : req.body['MERCHANT_ORDER_ID']
    //     }
    // });

    // if(!merch) return res.send('Не удалось найти заказ #' + req.body['MERCHANT_ORDER_ID']);

    // if(merch.status == 1) return res.redirect('/');

    // user = await db.Users.findById(merch.user_id);
    // if(!user) return res.send('Не удалось найти пользователь!');

    // user.balance = parseFloat((user.balance+merch.amount).toFixed(2));

    // await user.save();

    // merch.status = 1;
    // await merch.save();

    return res.redirect('/');
});

r.get('/deposit/callback', async(req, res) => {
    let list = ['136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '88.198.88.98'],
        agree = false;

    for(var i in list) if(list[i] == req.headers['x-real-ip']) agree = true;
    if(!agree) 
    {
        console.log('Access denied : ' + req.headers['x-real-ip']);
        return res.send('Access denied!');
    }

    let order = await db.Deposit.find({
        where : {
            order_id : req.query['MERCHANT_ORDER_ID']
        }
    });
    if(!order) 
    {
        console.log('Could not find order #' + req.query['MERCHANT_ORDER_ID']);
        return res.send('YES');
    }

    let user = await db.Users.findById(order.user_id);
    if(!user) 
    {
        console.log('Could not find user #' + order.user_id);
        return res.send('YES');
    }

    // user.balance += req.query['AMOUNT'];
    // if(isNaN(user.balance)) 
    // {
    //     console.log('NaN balance!');
    //     return res.send('NO');
    // }
    // await user.save();
    let finaly = user.balance + parseFloat(req.query['AMOUNT']);
    if(isNaN(finaly)) 
    {
        console.log('NaN balance');
        return res.send('NO');
    }
    await db.Users.update({
        balance : finaly
    }, {
        where : {
            id : order.user_id
        }
    });

    console.log(req.query['AMOUNT'] + ' to ' + order.user_id + ' : ' + user.username + ' / ' + finaly);

    // order.status = 1;
    // await order.save();
    await db.Deposit.update({
        status : 1
    }, {
        where : {
            id : order.id
        }
    });

    console.log('Success deposit!');
    return res.send('YES');
});

r.get('/sendWithdraw', Middleware.auth, Middleware.deposit, async(req, res) => {
    let transaction = await db.transaction();

    try {
        let amount = parseFloat(req.query.amount);
        if(!amount || isNaN(amount)) {
            await transaction.rollback();
            return res.redirect('/');
        }
    
        if(req.query.system != 'Qiwi' && req.query.system != 'Card') {
            await transaction.rollback();
            return res.send('Не удалось определить платежную систему!');
        }
    
        if(req.query.system == 'Qiwi' && amount < 106) {
            await transaction.rollback();
            return res.send('Минимальная сумма вывода на ' + req.query.system + ' - ' + ((req.query.system == 'Qiwi') ? '105' : '154'));
        }
    
        if(req.query.system == 'Card' && amount < 154) {
            await transaction.rollback();
            return res.send('Минимальная сумма вывода на ' + req.query.system + ' - ' + ((req.query.system == 'Qiwi') ? '105' : '154'));
        }
    
        user = await db.Users.findById(req.user.id);
        if(!user) {
            await transaction.rollback();
            return res.redirect('/');
        }
    
        if(isNaN(user.balance)) {
            await transaction.rollback();
            return res.send('Неверный баланс!');
        }
    
        if(amount < 0) {
            await transaction.rollback();
            return res.send('Сумма вывода введена неверно!');
        }
    
        if(user.balance < amount) {
            await transaction.rollback();
            return res.send('Недостаточно баланса!');
        }
    
        user.balance = parseFloat((user.balance-amount).toFixed(2));
        // await user.save();
        await db.Users.update({
            balance : user.balance
        }, {
            where : {
                id : user.id
            },
            transaction : transaction
        });
    
        await db.Withdraw.create({
            user_id : user.id,
            user : {
                id : user.id,
                username : user.username,
                avatar : user.avatar,
                vk : user.vk_id
            },
            amount : amount,
            wallet : req.query.wallet,
            wallet2 : req.query.wallet2,
            type : req.query.system,
            date : Roulette.getDate()
        }, {
            transaction : transaction
        });

        await transaction.commit();
    
        return res.redirect('/');
    } catch(error) {
        await transaction.rollback();
        return res.send('Попробуйте позже!');
    }
});

r.get('/operations', Middleware.auth, async(req, res) => {
    var deps = await db.Deposit.findAll({
        where : {
            user_id : req.user.id
        },
        order : [['id', 'desc']],
        limit : 15
    });

    var list = [];

    for(var i in deps)
    {
        let status = deps[i].status;
        
        let time = new Date(deps[i].createdAt).getTime()+(5*60*1000);
        if(time < new Date().getTime() && status == 0)
        {
            status = 2;
            await db.Deposit.update({
                status : 2
            }, {
                where : {
                    id : deps[i].id
                }
            });
        }
        
        list.push({
            order_id : deps[i].order_id,
            amount : Roulette.numberFormat(deps[i].amount),
            date : await Admin.getDatev2(new Date(deps[i].updatedAt).getTime()),
            status : status
        });
    }

    var sends = await db.Send.findAll({
        where : {
            user_id : req.user.id
        },
        limit : 15,
        order : [['id', 'desc']]
    });

    var history = [];
    for(var i in sends) history.push({
        id : sends[i].id,
        to : sends[i].to,
        value : Roulette.numberFormat(sends[i].value),
        date : sends[i].date
    });

    let promos = await db.Promo.findAll({
        where : {
            user_id : req.user.id
        },
        order : [['id', 'desc']],
        limit : 15
    });

    let listPromo = [];
    for(var i in promos)
    {
        let self = promos[i];
        let result = {
            promo : self.promo,
            amount : self.amount,
            count : self.count,
            activated : self.activated.length,
            date : self.date,
            status : (self.activated.length < self.count) ? 1 : 0,
            id : self.id
        }
        listPromo.push(result);
    }
    
    return res.render('pages/operations', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        title : '- Операции',
        cfg : await db.cfg(),
        count : (req.isAuthenticated()) ? await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }) : 0,
        rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })) : 0,
        withdraws : await db.Withdraw.findAll({
            where : {
                user_id : req.user.id
            },
            order : [['id', 'DESC']],
            limit : 10
        }),
        deps : Roulette.sort(list, 'order_id', 'desc'),
        sends : history,
        promos : listPromo,
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        count : (req.isAuthenticated()) ? await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }) : 0,
    });
});

r.get('/history', async(req, res) => {
    let rooms = await db.Rooms.findAll();
    let list = {};
    for(var u in rooms)
    {
        list[rooms[u].name] = [];
        games = await db.Games.findAll({
            where : {
                status : 3,
                room : rooms[u].id
            },
            limit : 9,
            order : [['id', 'DESC']]
        });
        for(var i = 0; i < games.length; i++) if(games[i].randomOrg !== null) list[rooms[u].name].push({
            id : games[i].id,
            room : games[i].room,
            price : Roulette.numberFormat(games[i].price),
            random : Roulette.numberFormat(games[i].random),
            status : games[i].status,
            secret : games[i].secret,
            randomOrg : games[i].randomOrg,
            winner : games[i].winner,
            winner_id : games[i].winner_id,
            comissionPrice : Roulette.numberFormat(games[i].comissionPrice),
            result : JSON.stringify(games[i].randomOrg.result.random)
        });
    }

    return res.render('pages/history', {
        user : req.user,
        info : await Roulette.globalInfo(),
        games : list,
        rcontents : await Roulette.getRoomsContent(),
        title : '- История игр',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        cfg : await db.cfg(),
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        count : (req.isAuthenticated()) ? await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }) : 0,
        rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })) : 0,
        rooms : await db.Rooms.findAll()
    });
});

// r.get('/about', async(req, res) => {
    // return res.render('pages/about', {
        // user : req.user,
        // info : await Roulette.globalInfo(),
        // rcontents : await Roulette.getRoomsContent(),
        // title : '- Помощь',
        // rate : (req.isAuthenticated()) ? Roulette.numberFormat(await db.Games.sum('comissionPrice', {
            // where : {
                // winner_id : req.user.id,
                // updatedAt : {
                    // [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                // }
            // }
        // }) || 0) : false,
        // refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        // cfg : await db.cfg()
    // });
// });

r.get('/ref', Middleware.auth, async(req, res) => {
    return res.render('pages/ref', {
        user : req.user,
        info : await Roulette.globalInfo(),
        rcontents : await Roulette.getRoomsContent(),
        count : (req.isAuthenticated()) ? await db.Users.findAll({
            where : {
                ref_id : req.user.id
            }
        }) : 0,
        rewards : (req.isAuthenticated()) ? Roulette.numberFormat(await db.RefRewards.sum('value', {
            where : {
                user_id : req.user.id
            }
        })) : 0,
        title : '- Партнерская программа',
        rate : (req.isAuthenticated()) ? Roulette.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : req.user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: req.user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })) : false,
        refPercent : (req.isAuthenticated()) ? await Roulette.getRefsPercent(req.user.id) : 0,
        cfg : await db.cfg()
    });
});

r.post('/addBet', Middleware.auth, async(req, res) => {
    return res.json(await Roulette.createBet(parseInt(req.body.room), req.user.id, req.body.value));
});

r.post('/changeUsername', Middleware.auth, async(req, res) => {
    // if(req.user.id == 16 || req.user.id == 4) return res.json({
    //     success : false,
    //     msg : 'Вы не имеете право менять имя во время тестов!'
    // });

    let transaction = await db.transaction();

    try {
        var user = await db.Users.findById(req.user.id),
        cfg = await db.cfg();

        if(isNaN(user.balance)) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неверный баланс!'
            });
        }

        if(user.balance < cfg.rename_price) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Недостаточно баланса!'
            });
        }

        if(typeof req.body.username == 'null' || typeof req.body.username == 'undefined' || req.body.username.length < 1) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Вы не ввели новое имя!'
            });
        }

        // if(req.body.username.indexOf('<') > -1 || req.username.msg.indexOf('>') > -1) return res.json({
        //     success : false,
        //     msg : 'Запрещено отправлять HTML теги в чат!'
        // });

        if(req.body.username.length > 15) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Максимальная длина нового имени - 15 символов'
            });
        }

        if(req.body.username.length < 5) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Минимальная длина нового имени - 5 символов'
            });
        }

        var needCheck = ['(', ')', '[', ']', '{', '}', '<', '>'];
        for(var i in needCheck) if(req.body.username.indexOf(needCheck[i]) > -1) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Ваше новое имя не должно содержать символы префиксов ('+needCheck[i]+')'
            });
        }

        var alreadyUsed = await db.Users.find({
            where : {
                username : req.body.username
            },
            transaction : transaction
        });

        if(alreadyUsed) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Этот ник уже занято!'
            });
        }

        user.balance = parseFloat((user.balance-cfg.rename_price).toFixed(2));
        user.username = req.body.username;
        // await user.save();

        await db.Users.update({
            balance : user.balance,
            username : user.username
        }, {
            where : {
                id : user.id
            },
            transaction : transaction
        });

        await db.pLog(cfg.rename_price, 'Пользователь #' + user.id + ' сменил ник!', true, Roulette.getDate());

        await transaction.commit();

        Roulette.updateBalance(user.id);
        
        return res.json({
            success : true,
            msg : 'Ваше новый ник - ' + user.username,
            username : user.username
        });
    } catch(error)  {
        await transaction.rollback();
        return res.json({
            success : false,
            msg : 'Попробуйте позже!'
        });
    }
});

// r.get('/test', async(req, res) => {
    // return res.json(await db.Profit.findAll());
// });

module.exports = r;