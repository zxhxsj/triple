var r = require('express').Router();

r.use((req, res, next) => {
    return next();
});



module.exports = r;