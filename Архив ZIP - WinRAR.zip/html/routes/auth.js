const Passport = require('../app/Passport');
const DB = require('../app/Database');
var r = require('express').Router();

r.use((req, res, next) => {
    return next();
});

r.get('/', function(req, res, next) {
    if(typeof req.query.r != 'undefined') res.cookie('referal', req.query.r, {maxAge : 9999999, httpOnly : false});
    return next();
},Passport.authenticate('vkontakte'));

r.get('/callback', function(req, res, next) {
    Passport.authenticate('vkontakte', {
        successRedirect : '/login/redirect',
        failureRedirect : '/'
    }, (err, user, info) => {
        if(err || !user) return res.redirect('/');
        req.logIn(user, async(err) => {
            return res.redirect('/login/redirect');
        });
        return next();
    })(req, res, next);
});

r.get('/user', async(req, res) => {
    return res.json(req.user);
});

r.get('/redirect', async(req, res) => {
    if(req.isAuthenticated() && req.cookies.referal != undefined)
    {
        let user = await DB.Users.find({
            where : {'id' : req.cookies.referal}
        });
        let me = await DB.Users.findById(req.user.id);
        if(user && me && me.id != user.id && me.ref_id == null)
        {
            me.ref_id = user.id;
            await me.save();
        }
        return res.redirect('/');
    } else {
        return res.redirect('/');
    }
});

r.get('/logout', (req, res) => {
    req.logout();
    return res.redirect('/');
});

module.exports = r;