var r = require('express').Router();
const db = require('../app/Database');
const Middleware = require('../app/Middleware');
const Roulette = require('../app/Roulette');
const Admin = require('../app/Admin');
const Redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const Crypto = require('crypto');
const FreeKassa = require('../app/FreeKassa');
const DateFormat = require('dateformat');

r.use(Middleware.admin);

r.get('/fish', async(req, res) => {
    return res.render('admin/fishs', {
        title: 'Рыбалка',
        user: req.user,
        fishs: await db.Fish.findAll(),
        cfg: await db.Config.findOne({
            order: [['id', 'desc']]
        })
    });
});

r.get('/fish/:id/delete', async(req, res) => {
    await db.Fish.destroy({
        where: {
            id: req.params.id
        }
    });
    return res.redirect('/admin/fish');
});

r.post('/fish/save', async(req, res) => {
    let cfg = await db.Config.findOne({
        order: [['id', 'desc']]
    });
    await db.Config.update({
        fish_okup: req.body.fish_okup
    }, {
        where: {
            id: cfg.id
        }
    });
    return res.redirect('/admin/fish');
});

r.get('/fish/:id/edit', async(req, res) => {
    let fish = await db.Fish.findOne({
        where: {
            id: req.params.id
        }
    });

    if(!fish) return res.redirect('/admin/fish');
    return res.render('admin/fish', {
        title: fish.name,
        fish: fish,
        user: req.user
    });
});

r.post('/fish/:id/save', async(req, res) => {
    await db.Fish.update({
        name: req.body.name,
        img: req.body.img,
        min: parseFloat(req.body.min),
        max: parseFloat(req.body.max)
    }, {
        where: {
            id: req.params.id
        }
    });

    return res.redirect('/admin/fish');
});

r.post('/fish/create', async(req, res) => {
    await db.Fish.create({
        name: req.body.name,
        img: req.body.img,
        min: parseFloat(req.body.min),
        max: parseFloat(req.body.max)
    });
    return res.redirect('/admin/fish');
});

r.post('/pd', async(req, res) => {
    let dates = await Admin.getDates(),
        list = [];

    let newDates = [];
    for(var i in dates) if(dates[i] != DateFormat(new Date().getTime(), 'yyyy-mm-dd 00:10:00')) newDates.push(dates[i]);
    dates = newDates;

    for(var i in dates) 
    {
        list.push({
            x : await Admin.getDate(new Date(dates[i]).getTime()),
            profit : await db.Profit.sum('value', {
                where : {
                    createdAt : {
                        [db.Sequelize.Op.gte] : dates[i],
                        [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:00:00')
                    },
                }
            }) || 0
        });

    }

    console.log(list);

    return res.json(list);
});

r.get('/bets/:id', async(req, res) => {
    return res.json(await db.Bets.findAll({
        where : {
            user : req.params.id
        }
    }));
});

r.get('/deps/:id', async(req, res) => {
    return res.json(await db.Deposit.findAll({
        where : {
            user_id : req.params.id
        }
    }));
});

r.get('/online', async(req, res) => {
    return res.json(await Admin.getOnlineDiagrams());
});

r.get('/stats/:id', async(req, res) => {
    let user = await db.Users.findById(req.params.id);
    let actions = [];

    actions.push({
        action : 'register',
        date : new Date(user.createdAt).getTime()
    });
    
    // bets
    let gamesID = [];
    let bets = await db.Bets.findAll({
        where : {
            user : user.id
        }
    });
    for(var i in bets) 
    {
        actions.push({
            actions : 'bet',
            game : bets[i].game,
            room : bets[i].room,
            price : bets[i].price,
            date : new Date(bets[i].createdAt).getTime()
        });

        let check = false;
        for(var u in gamesID) if(gamesID[u] == bets[i].game) check = true;
        if(!check) gamesID.push(bets[i].game);
    }

    // games results
    let games = [];
    for(var i in gamesID)
    {
        let game = await db.Games.findById(gamesID[i]);
        if(game) actions.push({
            action : 'game_result',
            win : (game.winner_id == req.params.id) ? true : false,
            cost : game.comissionPrice,
            room : game.room,
            date : new Date(game.updatedAt).getTime()
        });
    }

    // deposits
    let deposits = await db.Deposit.findAll({
        where : {
            user_id : req.params.id
        }
    });
    for(var i in deposits) actions.push({
        action : 'deposit',
        status : deposits[i].status,
        amount : deposits[i].amount,
        date : new Date(deposits[i].createdAt).getTime()
    });

    // withdraws
    let withdraws = await db.Withdraw.findAll({
        where : {
            user_id : req.params.id
        }
    });
    for(var i in withdraws) actions.push({
        action : 'withdraw',
        status : withdraws[i].status,
        amount : withdraws[i].amount,
        date : new Date(withdraws[i].createdAt).getTime()
    });

    let send_me = await db.Send.findAll({
        where : {
            user_id : req.params.id
        }
    });

    for(var i in send_me) 
    {
        let sender = await db.Users.findById(send_me[i].user_id);
        actions.push({
            action : 'send_me',
            amount : send_me[i].value,
            from : sender,
            date : new Date(send_me[i].createdAt).getTime()
        });
    }

    let my_sends = await db.Send.findAll({
        where : {
            user_id : req.params.id
        }
    });


    for(var i in my_sends) 
    {
        let sender = await db.Users.findById(my_sends[i].to.id);
        actions.push({
            action : 'my_send',
            amount : parseFloat((my_sends[i].value+((my_sends[i].value/95)*5)).toFixed(2)),
            to : sender,
            date : new Date(my_sends[i].createdAt).getTime()
        });
    }

    let promos = await db.PromoActives.findAll({
        where : {
            user_id : req.params.id
        }
    });

    for(var i in promos)
    {
        if(promos[i].user_id == promos[i].owner_id) 
        {
            actions.push({
                action : 'create_promo',
                promo : promos[i].promo,
                amount : promos[i].cost,
                date : new Date(promos[i].createdAt).getTime()
            });
        } else {
            actions.push({
                action : 'active_promo',
                promo : promos[i].promo,
                amount : promos[i].cost,
                date : new Date(promos[i].createdAt).getTime()
            });
        }
    }

    actions = Roulette.sort(actions, 'date', 'asc');

    let balance = 0;
    for(var i in actions)
    {
        let a = actions[i].action;
        if(a == 'bet') balance -= actions[i].price;
        if(a == 'game_result' && actions[i].win) balance += actions[i].cost;
        if(a == 'deposit' && actions[i].status == 1) balance += actions[i].amount;
        if(a == 'withdraw' && actions[i].status != 2) balance -= actions[i].amount;
        if(a == 'send_me') balance += actions[i].amount;
        if(a == 'my_send') balance -= actions[i].amount;
        if(a == 'create_promo') balance -= actions[i].amount;
        if(a == 'active_promo') balance += actions[i].amount;
    }

    return res.json({
       deposits,
	   withdraws  
    });   

	// return res.json({
        // real_balance : balance,
        // balance : user.balance
    // });
    

    // return res.json(actions);
});

r.get('/wins/:id', async(req, res) => {
    return res.json(await db.Games.findAll({
        where : {
            winner_id : req.params.id
        }
    }));
});


r.get('/sends/:id', async(req, res) => {
    return res.json(await db.Send.findAll({
        where : {
            user_id : req.params.id
        }
    }));
});

r.get('/tops', async(req, res) => {
    return res.json(await db.TopRewards.findAll());
});

// r.get('/p4', async(req, res) => {
    // let tl = await db.Profit.findAll({
        // order : [['id', 'DESC']],
        // limit : 2
    // });

    // return res.json(tl);
// });

r.get('/profit', async(req, res) => {
    let cfg = await db.cfg();

    let w = await db.Withdraw.sum('amount', {
        where : {
            status : 0
        }
    }) || 0;

    let u = await db.Users.sum('balance') || 0;
    let fk = parseFloat(cfg.fk_balance);
    let g = await db.Games.sum('price', {
        where : {
            status : {
                [db.Sequelize.Op.lt] : 3
            }
        }
    }) || 0;
    let promos = await db.Promo.findAll({
        where : {
            status : 0
        }
    });
    let sum = 0;
    for(var i in promos) sum += promos[i].amount*(promos[i].count-promos[i].activated.length);
    let today = parseFloat(((parseFloat(fk)+parseFloat(cfg.kassa_balance))-(u+w+g+sum)).toFixed(2));


    // let east = await db.Profit.sum('value', {
    //     where : {
    //         updatedAt : {
    //             [db.Sequelize.Op.gte] :  DateFormat(new Date().getTime()-(24*60*60*1000), 'yyyy-mm-dd 00:00:00'),
    //             [db.Sequelize.Op.lte] : DateFormat(new Date().getTime(), 'yyyy-mm-dd 00:00:00')
    //         }
    //     }
    // }) || 0;

    let east = await db.Profit.find({
        order : [['id', 'DESC']]
    });

    east = (east) ? east.value : 0;



    return res.render('admin/profit', {
        title : 'Доход',
        user : req.user,
        today : Roulette.numberFormat(today),
        east : Roulette.numberFormat(east),
        stats : await Admin.getProfitStats(),
        table : await db.pLogs.findAll({
            where : {
                createdAt : {
                    [db.Sequelize.Op.gte] : (new Date().getTime()-(3600*24*7*1000))
                }
            }
        })
    });

});

r.get('/promos', async(req, res) => {
    let promos = await db.Promo.findAll({
        where : {
            status : 0
        }
    });
    let list = [];
    for(var i in promos)
    {
        let user = await db.Users.findById(promos[i].user_id);
        if(user) list.push({
            id : promos[i].id,
            user : {
                username : user.username,
                avatar : user.avatar,
                vk_id : user.vk_id 
            },
            promo : promos[i].promo,
            activated : promos[i].activated.length + ' из ' + promos[i].count,
            price : promos[i].amount,
            date : await Admin.getDatev2(new Date(promos[i].createdAt).getTime())
        });
    }
    return res.render('admin/promos', {
        title : 'Промокоды',
        user : req.user,
        promos : list
    });
});

r.get('/promos/:id/delete', async(req, res) => {
    let promo = await db.Promo.findById(req.params.id);
    if(!promo) return res.send('Промокод #' + req.params.id + ' не найден!');

    await db.Promo.destroy({
        where : {
            id : req.params.id
        }
    });

    return res.redirect('/admin/promos');
});

r.get('/p', async(req, res) => {
    let stats = {today:{}, eday : {}};
    let dates = [
        DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'),
        DateFormat(new Date().getTime()-(24*60*60*1000), 'yyyy-mm-dd 00:00:00')
    ];

    let rooms = await db.Rooms.findAll();

    for(var i = 0; i < dates.length; i++)
    {
        let section = (i == 0) ? 'today' : 'eday';
        stats[section].sends = await db.Send.sum('value', {
            where : {
                createdAt : {
                    [db.Sequelize.Op.gte] : dates[i],
                    [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:00:00')
                }
            }
        }) || 0;

        stats[section].rooms = [];
        for(var u in rooms)
        {
            console.log(dates[i], DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:00:00'));
            let games = await db.Games.sum('price', {
                where : {
                    room : rooms[u].id,
                    status : 3,
                    updatedAt : {
                        [db.Sequelize.Op.gte] : dates[i],
                        [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:00:00')   
                    }
                }
            }) || 0;

            if(games > 0) games = parseFloat((games*0.1).toFixed(2));

            stats[section].rooms.push({
                name : rooms[u].name,
                value : Roulette.numberFormat(games)
            });
        }

        if(stats[section].sends > 0) {
            let percent = stats[section].sends/95;
            stats[section].sends = Roulette.numberFormat(parseFloat((percent*5).toFixed(2)));    
        }

        stats[section].fish = await db.Fish.sum('final', {
            where : {
                status: 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : dates[i],
                    [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:00:00')   
                }
            }
        }) || 0;

        console.log(stats);
    }

    return res.json(stats);
});

r.get('/', Middleware.auth, async(req, res) => {
    var chat = await db.Users.findAll({
        where : {
            ban_chat : true
        }
    }),
    moders = await db.Users.findAll({
        where : {
            is_admin : 1
        }
    }),
    admins = await db.Users.findAll({
        where : {
            is_admin : 2
        }
    }),
    all = await db.Users.findAll(),
    cfg = await db.cfg();

    let promos = await db.Promo.findAll({
        where : {
            status : 0
        }
    });

    let w = await db.Withdraw.sum('amount', {
        where : {
            status : 0
        }
    }) || 0;

    let u = await db.Users.sum('balance') || 0;
    let g = await db.Games.sum('price', {
        where : {
            status : {
                [db.Sequelize.Op.lt] : 3
            }
        }
    }) || 0;

    let sum = 0;
    for(var i in promos) sum += promos[i].amount*(promos[i].count-promos[i].activated.length);

    return res.render('admin/index', {
        user : req.user,
        title : 'Статистика',
        stats : await Admin.getStats(),
        users : {
            all : Roulette.numberFormat(all.length),
            admins : Roulette.numberFormat(admins.length),
            moders : Roulette.numberFormat(moders.length),
            chat : Roulette.numberFormat(chat.length)
        },
        balance : Roulette.numberFormat(w+u+g+sum),
        kassa : Roulette.numberFormat(cfg.kassa_balance),
        fk : Roulette.numberFormat(cfg.fk_balance)
    });
});

r.get('/deposits', async(req, res) => {
    var deps = await db.Deposit.findAll({
        where : {
            updatedAt : {
                [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-mm-01 00:00:00')
            }
        },
        order : [['id', 'desc']]
    });

    var list = [];
    for(var i in deps)
    {
        let user = await db.Users.findById(deps[i].user_id),
            status = deps[i].status;
        if((new Date(deps[i].updatedAt).getTime() < (new Date().getTime()-10*60*1000)) && deps[i].status == 0) 
        {
            status = 2;
            deps[i].status = 2;
            await deps[i].save();
        }

        if(status == 0) status = 'Ожидание';
        if(status == 1) status = 'Зачислено';
        if(status == 2) status = 'Отклонено';
        
        if(user) list.push({
            order_id : deps[i].order_id,
            user : {
                vk : user.vk_id,
                username : user.username,
                avatar : user.avatar
            },
            amount : deps[i].amount,
            date : await Admin.getDatev2(new Date(deps[i].createdAt).getTime()),
            status : status
        });
    }

    return res.render('admin/deposits', {
        user : req.user,
        title : 'Пополнения',
        deps : list
    });
});

r.post('/wd', async(req, res) => {
    return res.json(await Admin.getWD());
});

r.post('/diagrams', async(req, res) => {
    return res.json({
        online : await Admin.getOnlineDiagrams()
    });
});

r.get('/users', async(req, res) => {
    return res.render('admin/users', {
        user : req.user,
        title : 'Пользователи',
        users : await db.Users.findAll({
            order : [['id', 'DESC']]
        })
    });
}); 

r.get('/withdraws', async(req, res) => {
    return res.render('admin/withdraws', {
        user : req.user,
        title : 'Выводы',
        withdraws : await db.Withdraw.findAll({
            where : {
                status : 0
            }
        }),
        already : await db.Withdraw.findAll({
            where : {
                status : {
                    [db.Sequelize.Op.gt] : 0
                },
                createdAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date().getTime()-(7*24*60*60*1000), 'yyyy-mm-dd 00:00:00')
                }
            }
        })
    });
});

r.get('/withdraws/:id/:status', async(req, res) => {
    merch = await db.Withdraw.findById(req.params.id);
    if(!merch) return res.send('Не удалось найти вывод #' + req.params.id);

    if(req.params.status == 'cancel')
    {
        user = await db.Users.findById(merch.user.id);
        if(!user) return res.send('Не удалось найти пользователя!');

        user.balance = parseFloat((user.balance+merch.amount).toFixed(2));
        await user.save();

        merch.status = 2;
        await merch.save();

        // send message
        Redis.publish('message', JSON.stringify({
            to : merch.user.id,
            msg : 'Ваш вывод был отклонен!',
            type : 'error'
        }));
    }

    if(req.params.status == 'accept')
    {
        let FKBalance = await FreeKassa._fkGetBalance();
        if(!FKBalance.success) return res.send(FKBalance.error);

        let SendResult = await FreeKassa._fkSend(merch.wallet, merch.type, merch.amount, merch.id);
        if(SendResult.success) {
            merch.paymentID = SendResult.id;
            merch.status = 1;
            await merch.save();

            return res.redirect('/admin/withdraws');
        } else {
            return res.send(SendResult.error + ' - ' + merch.wallet);
        }
    }

    return res.redirect('/admin/withdraws');
});

r.get('/users/:user', async(req, res) => {
    user = await db.Users.findById(req.params.user);
    if(!user) return res.redirect('/admin/users');

    return res.render('admin/user', {
        user : req.user,
        title : user.username,
        user1 : user,
        ban_chat : ((user.ban_chat) ? 1 : 0).toString(),
        ban_chat_reason : (!user.ban_chat_reason) ? '' : user.ban_chat_reason,
        is_admin : user.is_admin.toString()
    });
});

r.post('/users/:user/save', async(req, res) => {
    await db.Users.update(req.body, {
        where : {
            id : req.params.user
        }
    });
    return res.redirect('/admin/users/' + req.params.user);
});

r.get('/settings', async(req, res) => {
    return res.render('admin/settings', {
        user : req.user,
        cfg : await db.Config.find({
            order : [['id', 'desc']]
        }),
        title : 'Настройки'
    });
});

r.post('/settings/:id/save', async(req, res) => {
    await db.Config.update(req.body, {
        where : {
            id : req.params.id
        }
    });
    return res.redirect('/admin/settings');
});

r.get('/rooms', async(req, res) => {
    return res.render('admin/rooms', {
        user : req.user,
        title : 'Комнаты',
        rooms : await db.Rooms.findAll()
    });
});

r.get('/rooms/:id', async(req, res) => {
    room = await db.Rooms.findById(req.params.id);
    return res.render('admin/room', {
        user : req.user,
        title : room.name,
        room : room
    });
});

r.post('/rooms/:id/save', async(req, res) => {
    await db.Rooms.update(req.body, {
        where : {
            id : req.params.id
        }
    });
    return res.redirect('/admin/rooms/' + req.params.id);
});

r.get('/addRoom', (req, res) => {
    return res.render('admin/addRoom', {
        user : req.user,
        title : 'Создать комнату'
    });
});

r.post('/createRoom', async(req, res) => {
    room = await db.Rooms.create(req.body);
    room = room.get({plain:true});
    if(room) await Roulette.initRoom(room.id);
    return res.redirect('/admin/rooms');
    
});

r.get('/rooms/:id/delete', async(req, res) => {
    room = await db.Rooms.findById(req.params.id);
    if(!room) return res.send('Не удалось найти комнату #' + req.params.id);

    // Ищем игру, которая не закончилась
    game = await db.Games.find({
        where : {
            room : room.id,
            status : {
                [db.Sequelize.Op.lt] : 3
            }
        }
    });

    if(game)
    {
        // ищем ставки из этой игры
        bets = await db.Bets.findAll({
            where : {
                room : room.id,
                game : game.id
            }
        });

        for(var i = 0; i < bets.length; i++)
        {
            var user = await db.Users.findById(bets[i].user);
            if(user)
            {
                user.balance = parseFloat((user.balance+bets[i].price).toFixed(2));
                user = await user.save();
                
                setTimeout(() => {
                    Redis.publish('message', JSON.stringify({
                        to : user.id,
                        msg : 'Ваша ставка из игры #' + game.id + ' была возвращена!',
                        type : 'info'
                    }));
                    Roulette.updateBalance(user.id);
                });
            }
        }
    }

    // удаляем ставки
    await db.Bets.destroy({
        where : {
            room : room.id
        }
    });

    // удаляем игры 
    await db.Games.destroy({
        where : {
            room : room.id
        }
    });

    // удаляем комнату
    await db.Rooms.destroy({
        where : {
            id : room.id
        }
    });

    Roulette.disableRoom(room.id);

    return res.redirect('/admin/rooms');
});

module.exports = r;