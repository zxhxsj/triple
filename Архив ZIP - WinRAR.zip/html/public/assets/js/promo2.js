$(document).ready(function() {
    this.calc = function(e) {
        if(isNaN(parseInt(e.key)) && e.key != 'Backspace' && e.key != 'Tab') return e.preventDefault();
        let price = parseInt($('#price').val()) || 0;
        let count = parseInt($('#count').val()) || 0;
        let result = price*count;
        // dot check
        let subResult = (result+'').substr((result+'').indexOf('.'), (result+'').length).replace('.', '');
        if(subResult.length > 2) result = result.toFixed(2);

        // print result
        $('.commissionSum').text(result); 
    }
    $('#price').keydown(this.calc);
    $('#price').keyup(this.calc);
    $('#count').keydown(this.calc);
    $('#count').keyup(this.calc);

    $('#sendForm').submit((e) => {
        $.ajax({
            url : '/registerPromo',
            type : 'post',
            data : {
                count : parseInt($('#count').val()) || 0,
                amount : parseInt($('#price').val()) || 0,
                promo : $('#promo').val()
            },
            success : (res) => {
                // console.log(res);
                $.notify(res.msg, (res.success) ? 'success' : 'error');
                if(res.success)
                {
                    // $('#historyList').prepend('<div class="list"><div class="tb1">'+res.result.id+'</div><div class="tb3">'+res.result.promo+'</div><div class="tb4"><span style="font-weight: 500; color: gold">'+res.result.amount+'</span></div><div class="tb5"><span style="font-weight: bold;color: darkorange;">'+res.result.activated.length+' из '+res.result.count+'</span></div><div class="tb2">&nbsp; '+res.result.date+'</div><div class="tb6"><div class="order-status" style="font-weight: 500; color: #32ed52">Активный</div></div></div>');
                }
            },
            error : (err) => {
                $.notify('Ошибка при отправке данных на сервер!', 'error');
                console.log(err.responseText);
            }
        });
        e.preventDefault();
    });

    $('#active').click(() => {
        $.ajax({
            url : '/activePromo',
            type : 'post',
            data : {
                promo : $('#promo_active').val()
            },
            success : (res) => {
                $.notify(res.msg, (res.success) ? 'success' : 'error');
                console.log(res);
            },
            error : (err) => {
                $.notify('Ошибка при отправке данных на сервер!', 'error');
                console.log(err.responseText);
            }
        });
    });
});