$(document).ready(() => {
    ws = new WebSocket ('wss://m24.pw:4433');

    ws.onopen = () => {
        ws.send('hello');
    }

    ws.onmessage = function (message) {
        console.log(message);
    }
});