$(document).ready(function() {
    var b = {
        Android: function() {
            return navigator.userAgent.match(/Android/i)
        },
        BlackBerry: function() {
            return navigator.userAgent.match(/BlackBerry/i)
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i)
        },
        Opera: function() {
            return navigator.userAgent.match(/Opera Mini/i)
        },
        Windows: function() {
            return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i)
        },
        any: function() {
            return b.Android() || b.BlackBerry() || b.iOS() || b.Opera() || b.Windows()
        }
    };
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    }), $('.tooltip').tooltipster({
        side: 'bottom',
        theme: 'tooltipster-borderless'
    }), $('#accordion').accordion({
        heightStyle: 'content'
    }), $('.btn-toggle-menu').click(function() {
        return $('.fixed-nav, .main-width').css({
            transition: 'all .5s ease'
        }), $(this).is('.active') ? ($('.main-width').removeClass('hide-menu'), $('.fixed-nav .buttons .dep').html('\u041F\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u044C'), $('.fixed-nav .buttons .with').html('\u0412\u044B\u0432\u043E\u0434'), $('.fixed-nav, .btn-toggle-menu').removeClass('active'), $.removeCookie('fixed-nav', {
            path: '/'
        })) : ($('.main-width').addClass('hide-menu'), $('.fixed-nav .buttons .dep').html('+'), $('.fixed-nav .buttons .with').html('-'), $('.fixed-nav, .btn-toggle-menu').addClass('active'), $.cookie('fixed-nav', 'true', {
            expires: 7,
            path: '/'
        })), !1
    }), $('.btn-toggle3').click(function() {
        return $('.fixed-chat, .main-width').css({
            transition: 'all .5s ease'
        }), $('.fixed-chat').is('.hide') ? ($('.fixed-chat, .main-width').removeClass('hide'), $.removeCookie('fixed-chat', {
            path: '/'
        })) : ($('.fixed-chat, .main-width').addClass('hide'), $.cookie('fixed-chat', 'true', {
            expires: 7,
            path: '/'
        })), !1
    }), $.cookie('fixed-nav') && ($('.main-width').addClass('hide-menu'), $('.fixed-nav .buttons .dep').html('+'), $('.fixed-nav .buttons .with').html('-'), $('.fixed-nav, .btn-toggle-menu').addClass('active')), $.cookie('fixed-chat') && $('.fixed-chat, .main-width').addClass('hide'), $('.scroller').slimScroll({
        size: '5px',
        start: 'bottom',
        height: 'auto'
    }), $(window).resize(function() {
        $('.scroller').slimScroll({
            destroy: !0
        }), $('.scroller').slimScroll({
            size: '5px',
            start: 'bottom',
            height: 'auto'
        })
    }), $(window).resize(), $('.close').click(function() {
        return $('.popup, .overlay, body').removeClass('active'), !1
    }), $('.overlay').click(function(c) {
        var d = c.target || c.srcElement;
        d.className.search('overlay') || $('.overlay, .popup, body').removeClass('active')
    }), $('[rel=popup]').click(function() {
        return showPopup($(this).attr('data-popup')), !1
    }), $('.cont-a .rooms .room:first').addClass('active'), $('.cont-a .historyTable:first').addClass('active'), $('.cont-a .rooms .room').click(function() {
        $(this).is('.active') || ($('.cont-a .rooms .room, .historyTable').removeClass('active'), $(this).addClass('active'), $('.historyTable:eq(' + $(this).index() + ')').addClass('active'))
    });
});

function showPopup(a) {
    $('.popup').is('.active') && $('.popup').removeClass('active'), $('.overlay, body, .popup.' + a).addClass('active')
}

function chatdelet(a) {
    $.post('/chatdel', {
        messages: a
    }, function(b) {
        b && $.notify({
            position: 'top-right',
            type: b.status,
            message: b.message
        })
    })
}

function copyToClipboard(a) {
    var b = $('<input>');
    $('body').append(b), b.val($(a).val()).select(), document.execCommand('copy'), b.remove(), $.notify('Скопировано в буфер обмена!', 'info'), $('.popup, .overlay, body').removeClass('active')
}

function declOfNum(a, b) {
    return cases = [2, 0, 1, 1, 1, 2], b[4 < a % 100 && 20 > a % 100 ? 2 : cases[5 > a % 10 ? a % 10 : 5]]
}
