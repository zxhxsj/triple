$(document).ready(() => {
    const e = io.connect('https://m24.pw:2083');
    var i = $.cookie('sounds');
    i == void 0 && (i = 'on'), e.on('mateNotify', p => {
        if (p.room != roomID) return;
        console.log(p);
        p.to != user.id || ($('.mates').before('<div class="mate-notify query-' + p.query + '" data-query="' + p.query + '"><div class="user"><div class="avatar"> <img src="' + p.sender.avatar + '" alt=""></div> <a class="username" href="https://vk.com/id' + p.sender.vk + '" target="_blank">' + p.sender.username + '</a></div> <span class="hidden-sm"> \u0445\u043E\u0447\u0435\u0442 \u0438\u0433\u0440\u0430\u0442\u044C \u0432 \u043F\u0430\u0440\u0435 </span><div class="buttons"> <button type="button" data-status="1">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button> <button type="button" data-status="2">\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C</button></div></div>'), $('.query-' + p.query).slideDown(400), $('.query-' + p.query).find('button').click(function() {
            $.ajax({
                url: '/acceptMateNotify',
                type: 'post',
                data: {
                    query: parseInt($(this).parent().parent().attr('data-query')),
                    status: parseInt($(this).attr('data-status'))
                },
                success: q => {
                    $(this).parent().parent().slideUp(400, () => {
                        $(this).parent().parent().remove()
                    }), $.notify(q.msg, q.success ? 'success' : 'error')
                },
                error: q => {
                    $.notify('\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440!', 'error'), console.log(q.responseText)
                }
            })
        }))
    }), e.on('bets', p => {
        p.room != roomID || ($('title').text(p.title), 'on' == i && audio('https://m24.pw/public/assets/sounds/bet.wav', 0.3), window.parseBets(p.bets))
    }), e.on('timer', p => {
        p.room != roomID || ($('#timer-min').text(p.timer.min), $('#timer-sec').text(p.timer.sec), 0 == parseInt(p.timer.min) && 10 >= parseInt(p.timer.sec) && 'on' == i && audio('https://m24.pw/public/assets/sounds/tick.wav', 0.1))
    }), e.emit('getSlider', roomID), e.on('postSlider', p => {
        p && ($('#circle').css({
            transform: 'rotate(-' + Math.floor(p.start) + 'deg)'
        }), setTimeout(() => {
            parseSlider(p)
        }, 1))
    }), e.on('slider', p => {
        p.room != roomID || ('on' == i && audio('https://m24.pw/public/assets/sounds/spin2.mp3', 0.2), parseSlider(p))
    }), window.parseSlider = function(p) {
        $('title').text(p.title), $('#timer-min').text(p.timer.min), $('#timer-sec').text(p.timer.sec), $('#circle').css({
            transition: 'all ' + p.time + 'ms ease',
            transform: 'rotate(-' + p.rotate + 'deg)'
        }), setTimeout(() => {
            $('#gameCarousel').find('img').attr('src', p.winner.avatar), $('.winner-name span').text(p.winner.username), $('.winner-cost-value').text(p.price), $('.winner-cost-ch').text(p.winner.bet.chance + '%'), $('#winner-ticket').text(p.ticket), $('.fair-secret').text(p.secret), $('#gameCarousel').slideDown(400), 'on' == i && p.winner.id == user.id && audio('https://m24.pw/public/assets/sounds/win' + (Math.floor(61 * Math.random()) + 1) + '.mp3', 0.3)
        }, p.time)
    }, e.on('newGame', p => {
        p.room != roomID || ($('.game_id').text('#' + p.id), $('#winavatar img').attr('src', p.winner.avatar), $('#winidrest').text(p.winner.username), $('#winchancet').text(p.winner.chance), $('#winmoner').html(p.winner.price + ' <i class="icon icon-goldcoin"></i>'), $('.ball_holderG').addClass('move'), $('#timer-min').text(p.timer.min), $('#timer-sec').text(p.timer.sec), $('title').text(p.title), $('#gameCarousel').slideUp(400), $('.bets').slideUp(400, () => {
            $('.bets').find('li').remove(), $('.bets').show()
        }), $('.chances').slideUp(400, () => {
            $('.chances').find('li').remove(), $('.chances').show()
        }), $('.game-price').text(0), $('#colors').slideUp(400, () => {
            $('#colors').find('div').remove(), $('#colors').show()
        }), $('#game-secret').text(p.secret), chart.data.datasets[0].data = [100], chart.data.datasets[0].backgroundColor = ['rgba(10, 21, 30, 0.5411764705882353)'], chart.update(), $('#circle').css({
            transition: 'all 0ms ease',
            transform: 'rotate(0deg)'
        }), $('#myChance').text('0.00'), $('#myBet').text('0')), $('.fair-button').attr('href', 'https://m24.pw/fair/' + p.id)
    });
    var o = document.getElementById('circle').getContext('2d');
    o.canvas.width = 100, o.canvas.height = 100, window.chart = new Chart(o, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                label: '# of Votes',
                data: [100],
                backgroundColor: ['rgba(10, 21, 30, 0.5411764705882353)'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: !0,
            cutoutPercentage: 75,
            legend: {
                display: !1
            },
            tooltips: {
                enabled: !1
            }
        }
    }), window.parseRotate = function() {
        var p = chart.data.datasets[0].data,
            q = [],
            r = 0;
        for (var s in p) q.push({
            start: r,
            end: r + 3.6 * p[s],
            random: random(r, r + 3.6 * p[s])
        }), r += 3.6 * p[s];
        return q
    }, window.colorsList = ['#DC143C', '#00FF7F', '#FF8C00', '#228B22', '#20B2AA', '#BA55D3', '#f0e68c', '#40E0D0', '#a52a2a', '#483D8B', '#DEB887', '#32CD32', '#008080', '#ff7f50', '#0FF', '#F0F', '#dda0dd', '#00F', '#FF0', '#0F0'], window.parseBets = function(p) {
        var s = '',
            t = [],
            u = [];
        for (var v in p.chances) s += '<li class="tooltip tooltipstered chance-user"> <img src="' + p.chances[v].user.avatar + '" alt="" data-user-id="' + p.chances[v].user.id + '"> <span>' + p.chances[v].chance + '%</span> <color class="color_' + p.chances[v].color + '"></color></li>', t.push(parseFloat(p.chances[v].chance)), u.push(window.colorsList[parseInt(p.chances[v].color) - 1]);
        for (var v in 0 == t.length && (t = [100], u = ['rgba(10, 21, 30, 0.5411764705882353)'], $('.ball_holderG').addClass('move')), chart.data.datasets[0].data = t, chart.data.datasets[0].backgroundColor = u, chart.update(), $('.players-list').html(s), p.chances) $('.ball_holderG').removeClass('move');
        $('.chance-user img').click(function() {
            confirm('\u0412\u044B \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0445\u043E\u0442\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0437\u0430\u043F\u0440\u043E\u0441 \u043A\u043E\u043C\u0430\u043D\u0434\u043D\u043E\u0439 \u0438\u0433\u0440\u044B \u0438\u0433\u0440\u043E\u043A\u0443 #' + $(this).attr('data-user-id')) && $.ajax({
                url: '/sendMateNotify',
                type: 'post',
                data: {
                    room: roomID,
                    to: $(this).attr('data-user-id')
                },
                success: x => {
                    $.notify(x.msg, x.success ? 'success' : 'error')
                },
                error: x => {
                    $.notify('\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440!', 'error'), console.log(x.responseText)
                }
            })
        }), $('#colors').html(''), $('.game-price').text(numberFormat(p.price));
        var w = '';
        for (var v in p.bets) w += '<li> <color class="color_' + p.bets[v].color + '"></color><div class="user"><div class="ava"><img src="' + p.bets[v].user.avatar + '" alt=""></div><div class="info"><div class="nickname">' + p.bets[v].user.username + '</div><div class="points">\u041F\u043E\u0441\u0442\u0430\u0432\u0438\u043B: <span style="font-weight: bold;color: gold;">' + p.bets[v].price + '</span> <span class="fab fa-monero mgmoney"></span></div></div><div class="detail"><div class="percent">\u0411\u0438\u043B\u0435\u0442\u044B</div><div class="tickets">\u043E\u0442 #' + numberFormat(p.bets[v].from) + ' \u0434\u043E #' + numberFormat(p.bets[v].to) + '</div></div></div></li>';
        $('.bets-list').html(w)
    }, window.newbet = function() {
        if (!checkTime()) return;
        value = parseInt($('.bet_inp').val()) || 0, $('.bet_inp').val(''), $.cookie('last_bet_emit', Math.floor(new Date().getTime() / 1e3)), $.ajax({
            url: '/addBet',
            type: 'post',
            data: {
                value: value,
                room: roomID
            },
            success: p => {
                $.notify(p.msg, p.success ? 'success' : 'error'), p.success && ($('#myChance').text(p.data.chance), $('#myBet').text(p.data.bet))
            },
            error: p => {
                console.log(p.responseText)
            }
        })
    }, window.init = function() {
        $.ajax({
            url: '/getInfo',
            type: 'post',
            data: {
                room: roomID
            },
            success: p => {
                return p.success ? void(this.parseBets(p.bets), $('.game-price').text(p.game.price), $('#timer-min').text(p.room.timer.min), $('#timer-sec').text(p.room.timer.sec)) : $.notify(p.msg, 'error')
            },
            error: p => {
                console.log(p.responseText)
            }
        })
    }, window.audio = function(p, q) {
        var r = new Audio;
        r.src = p, r.volume = q, r.play()
    }, 
		window.showPopup = function(p) {
        $('.popup').is('.active') && $('.popup').removeClass('active'), $('.overlay, .part, .popup.' + p).addClass('active')
    }, $('.overlay').click(function(p) {
        var q = p.target || p.srcElement;
        q.className.search('overlay') || $('.overlay, .popup, .part').removeClass('active')
    }), $('[rel=popup]').click(function() {
        return showPopup($(this).attr('data-popup')), !1
    }), 'on' == i ? ($('#open_chm').addClass('hidden'), $('#close_chm').removeClass('hidden')) : ($('#open_chm').removeClass('hidden'), $('#close_chm').addClass('hidden')), $('#open_chm').click(function(p) {
        p.preventDefault(), $('#open_chm').addClass('hidden'), $('#close_chm').removeClass('hidden'), i = 'on', $.cookie('sounds', 'on', {
            expires: 365
        })
    }), $('#close_chm').click(function(p) {
        p.preventDefault(), $('#open_chm').removeClass('hidden'), $('#close_chm').addClass('hidden'), i = 'off', $.cookie('sounds', 'off', {
            expires: 365
        })
    }), init()
});
