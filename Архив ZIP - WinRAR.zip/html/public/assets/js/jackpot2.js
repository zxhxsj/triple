$(document).ready(() => {
    const a = io.connect('https://mg24.pro:2083');
    // const roomID = getRoomID();
	var b = $.cookie('sounds');
	if (b == undefined) b = 'on';
	a.on('mateNotify', d => {
		if(d.to != user.id) return; 
		$('.mates').before('<div class="mate-notify query-' + d.query + '" data-query="' + d.query + '"><div class="user"><div class="avatar"> <img src="' + d.sender.avatar + '" alt=""></div> <a class="username" href="https://vk.com/id' + d.sender.vk + '" target="_blank">' + d.sender.username + '</a></div> <span class="hidden-sm"> хочет играть в паре </span><div class="buttons"> <button data-status="1">Принять</button> <button data-status="2">Отклонить</button></div></div>');
		$('.query-' + d.query).slideDown(400);
		$('.query-' + d.query).find('button').click(function () {
			$.ajax({
				url: '/acceptMateNotify',
				type: 'post',
				data: {
					query: parseInt($(this).parent().parent().attr('data-query')),
					status: parseInt($(this).attr('data-status'))
				},
				success: f => {
					$(this).parent().parent().slideUp(400, () => {
						$(this).parent().parent().remove()
					}),
					$.notify(f.msg, f.success ? 'success' : 'error')
				},
				error: f => {
					$.notify('Ошибка при отправке данных на сервер!', 'error'),
					console.log(f.responseText)
				}
			})
		});
	}),
	a.on('bets', d => {
		d.room != roomID || ($('title').text(d.title), 'on' == b && audio('https://mg24.pro/public/assets/sounds/bet.wav', 0.1), window.parseBets(d.bets))
	}),
	a.on('timer', d => {
		d.room != roomID || ($('#timer-min').text(d.timer.min), $('#timer-sec').text(d.timer.sec), 0 == parseInt(d.timer.min) && 10 >= parseInt(d.timer.sec) && 'on' == b && audio('https://mg24.pro/public/assets/sounds/tick.wav', 0.1))
	}),
	a.emit('getSlider', roomID),
	a.on('postSlider', d => {
		d && ($('#circle').css({
			transform: 'rotate(-' + Math.floor(d.start) + 'deg)'
		}), setTimeout(() => {
			parseSlider(d)
		}, 1))
	}),
	a.on('slider', d => {
		d.room != roomID || ('on' == b && audio('https://mg24.pro/public/assets/sounds/scroll.wav', 0.1), parseSlider(d))
	}),
	window.parseSlider = function (d) {
		$('title').text(d.title), $('#timer-min').text(d.timer.min), $('#timer-sec').text(d.timer.sec), $('#circle').css({
			transition: 'all ' + d.time + 'ms ease',
			transform: 'rotate(-' + d.rotate + 'deg)'
		}), setTimeout(() => {
			// $('.winner-cost-ch').text()
			console.log(d.winner);
			$('#gameCarousel').find('img').attr('src', d.winner.avatar);
			$('.winner-name span').text(d.winner.username),
			$('.winner-cost-value').text(d.price),
			$('.winner-cost-ch').text(d.winner.bet.chance + '%'),
			$('#winner-ticket').text(d.ticket),
			$('.fair-secret').text(d.secret),
			$('#gameCarousel').slideDown(400),
			'on' == b && d.winner.id == user.id && audio('https://mg24.pro/public/assets/sounds/win' + (Math.floor(Math.random() * 20) + 1) + '.mp3', 0.1)
		}, d.time)
	},
	a.on('newGame', d => {
		d.room != roomID || ($('.game_id').text('#' + d.id), $('#winavatar img').attr('src', d.winner.avatar), $('#winidrest').text(d.winner.username), $('#winchancet').text(d.winner.chance), $('#winmoner').html(d.winner.price + ' <i class="icon icon-goldcoin"></i>'), $('.ball_holderG').addClass('move'), $('#timer-min').text(d.timer.min), $('#timer-sec').text(d.timer.sec), $('title').text(d.title), $('#gameCarousel').slideUp(400), $('.bets').slideUp(400, () => {
			$('.bets').find('li').remove(),
			$('.bets').show()
		}), $('.chances').slideUp(400, () => {
			$('.chances').find('li').remove(),
			$('.chances').show()
		}), $('.game-price').text(0), $('#colors').slideUp(400, () => {
			$('#colors').find('div').remove(),
			$('#colors').show()
		}), $('#game-secret').text(d.secret), chart.data.datasets[0].data = [100], chart.data.datasets[0].backgroundColor = ['#0a151e8a'], chart.update(), $('#circle').css({
			transition: 'all 0ms ease',
			transform: 'rotate(0deg)'
		}), $('#myChance').text('0.00'), $('#myBet').text('0'));
		$('.fair-button').attr('href', 'https://mg24.pro/fair/' + d.id);
	});
	var c = document.getElementById('circle').getContext('2d');
	c.canvas.width = 100,
	c.canvas.height = 100,
	window.chart = new Chart(c, {
		type: 'doughnut',
		data: {
			labels: [],
			datasets: [{
				label: '# of Votes',
				data: [100],
				backgroundColor: ['#0a151e8a'],
				borderWidth: 0
			}]
		},
		options: {
			responsive: !0,
			cutoutPercentage: 75,
			legend: {
				display: !1
			},
			tooltips: {
				enabled: !1
			}
		}
	}),
	window.parseRotate = function () {
		var d = chart.data.datasets[0].data,
			f = [],
			g = 0;
		for (var h in d) f.push({
			start: g,
			end: g + 3.6 * d[h],
			random: random(g, g + 3.6 * d[h])
		}), g += 3.6 * d[h];
		return f
	},
	window.colorsList = ['#DC143C', '#00FF7F', '#FF8C00', '#228B22', '#20B2AA', '#BA55D3', '#f0e68c', '#40E0D0', '#a52a2a', '#483D8B', '#DEB887', '#32CD32', '#008080', '#ff7f50', '#0FF', '#F0F', '#dda0dd', '#00F', '#FF0', '#0F0'],
	window.parseBets = function (d) {
		var f = '',
			g = '',
			h = '',
			j = [],
            k = [];
        for(var l in d.chances)
        {
            h += '<li class="tooltip tooltipstered chance-user"> <img src="' + d.chances[l].user.avatar + '" alt="" data-user-id="' + d.chances[l].user.id + '"> <span>'+d.chances[l].chance+'%</span> <color class="color_' + d.chances[l].color + '"></color></li>';
            j.push(parseFloat(d.chances[l].chance)), k.push(window.colorsList[parseInt(d.chances[l].color) - 1]);
        }
        // for (var l in d.chances) d.chances[l].user.id == user.id && ($('#myChance').text(d.chances[l].chance), $('#myBet').text(d.chances[l].bet)), h += '<span class="tooltip_chance chan_' + d.chances[l].color + '">' + d.chances[l].user.username + '<br><a href="https://vk.com/id' + d.chances[l].user.vk + '" target="_blank">Перейти на страницу</a></span>', f += '<div class="players-percent-block color_' + d.chances[l].color + '"> <img alt="" data-user-id="' + d.chances[l].user.id + '" src="' + d.chances[l].user.avatar + '" style="cursor:pointer;"><div class="players-percent-text">' + d.chances[l].chance + '%</div>' + h + '</div>', g += '<div class="color_' + d.chances[l].color + '" style="width: ' + d.chances[l].chance + '%;"></div>';
        for (var l in 0 == j.length && (j = [100], k = ['#0a151e8a'], $('.ball_holderG').addClass('move')), chart.data.datasets[0].data = j, chart.data.datasets[0].backgroundColor = k, chart.update(), $('.players-list').html(h), d.chances) $('.ball_holderG').removeClass('move');
        // $('.color_' + d.chances[l].color).tooltipster({
		// 	contentAsHTML: !0,
		// 	interactive: !0,
		// 	content: $('.chan_' + d.chances[l].color).html(),
		// 	side: 'bottom',
		// 	theme: 'tooltipster-borderless'
		// });
		$('.chance-user img').click(function () {
			confirm('Вы действительно хотите отправить запрос командной игры игроку #' + $(this).attr('data-user-id')) && $.ajax({
				url: '/sendMateNotify',
				type: 'post',
				data: {
					room: roomID,
					to: $(this).attr('data-user-id')
				},
				success: n => {
					$.notify(n.msg, n.success ? 'success' : 'error')
				},
				error: n => {
					$.notify('Ошибка при отправке данных на сервер!', 'error'),
					console.log(n.responseText)
				}
			})
		}), $('#colors').html(g), $('.game-price').text(numberFormat(d.price));
		var m = '';
        // for (var l in d.bets) m += '<div class="bet color_' + d.bets[l].color + '"><div class="short"><div class="top"><div class="avatar color_' + d.bets[l].color + ' "> <img alt="" src="' + d.bets[l].user.avatar + '"/></div> <span class="username">' + d.bets[l].user.username + '&nbsp;</span> <span class="u_deposit">вложил </span> <span class="u_price">' + d.bets[l].price + '</span> <i class="icon icon-goldcoin"></i> <div class="blanks">Билеты от <span class="from price">#' + numberFormat(d.bets[l].from) + '</span> до <span class="to price">#' + numberFormat(d.bets[l].to) + '</span></div></div></div></div>';
        for (var l in d.bets) m += '<li> <color class="color_' + d.bets[l].color + '"></color><div class="user"><div class="ava"><img src="' + d.bets[l].user.avatar + '" alt=""></div><div class="info"><div class="nickname">' + d.bets[l].user.username + '</div><div class="points">Поставил: <span style="font-weight: bold;color: gold;">' + d.bets[l].price + '</span> <span class="fab fa-monero mgmoney"></span></div></div><div class="detail"><div class="percent">Билеты</div><div class="tickets">от #' + numberFormat(d.bets[l].from) + ' до #' + numberFormat(d.bets[l].to) + '</div></div></div></li>'
		$('.bets-list').html(m)
	},
	window.newbet = function () {
		value = parseInt($('.bet_inp').val()) || 0, $('.bet_inp').val(''), $.cookie('last_bet_emit', Math.floor(new Date().getTime() / 1e3)), $.ajax({
			url: '/addBet',
			type: 'post',
			data: {
				value: value,
				room: roomID
			},
			success: d => {
				$.notify(d.msg, d.success ? 'success' : 'error'),
				d.success && ($('#myChance').text(d.data.chance), $('#myBet').text(d.data.bet))
			},
			error: d => {
				console.log(d.responseText)
			}
		})
	},
	window.init = function () {
		$.ajax({
			url: '/getInfo',
			type: 'post',
			data: {
				room: roomID
			},
			success: d => {
				return d.success ? void(this.parseBets(d.bets), $('.game-price').text(d.game.price), $('#timer-min').text(d.room.timer.min), $('#timer-sec').text(d.room.timer.sec)) : $.notify(d.msg, 'error')
			},
			error: d => {
				console.log(d.responseText)
			}
		})
	},
	window.audio = function (d, f) {
		var g = new Audio;
		g.src = d, g.volume = f, g.play()
	},
	window.showPopup = function (d) {
		$('.popup').is('.active') && $('.popup').removeClass('active'), $('.overlay, .part, .popup.' + d).addClass('active')
	},
	$('.overlay').click(function (d) {
		var f = d.target || d.srcElement;
		f.className.search('overlay') || $('.overlay, .popup, .part').removeClass('active')
	}),
	$('[rel=popup]').click(function () {
		return showPopup($(this).attr('data-popup')), !1
	}),
	'on' == b ? ($('#open_chm').addClass('hidden'), $('#close_chm').removeClass('hidden')) : ($('#open_chm').removeClass('hidden'), $('#close_chm').addClass('hidden')),
	$('#open_chm').click(function (d) {
		d.preventDefault(), $('#open_chm').addClass('hidden'), $('#close_chm').removeClass('hidden'), b = 'on', $.cookie('sounds', 'on', {
			expires: 365
		})
	}),
	$('#close_chm').click(function (d) {
		d.preventDefault(), $('#open_chm').removeClass('hidden'), $('#close_chm').addClass('hidden'), b = 'off', $.cookie('sounds', 'off', {
			expires: 365
		})
	}),
	init()
});
