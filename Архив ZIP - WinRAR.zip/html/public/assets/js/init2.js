$(document).ready(() => {

    window.socket = io.connect('https://mg24.pro:2083');

    window.getRoomID = function() {
        array = location.search.replace('?', '').split('&');
        for(var i in array) if(array[i].indexOf('room=') > -1) return parseFloat(array[i].replace('room=', '')) || 0;
        return 0;
    }
});