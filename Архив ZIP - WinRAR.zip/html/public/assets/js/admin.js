$(document).ready(() => {
    const wss = new WebSocket('wss://m24.pw:8080/');

    wss.onopen = () => {
        wss.send(JSON.stringify({
            action : 'upd_online'
        }));
    }

    wss.onmessage = (res) => {
        res = JSON.parse(res.data);
        if(res.action == 'online') parseOnline(res);
    }

    wss.onclose = () => {
        location.reload();
    }

    // index diagrams
    if(location.pathname == '/admin')
    {
        $.ajax({
            url: '/admin/diagrams',
            type: 'post',
            success: a => {
                console.log(a), Morris.Area({
                    element: 'withdraws',
                    data: a.online,
                    xkey: 'time',
                    ykeys: ['count'],
                    labels: ['\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0445'],
                    fillOpacity: 0.9,
                    pointStrokeColors: ['#aba7de', '#7aecb8'],
                    behaveLikeLine: !0,
                    gridLineColor: '#e1e1e1',
                    lineWidth: 0,
                    smooth: !0,
                    hideHover: 'auto',
                    lineColors: ['#aba7de', '#7aecb8'],
                    resize: !0
                })
            },
            error: a => {
                console.log(a.responseText)
            }
        });
    }
    

    function parseOnline(res) {
        let html = '';
        for(var i in res.users)
        {
            let user = res.users[i];
            if(user.permission == 1) user.username = '<font color="green">' + user.username + '</font>';
            if(user.permission == 2) user.username = '<font color="red">' + user.username + '</font>';
            html += '<tr><td> <img src="' + user.avatar + '" style="width: 30px; border-radius: 50%;"> ' + user.username + ' ['+user.connection+']</td><td>' + user.count + '</td><td style="line-height: 30px;"> <a href="/admin/users/' + user.id + '" class="btn btn-primary">Редактировать</a></td></tr>';
        }
        $('#onlineUsers').html(html);
    }
});