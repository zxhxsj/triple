$(document).ready(() => {
    $('#depositForm').submit(function(e) {
        if(!checkTime()) return e.preventDefault(); 
    });


    window.checkTime = function() {
        let time = localStorage.getItem('node_session') || false;
        if(time && ((new Date().getTime())-parseInt(time)) < 3000) 
        {
            $.notify('Попробуйте позже', 'error');
            return false;
        }
    
        localStorage.setItem('node_session', new Date().getTime());
        return true;
    }
});