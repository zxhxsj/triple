$(document).ready(() => {
    const wss = new WebSocket('wss://mg24.pw:8080/');
    const audio = {
        bet: new Audio('https://mg24.pro/public/assets/sounds/bet.wav', 0.3)
    }

    wss.onopen = () => {
        $.notify('Jackpot соединение установлено!', 'info');
    }

    wss.onclose = () => {
        $.notify('Jackpot соединение потеряно!', 'error');
    }

    wss.onmessage = (res) => {
        res = JSON.parse(res.data);
        if (res.action == 'mateNotify') mateNotify(res);
        if (res.action == 'bets') {
            $('title').text(res.title);
            audio.bet.play();
            parseBets(res);
        }
    }

    var canvas = document.getElementById('circle').getContext('2d');
    canvas.canvas.width = 100
    canvas.canvas.height = 100

    const chart = new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                label: '',
                data: [100],
                backgroundColor: ['rgba(10, 21, 30, 0.5411764705882353)'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: 1,
            cutoutPercentage: 75,
            legend: {
                display: 0
            },
            tooltips: {
                enabled: 0
            }
        }
    });

    const colorsList = ['#DC143C', '#00FF7F', '#FF8C00', '#228B22', '#20B2AA', '#BA55D3', '#f0e68c', '#40E0D0', '#a52a2a', '#483D8B', '#DEB887', '#32CD32', '#008080', '#ff7f50', '#0FF', '#F0F', '#dda0dd', '#00F', '#FF0', '#0F0'];

    function mateNotify(res) {
        if (res.to != user.id) return;
        $('.mates').before('<div class="mate-notify query-' + res.query + '" data-query="' + res.query + '"><div class="user"><div class="avatar"> <img src="' + res.sender.avatar + '" alt=""></div> <a class="username" href="https://vk.com/id' + res.sender.vk + '" target="_blank">' + res.sender.username + '</a></div> <span class="hidden-sm"> \u0445\u043E\u0447\u0435\u0442 \u0438\u0433\u0440\u0430\u0442\u044C \u0432 \u043F\u0430\u0440\u0435 </span><div class="buttons"> <button type="button" data-status="1">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button> <button type="button" data-status="2">\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C</button></div></div>');

        $('.query-' + res.query).slideDown(400);
        $('.query-' + p.query).find('button').click(function () {
            $.ajax({
                url: '/acceptMateNotify',
                type: 'post',
                data: {
                    query: parseInt($(this).parent().parent().attr('data-query')),
                    status: parseInt($(this).attr('data-status'))
                },
                success: q => {
                    $(this).parent().parent().slideUp(400, () => {
                        $(this).parent().parent().remove()
                    }), $.notify(q.msg, q.success ? 'success' : 'error')
                },
                error: q => {
                    $.notify('Ошибка при отправке данных на сервер!', 'error');
                    console.log(q.responseText)
                }
            });
        });
    }

    function parseBets(res) {
        let chances = '';
        let values = [];
        let colors = [];
        let circleColors = [];
        for (var i in res.chances) {
            chances += '<li class="tooltip tooltipstered chance-user"> <img src="' + res.chances[i].user.avatar + '" alt="" data-user-id="' + res.chances[i].user.id + '"> <span>' + res.chances[i].chance + '%</span> <color class="color_' + res.chances[i].color + '"></color></li>';

            values.push(parseFloat(res.chances[i].chance));
            colors.push(colorsList[parseInt(res.chances[i].color) - 1])
        }

        chart.data.datasets[0].data = values;
        chart.data.datasets[0].backgroundColor = colors;
        chart.update();

        $('.players-list').html(chances);

        $('.chance-user img').click(function () {
            if (confirm('Вы действительно хотите предложить командную игру игроку #' + $(this).attr('data-user-id'))) {
                $.ajax({
                    url: '/sendMateNotify',
                    type: 'post',
                    data: {
                        room: roomID,
                        to: $(this).attr('data-user-id')
                    },
                    success: x => {
                        $.notify(x.msg, x.success ? 'success' : 'error')
                    },
                    error: x => {
                        $.notify('Ошибка при отправке данных на сервер!', 'error'); console.log(x.responseText);
                    }
                });
            }
        });

        $('.game-price').text(numberFormat(res.price));

        let bets = '';
        for (var i in res.bets) bets += '<li> <color class="color_' + res.bets[i].color + '"></color><div class="user"><div class="ava"><img src="' + res.bets[i].user.avatar + '" alt=""></div><div class="info"><div class="nickname">' + res.bets[i].user.username + '</div><div class="points">\u041F\u043E\u0441\u0442\u0430\u0432\u0438\u043B: <span style="font-weight: bold;color: gold;">' + res.bets[i].price + '</span> <span class="fab fa-monero mgmoney"></span></div></div><div class="detail"><div class="percent">\u0411\u0438\u043B\u0435\u0442\u044B</div><div class="tickets">\u043E\u0442 #' + numberFormat(res.bets[i].from) + ' \u0434\u043E #' + numberFormat(res.bets[i].to) + '</div></div></div></li>';

        $('.bets-list').html(bets);
    }

    $.ajax({
        url: '/getInfo',
        type: 'post',
        data: {
            room: roomID
        },
        success: p => {
            if (p.success) {
                parseBets(p.bets);
                $('.game-price').text(p.game.price);
                $('#timer-min').text(p.room.timer.min);
                $('#timer-sec').text(p.room.timer.sec);
            } else {
                $.notify(p.msg, 'error');
            }
        },
        error: p => {
            console.log(p.responseText)
        }
    });

    // window.parseBets = function(p) {
    //     var s = '',
    //         t = [],
    //         u = [];
    //     for (var v in p.chances) s += '<li class="tooltip tooltipstered chance-user"> <img src="' + p.chances[v].user.avatar + '" alt="" data-user-id="' + p.chances[v].user.id + '"> <span>' + p.chances[v].chance + '%</span> <color class="color_' + p.chances[v].color + '"></color></li>',
    //     t.push(parseFloat(p.chances[v].chance)), u.push(window.colorsList[parseInt(p.chances[v].color) - 1]);
    //     for (var v in 0 == t.length && (t = [100], u = ['rgba(10, 21, 30, 0.5411764705882353)'], $('.ball_holderG').addClass('move')), chart.data.datasets[0].data = t, chart.data.datasets[0].backgroundColor = u, chart.update(), $('.players-list').html(s), p.chances) $('.ball_holderG').removeClass('move');
    //     $('.chance-user img').click(function() {
    //         confirm('\u0412\u044B \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0445\u043E\u0442\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0437\u0430\u043F\u0440\u043E\u0441 \u043A\u043E\u043C\u0430\u043D\u0434\u043D\u043E\u0439 \u0438\u0433\u0440\u044B \u0438\u0433\u0440\u043E\u043A\u0443 #' + $(this).attr('data-user-id')) && $.ajax({
    //             url: '/sendMateNotify',
    //             type: 'post',
    //             data: {
    //                 room: roomID,
    //                 to: $(this).attr('data-user-id')
    //             },
    //             success: x => {
    //                 $.notify(x.msg, x.success ? 'success' : 'error')
    //             },
    //             error: x => {
    //                 $.notify('\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440!', 'error'), console.log(x.responseText)
    //             }
    //         })
    //     }), $('#colors').html(''), $('.game-price').text(numberFormat(p.price));
    //     var w = '';
    //     for (var v in p.bets) w += '<li> <color class="color_' + p.bets[v].color + '"></color><div class="user"><div class="ava"><img src="' + p.bets[v].user.avatar + '" alt=""></div><div class="info"><div class="nickname">' + p.bets[v].user.username + '</div><div class="points">\u041F\u043E\u0441\u0442\u0430\u0432\u0438\u043B: <span style="font-weight: bold;color: gold;">' + p.bets[v].price + '</span> <span class="fab fa-monero mgmoney"></span></div></div><div class="detail"><div class="percent">\u0411\u0438\u043B\u0435\u0442\u044B</div><div class="tickets">\u043E\u0442 #' + numberFormat(p.bets[v].from) + ' \u0434\u043E #' + numberFormat(p.bets[v].to) + '</div></div></div></li>';
    //     $('.bets-list').html(w)
    // }
}); 