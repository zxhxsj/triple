const wss = new WebSocket('wss://mg24.pw:8080/');

wss.onopen = () => {
    //$.notify('Соединение открыто!', 'success');
    if(user.id !== null) wss.send(JSON.stringify({
        action : 'register',
        user : user
    }));
}

wss.onclose = () => {
    //$.notify('Соединение закрыто!', 'error');
}

wss.onmessage = function(res) {
    //$.notify('Новое сообщение от канала!', 'info');
    res = JSON.parse(res.data);
    if(res.action == 'message') message(res);
    if(res.action == 'chat') parseChatMessages(res.messages);
    if(res.action == 'balance') updateBalance(res);
    if(res.action == 'online') 
    {
        $('.stater_1').text(res.count);
        //console.log(res);
    }
    if(res.action == 'bets') $('.jackpot-rooms').html(res.content);
    if(res.action == 'newGame') 
    {
        $('.jackpot-rooms').html(res.content);
        $('.stater_4').text(res.global.biggest);
        $('.stater_2').text(res.global.players);
        $('.stater_3').text(res.global.games);
        $('.stater_5').text(res.global.users);
    }
}



function message(res) {
    if(user.id != res.to) return;
    $.notify(res.msg, res.type);
}

function updateBalance(res) {
    if(user.id != res.user_id) return;
    //console.log(res);
    $('.update_balance').val(res.balance);
    $('.update_rate').val(res.rate);
}

// CHAT
$.ajax({
    url : '/chat/get',
    type : 'post',
    success : parseChatMessages,
    error : e => {
        $.notify('Ошибка при отправке данных на сервер!');
    }
});

function parseChatMessages(messages) {
    messages.sort((a,b) => {
        if(a.id > b.id) return 1;
        if(a.id < b.id) return -1;
        return 0;
    });

    //console.log(messages);
    
    let html = '';
    for(var i in messages)
    {
        let msg = messages[i];

        // chance #id to username
        if(msg.isAnswer) msg.message = msg.message.replace(msg.replace, ((msg.answerUser.id == user.id) ? '<span style="background: red;padding: 1px 6px;border-radius: 4px;">' + msg.answerUser.username + '</span>' : msg.answerUser.username));

        html += '<div class="item '+((msg.admin > 0) ? 'admin_' + msg.admin : '')+'" data-message-id="'+msg.id+'" data-user-id="'+msg.user+'">';
        html += '<div class="sub-heading clear">';
        html += '<div class="avatar"><img src="'+msg.avatar+'" alt=""></div>';
        html += '<div><a '+((msg.admin) ? 'style="color:gold;"' : '')+' class="name" href="https://vk.com/id'+msg.vk+'" target="_blank">'+msg.username+'</a>';
        if(user.perm > 0 && msg.user != 0) html += '<div class="chatButtons" style="float: left;margin-top: 6px;"><span class="deleteMessage" style="margin-left: 5px; color : #d88f8f;"><i class="fa fa-times" aria-hidden="true"></i></span><span class="banUser" style="margin-left:5px; color : #ff5858;"><i class="fa fa-ban" aria-hidden="true"></i></span></div>';
        html += '</div>';
        html += '<div class="id"><span>'+((msg.user) ? msg.user : '')+'</span></div></div>';
        html += '<div class="text" data-user-id="'+msg.user+'" style="cursor:pointer;" title="Нажмите, чтобы ответить">'+msg.message+'</div>';
        html += '</div>';
    }

    $('.chat-messages').html(html).animate({
        scrollTop: $('.chat-messages')[0].scrollHeight
    }, 0);

    if(user.perm > 0) $('.deleteMessage').click(function() {
        $.ajax({
            url: '/chat/delete',
            type: 'post',
            data: {
                msg_id: $(this).parent().parent().parent().parent().attr('data-message-id')
            },
            success: e => $.notify(e.msg, (e.success) ? 'success' : 'error'),
            error: e => $.notify('Ошибка при отправке данных на сервер!', 'error')
        })
    });

    if(user.perm > 0) $('.banUser').click(function() {
        var reason = prompt('Причина блокировки', ''),
            time = prompt('Укажите время блокировки (в минутах, 0 = навсегда)');
        if(isNaN(parseInt(time))) return $.notify('Вы не указали время блокировки!', 'error');
        $.ajax({
            url : '/chat/ban',
            type : 'post',
            data : {
                user_id : $(this).parent().parent().parent().parent().attr('data-user-id'),
                reason : reason,
                time : time
            },
            success : e => $.notify(e.msg, (e.success) ? 'success' : 'error'),
            error : e => $.notify('Ошибка при отправке данных на сервер!', 'error')
        });
    });

    $('.chat-messages .text').click(function() {
        $('#sendie').val('#' + $(this).attr('data-user-id') + ', ');
        $('#sendie').focus();
    });
}

function sendMessage() {
    let sendieValue = $('#sendie').val();
    $('#sendie').val('');
    $.ajax({
        url: '/chat/sendMessage',
        type: 'post',
        data: {
            msg: sendieValue
        },
        success: c => $.notify(c.msg, c.success ? 'success' : 'error'),
        error: c => $.notify('Ошибка при отправке данных на сервер!')
    });
}

$('#sendie').keypress(function(c) {
    13 == c.keyCode && (c.preventDefault(), sendMessage())
});
$('.chat-send').click(sendMessage);

$('#open_ch').click(() => {
    $('.cha').slideDown(400);
    $('#open_ch').hide();
    $('#close_ch').show();
    localStorage.setItem('chat', 1);
});

$('#close_ch').click(() => {
    localStorage.setItem('chat', 0);
    $('.cha').slideUp(400);
    $('#close_ch').hide();
    $('#open_ch').show();
});

if(localStorage.getItem('chat') == 0)
{
    $('#close_ch').hide();
    $('#open_ch').show();
} else {
    $('#open_ch').hide();
    $('#close_ch').show();
}

// CHANGE USERNAME
$('#rename').click(function() {
    $.ajax({
        url: '/changeUsername',
        type: 'post',
        data: {
            username: $('.newUsername').val()
        },
        success: e => {
            $.notify(e.msg, e.success ? 'success' : 'error');
            if(!e.success) return;
            $('.popup, .overlay, body').removeClass('active');
            $('.mynickname').text(e.username);
        },
        error: e => $.notify('Ошибка при отправке данных на сервер!', 'error')
    });
});

// TOOLTIPSTERS
$('.players-percent-block').tooltipster({
    side: 'bottom',
    theme: 'tooltipster-borderless'
});

$('#winavatar, #winidrest').tooltipster({
    contentAsHTML: !0,
    interactive: !0,
    content: $('.tooltip_content').html(),
    side: 'bottom',
    theme: 'tooltipster-borderless'
})

// OTHER FUNCTIONS
window.random = (c, d) => {
    return Math.floor(Math.random() * (d + 1 - c)) + c
}

window.numberFormat = function(c) {
    beforeDot = Math.floor(c).toFixed(0), afterDot = (c - beforeDot).toFixed(2).replace('0.', ''), array = [], count = 0;
    for (var d = 0; d < beforeDot.length; d++) Math.floor(count / 3) == count / 3 && 0 < count && array.push(' '), array.push(beforeDot[beforeDot.length - d - 1]), count++;
    string = '';
    for (var d = 0; d < array.length; d++) string += array[array.length - d - 1];
    return string + ('00' == afterDot ? '' : '.' + afterDot)
}