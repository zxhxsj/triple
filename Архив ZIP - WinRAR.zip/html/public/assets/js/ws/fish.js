$(document).ready(() => {
  const e = io.connect('https://m24.pw:2083');

  const Audios = {
    FishLose: new Audio('../public/assets/sounds/fish_lose.mp3'),
    FishWin: new Audio('../public/assets/sounds/fish_wins.mp3'),
    FishZakid: new Audio('../public/assets/sounds/fish_zakid.mp3'),
    FishTyanet: new Audio('../public/assets/sounds/fish_tyanet.mp3'),
    FishMenu: new Audio('../public/assets/sounds/fish_menu.mp3'),
    FishMenu2: new Audio('../public/assets/sounds/fish_menu2.mp3') 
  }

  var i = $.cookie('sounds');
  if (i == undefined) i = 'on';

  window.Audios = Audios;

  Audios.FishMenu.oncanplaythrough = () => {
    Audios.FishMenu.play();
  }

  Audios.FishMenu.onended = () => {
    Audios.FishMenu.currentTime = 0;
    Audios.FishMenu.play();
  }
  $('#open_chm').click((p) => {
    p.preventDefault(); 
    $('#open_chm').addClass('hidden');
    $('#close_chm').removeClass('hidden');
    i = 'on';
    $.cookie('sounds', 'on', {expires: 365});
    for(let i in Audios) Audios[i].volume = (i == 'FishWin' || i == 'FishLose') ? 0.3 : 1;
  });

  $('#close_chm').click(function(p) {
    p.preventDefault();
    $('#open_chm').removeClass('hidden');
    $('#close_chm').addClass('hidden');
    i = 'off';
    $.cookie('sounds', 'off', {expires: 365});
    for(let i in Audios) Audios[i].volume = 0;
  });

  if(i == 'on')
  {
    $('#open_chm').addClass('hidden');
    $('#close_chm').removeClass('hidden');
    for(let i in Audios) Audios[i].volume = (i == 'FishWin' || i == 'FishLose') ? 0.3 : 1;
  } else {
    $('#open_chm').removeClass('hidden');
    $('#close_chm').addClass('hidden');
    for(let i in Audios) Audios[i].volume = 0;
  }

//   'on' == i ? ($('#open_chm').addClass('hidden'), $('#close_chm').removeClass('hidden')) : ($('#open_chm').removeClass('hidden'), $('#close_chm').addClass('hidden')), 
//   $('#open_chm').click(function(p) {
//     p.preventDefault(), $('#open_chm').addClass('hidden'), $('#close_chm').removeClass('hidden'), i = 'on', $.cookie('sounds', 'on', {
//         expires: 365
//     });
//     for(let i in Audios) Audios[i].volume = 1;
// }), $('#close_chm').click(function(p) {
//     p.preventDefault(), $('#open_chm').removeClass('hidden'), $('#close_chm').addClass('hidden'), i = 'off', $.cookie('sounds', 'off', {
//         expires: 365
//     });
//     for(let i in Audios) Audios[i].volume = 0;
// });

  e.on('fishing', (res) => {
    let html = '<tr><td><div class="id ok"><a href="https://vk.com/id'+res.game.user.vk+'" target="_blank">'+res.game.user.username+'</a></div></td><td><div class="sum dec">-'+res.game.bet+'</div></td><td><div class="system rate">x'+res.game.multiplier.toFixed(2)+'</div></td><td><div class="status '+((res.game.result > 1) ? 'ok' : 'dec')+'">'+((res.game.result > 0) ? '+' : '')+''+parseFloat(res.game.result.toFixed(2))+' <span class="fab fa-monero mgmoney"></span></div></td></tr>';
    $('#FishHistory').prepend(html);
    
    let items = $('#FishHistory').find('tr');
    for(let i = 0; i < items.length; i++) if(i > 9) $(items[i]).remove();

    $('.stater_4').text(res.global.biggest);
    $('.stater_2').text(res.global.players);
    $('.stater_3').text(res.global.games);
    $('.stater_5').text(res.global.users);
  });

  let _lineCicle = 0,
      _lineInterval = null,
      _canClick = false,
      _fishReverse = false;

  // let _gameStatus = 0,
    let line = 50,
        fish = 70,
        currentFish = 0;

    window._gameStatus = 0;



  $.ajax({
    url: '/fish/get',
    type: 'post',
    success: r => {
      if(r.success)
      {
        _gameStatus = 1;
        ShowLine();
        setTimeout(StartLine, Math.floor(Math.random()*4000)+1000);
      }
      changeStatus(_gameStatus);
    }
  });

  window.changeText = (m) => {
    $('.fish-text').hide();
    $('#fishing' + m).show();
  }

  window.changeStatus = (s) => {
    console.log(s);
    if(s == 0)
    {
      // нет игры
      $('.FishInput').show();
      $('#FishPlay').show();
      $('#FishGrap').hide();
      changeText(0);
    } else {
      $('.FishInput').hide();
      $('#FishPlay').hide();
      $('#FishGrap').show();
      changeText(3);
    }
  }

  window.StopLine = () => {
    $('.fish-progress').hide();
    $('.fish-p').hide();
    $('.fish-fish').hide();
    $('.fish-ul').hide();
    clearInterval(MouseDownInterval);
    changeText(0);
    Play();
  }

  window.Play = function() {
    let _data = {};
    if(_gameStatus)
    {
      _data.line = line;
      _data.fish = fish;
      _data.sign = window.btoa('l#' + line + '&F#' + fish);
    } else {
      _data.amount = parseFloat($('#FishAmount').val()) || 0;
    }

    $.ajax({
      url: location.pathname + '/play',
      type: 'post',
      data: _data,
      success: r => {
        if(r.type == 'line')
          {
            ShowLine();
            setTimeout(StartLine, Math.floor(Math.random()*4000)+1000);
            _gameStatus = 1;
          } else if(r.type == 'new') {
            _gameStatus = 0;

            console.log(r);

            $('#fish_img').attr('src', r.result.fish.img);
            $('#fish_name').text(r.result.fish.name);

            $('.overlay, body, .popup.fishwin').addClass('active');

            $('#fish_x').prop('number', 0).animate({
              num: 0
            }, {
              duration: 1,
              step: function(num) {
                this.innerHTML = 'x' + num.toFixed(2);
              }
            });

            $('#fish_rate').prop('number', 0).animate({
              num: 0
            }, {
              duration: 1,
              step: function(num) {
                this.innerHTML = '<span style="font-weight:bold;color:gold;font-size: 25px;color:darkorange;"><i class="fas fa-trophy" ></i> '+((r.result.result > 0) ? num.toFixed(0) : 0)+'</span>';
              }
            });

            $('#fish_win').prop('number', 0).animate({
              num: 0
            }, {
              duration: 1,
              step: function(num) {
                this.innerHTML = '<span style="font-weight:bold;color:gold;font-size: 25px;"><i class="fab fa-monero mgmoney"></i> '+((r.result.result > 0) ? num.toFixed(2) : 0)+'</span>';
              }
            });

            setTimeout(() => {
              $('#fish_x').prop('number', 0).animate({
                num: r.result.multiplier
              }, {
                duration: 5000,
                step: function(num) {
                  this.innerHTML = 'x' + num.toFixed(2);
                }
              });

              $('#fish_rate').prop('number', 0).animate({
                num: r.result.result
              }, {
                duration: 5000,
                step: function(num) {
                  this.innerHTML = '<span style="font-weight:bold;color:gold;font-size: 25px;color:darkorange;"><i class="fas fa-trophy" ></i> '+((r.result.result > 0) ? num.toFixed(0) : 0)+'</span>';
                }
              });

              $('#fish_win').prop('number', 0).animate({
                num: r.result.result
              }, {
                duration: 5000,
                step: function(num) {
                  this.innerHTML = '<span style="font-weight:bold;color:gold;font-size: 25px;"><i class="fab fa-monero mgmoney"></i> '+((r.result.result > 0) ? num.toFixed(2) : 0)+'</span>';
                }
              });
            }, 50);
          } else {
            _gameStatus = 0;
            $('.fish-p, .fish-progress').hide();
          }
          $.notify(r.msg, (r.success) ? 'success' : 'error');
          changeStatus(_gameStatus);
          console.log(r.type);
        },
        error: e => {
          $.notify('Whoops... Looks like something wrong!', 'error');
          console.log(e.responseText);
        }
    });
  }

  window.ShowLine = () => {
    fish = 70;
    line = 50;
    currentFish = 0;
    $('.fish-back').css('transition', 'width 0s');
    $('.fish-back').css('width', '50%');
    $('.fish-back').css('transition', 'width 0.4s linear');
    $('.fish-fish img').css('transform', 'rotateY(0deg)');
    $('.fish-fish img').css('transition', 'margin-left 0s linear');
    $('.fish-fish img').css('margin-left', fish + '%');
    $('.fish-fish img').css('transition', 'margin-left 0.4s linear');
    $('.fish-fish img').hide();
    $('.fish-progress').show();
    $('.fish-p').show();
    $('.fish-ul').show();
    $('.fish-fish').show();
    changeText(2);
    Audios.FishZakid.play();
  }

  let MouseDown = false, MouseDownTime = 0, MouseDownInterval = false;

  $('#FishGrap').mousedown(() => {
    if(!_canClick) return;
    MouseDown = true;
    MouseDownTime = new Date().getTime();
    line -= 5;
    $('.fish-back').css('width', line + '%');
    _fishReverse = false;
    _lineCicle = 0;
    $('.fish-fish img').css('transform', 'rotateY(0deg)');
    changeText(2);
    MouseDownInterval = setInterval(() => {
      line -= 10;
      $('.fish-back').css('width', line + '%');
      _fishReverse = false;
      _lineCicle = 0;
      $('.fish-fish img').css('transform', 'rotateY(0deg)');
      changeText(2);
    }, 400);
  });

  $('#FishGrap').mouseup(() => {
    MouseDown = false;
    MouseDownTime = 0;
    clearInterval(MouseDownInterval);
  });

  $('#FishGrap').click(() => {
    return;
    if(!_canClick) return;
    line -= 5;
    $('.fish-back').css('width', line + '%');
    _fishReverse = false;
    _lineCicle = 0;
    $('.fish-fish img').css('transform', 'rotateY(0deg)');
    changeText(2);
  });

  $('#FishPlay').click(Play);

  window.StartLine = () => {
    changeText(2);
    _canClick = true;
    _lineCicle = 0;
    $('.fish-fish img').show();
    _lineInterval = setInterval(() => {
      if(_lineCicle >= 3) 
      {
        _fishReverse = true;
        $('.fish-fish img').css('transform', 'rotateY(180deg)');
        changeText(1);
      }
      _lineCicle++;
      if(fish < -95) 
      {
        clearInterval(_lineInterval);
        _canClick = false;
        Audios.FishWin.play();
        return StopLine();
      }

      if(fish > 95)
      {
        clearInterval(_lineInterval);
        _canClick = false;
        // $.notify('Леска порвалась!', 'error');
        Audios.FishLose.play();
        return StopLine();
      }

      line += 5;
      $('.fish-back').css('width', line + '%');
      if(line > 95 || line < 5) 
      {
        clearInterval(_lineInterval);
        // $.notify((line > 95) ? 'Недотянул' : 'Перетянул', 'error');
        _canClick = false;
        Audios.FishLose.play();
        return StopLine();
      }
      if(_fishReverse) {
        fish += ((line)/100)*6;
        currentFish -= ((line)/100)*6;
      } else {
        fish -= ((100-line)/100)*6;
        currentFish += ((100-line)/100)*6;
      } 
      $('.fish-fish img').css('margin-left', fish + '%');
      $('.fish-p').text('Цель ('+((currentFish/170)*100).toFixed(2)+'%)');

    }, 400);
  }
});