$(document).ready(() => {
   // const wss = new WebSocket('wss://mg24.pro:8080/');

   // wss.onopen = () => {
        //$.notify('Соединение демона установлено!', 'info');
   // }
    
   // wss.onclose = () => {
        //$.notify('Соединение демона потеряно!', 'error');
   // }

    var o = document.getElementById('circle').getContext('2d');
    o.canvas.width = 100, o.canvas.height = 100, window.chart = new Chart(o, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                label: '# of Votes',
                data: [70, 30],
                backgroundColor: ['#f4f6ec', '#000000'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: !0,
            cutoutPercentage: 75,
            legend: {
                display: !1
            },
            tooltips: {
                enabled: !1
            }
        }
    });
});