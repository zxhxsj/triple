var admin;
var name;
name = "Василий";
name = admin;
alert(admin);