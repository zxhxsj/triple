window.numberFormat = function(c) {
    beforeDot = Math.floor(c).toFixed(0), afterDot = (c - beforeDot).toFixed(2).replace('0.', ''), array = [], count = 0;
    for (var d = 0; d < beforeDot.length; d++) Math.floor(count / 3) == count / 3 && 0 < count && array.push(' '), array.push(beforeDot[beforeDot.length - d - 1]), count++;
    string = '';
    for (var d = 0; d < array.length; d++) string += array[array.length - d - 1];
    return string + ('00' == afterDot ? '' : '.' + afterDot)
};
const socket = io.connect('https://m24.pw:2083');
socket.on('chat', c => {
    parseChat(c.messages)
}), socket.on('updateBalance', c => {
    c.user_id == user.id && ($('.update_balance').val(c.balance), $('.update_rate').val(c.rate))
}), null != user.id && socket.emit('registerUser', user), socket.on('message', c => {
    c.to != user.id || $.notify(c.msg, c.type)
}), socket.on('online', c => {
    $('.stater_1').text(c)
}), socket.on('bets', c => {
    $('.jackpot-rooms').html(c.content)
}), socket.on('newGame', c => {
    $('.jackpot-rooms').html(c.content), $('.stater_4').text(c.global.biggest), $('.stater_2').text(c.global.players), $('.stater_3').text(c.global.games), $('.stater_5').text(c.global.users)
}), window.random = (c, d) => {
    return Math.floor(Math.random() * (d + 1 - c)) + c
}, window.sendMessage = function() {
    sendieValue = $('#sendie').val(), $('#sendie').val(''), $.ajax({
        url: '/chat/sendMessage',
        type: 'post',
        data: {
            msg: sendieValue
        },
        success: c => {
            $.notify(c.msg, c.success ? 'success' : 'error')
        },
        error: c => {
            console.log(c.responseText)
        }
    })
}, $(document).ready(() => {
    $('#winavatar, #winidrest').tooltipster({
        contentAsHTML: !0,
        interactive: !0,
        content: $('.tooltip_content').html(),
        side: 'bottom',
        theme: 'tooltipster-borderless'
    }), 0 == localStorage.getItem('chat') ? ($('#close_ch').hide(), $('#open_ch').show()) : ($('#open_ch').hide(), $('#close_ch').show()), $('#close_ch').click(() => {
        localStorage.setItem('chat', 0), $('.cha').slideUp(400), $('#close_ch').hide(), $('#open_ch').show()
    }), $('#open_ch').click(() => {
        $('.cha').slideDown(400), $('#open_ch').hide(), $('#close_ch').show(), localStorage.setItem('chat', 1)
    }), $('#sendie').keypress(function(c) {
        13 == c.keyCode && (c.preventDefault(), sendMessage())
    }), $('.chat-send').click(sendMessage), $('.players-percent-block').tooltipster({
        side: 'bottom',
        theme: 'tooltipster-borderless'
    }), $.ajax({
        url: '/chat/get',
        type: 'post',
        success: parseChat,
        error: c => {
            console.log(c.responseText), $.notify('\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440!', 'error')
        }
    }), $('#rename').click(async () => {
        checkTime() && $.ajax({
            url: '/changeUsername',
            type: 'post',
            data: {
                username: $('.newUsername').val()
            },
            success: c => {
                $.notify(c.msg, c.success ? 'success' : 'error'), $('.popup, .overlay, body').removeClass('active'), c.success && $('.mynickname').text(c.username)
            },
            error: c => {
                $.notify('\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440!', 'error'), console.log(c.responseText)
            }
        })
    })
}), window.parseChat = c => {
        c.sort((k, l) => {
            return k.id < l.id ? -1 : l.id < k.id ? 1 : 0
        });
        var d = '';
        for (var f in c) {
            c[f].isAnswer && (replace = user.id == c[f].answerUser.id ? '<span style="background: red;padding: 1px 6px;border-radius: 4px;">' + c[f].answerUser.username + '</span>' : c[f].answerUser.username, c[f].message = c[f].message.replace(c[f].replace, replace));
            var g = 0 < user.perm ? 'data-message-id="' + c[f].id + '" data-user-id="' + c[f].user + '"' : '';
            h = 0 < user.perm && 0 < c[f].vk ? '<div class="chatButtons" style="float: left;margin-top: 6px;"><span class="deleteMessage" style="margin-left: 5px; color : #d88f8f;"><i class="fa fa-times" aria-hidden="true"></i></span><span class="banUser" style="margin-left:5px; color : #ff5858;"><i class="fa fa-ban" aria-hidden="true"></i></span></div>' : '';
            j = (0 < c[f].user ? c[f].user : '');
            // d += ' <div class="message" ' + g + '> <div class="item ' + (0 < c[f].admin ? 'admin_' + c[f].admin : '') + '"> <div class="sub-heading clear"> <div class="avatar"><img src="' + c[f].avatar + '" alt=""></div><div class="name" ' + (0 < c[f].admin ? 'style="color:gold;"' : '') + '><a href="' + (0 == c[f].vk_id ? '' : 'https://vk.com/id' + c[f].vk) + '" target="_blank" style="float:left;"><span style="max-width: 120px;overflow: hidden;display: block;float: left;white-space: nowrap;text-overflow: ellipsis;">' + c[f].username + '</span></a>' + h + '</div>' + j + '</div><div class="text" data-user-id="' + c[f].user + '" style="cursor:pointer;" title="Нажмите, чтобы ответить">' + c[f].message + '</div></div></div>'
            d += '<div class="item ' + ((c[f].admin > 0) ? 'admin_' + c[f].admin : 'user_0') + '" id="chatm_1539585226" '+g+'><div class="sub-heading clear"><div class="avatar"><img src="' + c[f].avatar + '" alt=""></div><div onclick="var u = $(this); $(".chat-input").val(u.text());"><a ' + (0 < c[f].admin ? 'style=""' : '') + 'class="name" href="' + (0 == c[f].vk_id ? '' : 'https://vk.com/id' + c[f].vk) + '" target="_blank">' + c[f].username + '</a>'+h+'</div><div class="id"><span>' + j + '</span></div></div><div class="text" data-user-id="' + c[f].user + '" style="cursor:pointer;" title="Нажмите, чтобы ответить">' + c[f].message + '</div></div>';
        }
        $('.chat-messages')
            .html(d), $('.chat-messages')
            .animate({
                scrollTop: $('.chat-messages')[0].scrollHeight
            }, 400), $('.deleteMessage')
            .click(function() {
                $.ajax({
                    url: '/chat/delete',
                    type: 'post',
                    data: {
                        msg_id: $(this)
                            .parent()
                            .parent()
                            .parent()
                            .parent()
                            .attr('data-message-id')
                    },
                    success: k => {
                        $.notify(k.msg, k.success ? 'success' : 'error')
                    },
                    error: k => {
                        console.log(k.responseText), $.notify('Ошибка при отправке данных на сервер!', 'error')
                    }
                })
            }), $('.banUser')
            .click(function() {
                var k = prompt('Причина блокировки', '');
                var time = prompt('Укажите время время блокировки (в минутах, 0 = навсегда)');
                return 1 > k.length ? $.notify('Вы не указали причину блокировки!', 'error') : void $.ajax({
                    url: '/chat/ban',
                    type: 'post',
                    data: {
                        user_id: $(this)
                            .parent()
                            .parent()
                            .parent()
                            .parent()
                            .attr('data-user-id'),
                        reason: k,
                        time: time
                    },
                    success: l => {
                        $.notify(l.msg, l.success ? 'success' : 'error')
                    },
                    error: l => {
                        console.log(l.responseText), $.notify('Ошибка при отправке данных на сервер!', 'error')
                    }
                })
            }), $('.chat-messages .text')
            .click(function() {
                $('#sendie')
                    .val('#' + $(this)
                        .attr('data-user-id') + ', '), $('#sendie')
                    .focus()
            })
    };
