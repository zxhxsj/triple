/*
 *
 * @licstart  The following is the entire license notice for the JavaScript
 * code in this file.
 * (c) 2018 MultiGame Corp. [https://mg24.pro]
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 *
 * @licend  The above is the entire license notice for the JavaScript code
 * in this file.
 *
 */
$(document).ready(function(e) {
	var isMobile = {
		Android: function() {
			return navigator.userAgent.match(/Android/i);
		},
		BlackBerry: function() {
			return navigator.userAgent.match(/BlackBerry/i);
		},
		iOS: function() {
			return navigator.userAgent.match(/iPhone|iPad|iPod/i);
		},
		Opera: function() {
			return navigator.userAgent.match(/Opera Mini/i);
		},
		Windows: function() {
			return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
		},
		any: function() {
			return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
		}
	}
	$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
	$('.tooltip').tooltipster({
		side: 'bottom',
		theme: 'tooltipster-borderless'
	});
	$('.chances').kinetic({
		filterTarget: function(target, e){
			if (!/down|start/.test(e.type)){
				return !(/area|a|input/i.test(target.tagName));
			}
		}
	});
	$('#accordion').accordion({
		heightStyle: 'content'
	});
	$('.btn-toggle-menu').click(function(e) {
        $('.fixed-nav, .main-width').css({transition: 'all .5s ease'});
        if ($(this).is('.active')) {
            $('.main-width').removeClass('hide-menu');
			$('.fixed-nav .buttons .dep').html('Пополнить');
			$('.fixed-nav .buttons .with').html('Вывод');
            $('.fixed-nav, .btn-toggle-menu').removeClass('active');
            $.removeCookie('fixed-nav', {
                path: '/'
            });
        } else {
            $('.main-width').addClass('hide-menu');
			$('.fixed-nav .buttons .dep').html('+');
			$('.fixed-nav .buttons .with').html('-');
            $('.fixed-nav, .btn-toggle-menu').addClass('active');
            $.cookie('fixed-nav', 'true', {
                expires: 7,
                path: '/'
            });
        }
        return false;
    });
	$('.btn-toggle3').click(function(e) {
        $('.fixed-chat, .main-width').css({transition: 'all .5s ease'});
        if ($('.fixed-chat').is('.hide')) {
            $('.fixed-chat, .main-width').removeClass('hide');
            $.removeCookie('fixed-chat', {
                path: '/'
            });
        } else {
            $('.fixed-chat, .main-width').addClass('hide');
            $.cookie('fixed-chat', 'true', {
                expires: 7,
                path: '/'
            });
        }
        return false;
    });
	if(!isMobile.any()) {
		if($.cookie('fixed-nav')) {
			$('.main-width').addClass('hide-menu');
			$('.fixed-nav .buttons .dep').html('+');
			$('.fixed-nav .buttons .with').html('-');
			$('.fixed-nav, .btn-toggle-menu').addClass('active');
		}
		if ($.cookie('fixed-chat')) {
			$('.fixed-chat, .main-width').addClass('hide');
		}
	}
	$('.scroller').slimScroll({
	    size: '5px',
		start: 'bottom',
	    height: 'auto'
	});
	$(window).resize(function(e) {
		$('.scroller').slimScroll({'destroy':true});
     	$('.scroller').slimScroll({
		    size: '5px',
			start: 'bottom',
		    height: 'auto'
		});   
    });
	$(window).resize();
	$('.close').click(function(e) {
        $('.popup, .overlay, body').removeClass('active');
		return false;
    });
	$('.overlay').click(function(e) {
        var target = e.target || e.srcElement;
		if(!target.className.search('overlay')) {
			$('.overlay, .popup, body').removeClass('active');
		} 
    });	
	$('[rel=popup]').click(function(e) {
    	showPopup($(this).attr('data-popup'));
		return false
    });
	// $('.list-pay .item').click(function(e) {
    //     if(!$(this).is('.active')) {
	// 		$(this).parent().find('.item').removeClass('active');
	// 		$(this).addClass('active');
	// 		checkSystem();
	// 		// calcSum();
	// 	}
    // });
	// $('#value').on('change keydown paste input', function() {
	// 	// calcSum();
	// });
	// function calcSum() {
    //     if($('.list-pay .active').data('type') == 'qiwi') {
    //         var perc = 4;
    //         var com = 1;
    //         var min = 1000;
    //         if(youtuber == '1') {
    //             var perc = 0;
    //             var com = 0;
    //             var min = 1000;
    //         }
    //         $('#com').html(perc + '% + ' + com + 'руб.');
    //     } else if($('.list-pay .active').data('type') == 'yandex') {
    //         var perc = 0;
    //         var com = 0;
    //         var min = 100;
    //         if(youtuber == '1') {
    //             var perc = 0;
    //             var com = 0;
    //             var min = 100;
    //         }
    //         $('#com').html(perc + '%');
    //     } else if($('.list-pay .active').data('type') == 'webmoney') {
    //         var perc = 6;
    //         var com = 0;
    //         var min = 100;
    //         if(youtuber == '1') {
    //             var perc = 0;
    //             var com = 0;
    //             var min = 100;
    //         }
    //         $('#com').html(perc + '%');
    //     } else if($('.list-pay .active').data('type') == 'visa') {
    //         var perc = 4;
    //         var com = 50;
    //         var min = 10000;
    //         if(youtuber == '1') {
    //             var perc = 0;
    //             var com = 0;
    //             var min = 1000;
    //         }
    //         $('#com').html(perc + '% + ' + com + 'руб.');
    //     }
    //     var val = $('#value').val();
    //     var comission = (val-(min/100*perc)-com)/10;
    //     if(!val) comission = 0;
    //     if(comission <= 1) comission = 0;
    //     $('#valwithcom').html(comission + ' руб.');
    // }
	// $('#chh').click(function() {
    //     $('#chh').attr('checked', 'checked');
    //     if($(this).prop('checked') == true){
    //         $('#withdraw').removeAttr('disabled');
    //     } else {
    //         $('#withdraw').attr('disabled', 'false');
    //         $('#chh').removeAttr('checked');
    //     }
    // });
	// function checkSystem() {
	// 	if($('.list-pay .active').data('type') == 'qiwi') {
    //         var perc = 4;
    //         var com = 1;
    //         var val = 1000;
    //         // if(youtuber == '1') {
    //         //     var perc = 0;
    //         //     var com = 0;
    //         //     var val = 1000;
    //         // }
    //         var comission = (val+(val/100*perc)+com*10);
    //         $('#min_wid').html(comission);
    //         $('#value').attr('placeholder', 'Мин. сумма: ' + comission + ' монет');
    //         $('#wallet').attr('placeholder', '7900xxxxxxx');
    //         $('#com').html(perc + '% + ' + com + 'руб.');
    //     } else if($('.list-pay .active').data('type') == 'yandex') {
    //         var perc = 0;
    //         var com = 0;
    //         var val = 100;
    //         // if(youtuber == '1') {
    //         //     var perc = 0;
    //         //     var com = 0;
    //         //     var val = 100;
    //         // }
    //         var comission = (val+(val/100*perc)+com*10);
    //         $('#min_wid').html(comission);
    //         $('#value').attr('placeholder', 'Мин. сумма: ' + comission + ' монет');
    //         $('#wallet').attr('placeholder', '41001хххххххххх');
    //         $('#com').html(perc + '%');
    //     } else if($('.list-pay .active').data('type') == 'webmoney') {
    //         var perc = 6;
    //         var com = 0;
    //         var val = 100;
    //         // if(youtuber == '1') {
    //         //     var perc = 0;
    //         //     var com = 0;
    //         //     var val = 100;
    //         // }
    //         var comission = (val+(val/100*perc)+com*10);
    //         $('#min_wid').html(comission);
    //         $('#value').attr('placeholder', 'Мин. сумма: ' + comission + ' монет');
    //         $('#wallet').attr('placeholder', 'R536xxxxxxxxx');
    //         $('#com').html(perc + '%');
    //     } else if($('.list-pay .active').data('type') == 'visa') {
    //         var perc = 4;
    //         var com = 50;
    //         var val = 10000;
    //         // if(youtuber == '1') {
    //         //     var perc = 0;
    //         //     var com = 0;
    //         //     var val = 10000;
    //         // }
    //         var comission = (val+(val/100*perc)+com*10);
    //         $('#min_wid').html(comission);
    //         $('#value').attr('placeholder', 'Мин. сумма: ' + comission + ' монет');
    //         $('#wallet').attr('placeholder', '4700xxxxxxxxxxxx');
    //         $('#com').html(perc + '% + ' + com + 'руб.');
    //     }
    // }
	// $('#wallet').keydown(function(event) {
	// 	if (event.shiftKey === true) return false;
    //     if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || 
    //        (event.keyCode == 65 && event.ctrlKey === true) || 
    //        (event.keyCode >= 35 && event.keyCode <= 39)) {
    //              return;
    //     } else {
    //         if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 ) && (event.keyCode < 65 || event.keyCode > 90 )) {
    //             event.preventDefault(); 
    //         }   
    //     }
    // });
	// $('#withdraw').click(function(){
	// 	var system = $('.list-pay .active').attr('data-type');
	// 	var value = $('#value').val();
	// 	var wallet = $('#wallet').val();
	// 	if(!$('#chh').attr('checked')) {
	// 		$.notify({
	// 			position : 'top-right',
	// 			type: 'error',
	// 			message: 'Вы не подтвердили правильность введенных даных'
	// 		});
	// 		return false;
	// 	}
	// 	$.ajax({
    //         url : '/withdraw',
    //         type : 'post',
    //         data : {
    //             system : system,
    //             value : value,
	// 			wallet : wallet
    //         },
	// 		success : function(data) {
	// 			$('.popup, .overlay, body').removeClass('active');
	// 			$.notify({
    //                 position : 'top-right',
    //                 type: data.type,
    //                 message: data.msg
    //             });
	// 	        return false;
	// 		},
    //         error : function(data) {
    //             console.log(data.responseText);
    //         }
    //     });
	// });
	$('.cont-a .rooms .room:first').addClass('active');
	$('.cont-a .historyTable:first').addClass('active');
	$('.cont-a .rooms .room').click(function(e) {
        if(!$(this).is('.active')) {
			$('.cont-a .rooms .room, .historyTable').removeClass('active');
			$(this).addClass('active');
			$('.historyTable:eq('+$(this).index()+')').addClass('active');
		}	
    });
	// var socket = io.connect(':8080');
	// $('.scroller').scrollTop(1e7);
	// socket.on('message', function(msg) {
        // if(USER_ID == msg.user) {
			// $.notify({
				// position : 'top-right',
				// type: msg.type,
				// message: msg.msg
			// });
        // }
    // });
	socket.on('updateBalance', function(data) {
        if(USER_ID == data.id) $('.money').text(data.balance);
        if(USER_ID == data.id) $('#money').val(data.balance);
    });
	socket.on('online', function(data) {
        $('.on').text(data); 
    });
	socket.on('chat', function (data) {
		msg = JSON.parse(data);
		var chat = $('.messages');
		/* ban panel */
		if(admin == 1) {
			var ban = 'onclick="var u = $(this); $(\'.chat-input\').val(\'/ban \' + u.text() + \' \'); return false;"';
			var panel = '<a class="delete" onclick="chatdelet('+ msg.time2 +')"><i class="far fa-times-circle"></i></a>';
		} else {
			var ban = '';
			var panel = '';
		}
		var name = msg.username;
        if(msg.admin) {
            name = '<span style="color:#ff5722;">[Администратор]</span>';
        }
        if(msg.moder) {
            name = '<span style="color:#4caf50;">[Модератор]</span> ' + msg.username;
        }
        // if(msg.youtuber) {
        //     name = '<span style="color:#ffc107;">[YouTube`r]</span> ' + msg.username;
        // }
		var messages = msg.messages;
		chat.find('.scroller').append(
			'<div class="item" id="chatm_' + msg.time2 + '">' +
            	'<div class="sub-heading clear">' +
            		'<div class="avatar"><img src="' + msg.avatar + '" alt=""></div>' +
                    '<div class="name" onclick="var u = $(this); $(\'.chat-input\').val(u.text() + \', \'); return false;">' + name + '</div>' +
                    '<div class="date"><span '+ ban +'>' + msg.user_id + '</span> ' + panel +'</div>' +
                '</div>' +
                '<div class="text">' + messages + '</div>' +
            '</div>');
		$('.scroller').scrollTop(1e7);
		if($('.item').length >= 20) $('.item:nth-child(1)').remove();
	});
	socket.on('chatdel', function (data) {
		info = JSON.parse(data);
		$('#chatm_' + info.time2).remove();
	});
	socket.on('clear', function (data) {
		$('.scroller').html('');
	});
	socket.on('bonus', function (data) {
		if(USER_ID == data.user_id) {
			var line = '';
			for(var i = 0; i < data.line.length; i++) line += '<li><div class="sum">' + data.line[i].sum + '</div><div class="background" style="background: #' + data.line[i].color + '"></div><div class="bottom" style="background: #' + data.line[i].color + '">'+ declOfNum(data.line[i].sum, ['монета','монеты','монет'])+'</div></li>';
			$('#bonus_carousel').html(line);
			$('#bonus_carousel').css({
				transform: 'translate3d(-' + data.ml + 'px, 0px, 0px)',
				transition: 7000 + 'ms cubic-bezier(0.32, 0.64, 0.45, 1)'
			});
			setTimeout(function () {
				$('.line .cooldown').show();
			}, 7200);
		}
	});
	$('.chat-input').bind("enterKey", function (e) {
        var input = $(this);
        var msg = input.val();
        if (msg != '') {
            $.post('/chat', {messages: msg}, function (data) {
                if (data) {
                    if (data.status == 'success') {
                        input.val('');
                    } else {
						input.val('');
                    }
                    $.notify({
                        position : 'top-right',
                        type: data.status,
                        message: data.message
                    });
                }
                else
                    input.val('');
            });
        }
    });
    $('.chat-input').keyup(function (e) {
        if (e.keyCode == 13) {
            $(this).trigger("enterKey");
        }
    });
    $('.btn-send').on('click', function (event) {
        $('.chat-input').trigger("enterKey");
    });
	$('.bet-input .upper a').on('click', function (event) {
        let value = parseFloat($('#amount').val()) || 0,
            all = $('#money').val(),
            thisMethod = $(this).attr('data-method'),
            thisValue = parseFloat($(this).attr('data-value'));

        switch(thisMethod) {
            case 'plus' : 
                value += thisValue;
                break;
            case 'divide' :
                value = parseInt((value/thisValue).toFixed(0));
                break;
            case 'clear' :
                value = '';
                break;
            case 'last' : 
                value = localStorage.getItem('last');;
                break;
            case 'all' : 
                value = all;
                break;
            case 'multiply' :
                value *= thisValue;
                break;
        }

        $('#amount').val(value);
    });
	$('.promoButton').click(function() {
		var code = $('.promoCode').val();
		$.ajax({
            url : '/ref/activate',
            type : 'post',
            data : {
                code : code
            },
			success : function(data) {
				$.notify({
                    position : 'top-right',
                    type: data.type,
                    message: data.msg
                });
		        return false;
			},
            error : function(data) {
                console.log(data.responseText);
            }
        });
	});
	$('.getMoney').click(function() {
		$.ajax({
            url : '/ref/getMoney',
            type : 'post',
			success : function(data) {
				$.notify({
                    position : 'top-right',
                    type: data.type,
                    message: data.msg
                });
                $('.getMoney').hide();
                $('.moneyRef .to-get').html('Доступно для получения: <span>0</span> <i class="fas fa-coins"></i>');
		        return false;
			},
            error : function(data) {
                console.log(data.responseText);
            }
        });
	});
	$('.getBonus').click(function() {
		$.ajax({
            url : '/bonus/getBonus',
            type : 'post',
			success : function(data) {
				$.notify({
                    position : 'top-right',
                    type: data.type,
                    message: data.msg
                });
		        return false;
			},
            error : function(data) {
                console.log(data.responseText);
            }
        });
	});
});
function showPopup(el) {
	if($('.popup').is('.active')) {
		$('.popup').removeClass('active');	
	}
	$('.overlay, body, .popup.'+el).addClass('active');
}
function chatdelet(id) {
	$.post('/chatdel', {messages: id}, function (data) {
		if (data) {
			$.notify({
				position : 'top-right',
				type: data.status,
				message: data.message
			});
		}
	});
}
function copyToClipboard(element) {
    alert('hello');
    element.select();
    document.execCommand('copy');
    $.notify('Скопировано в буфер обмена!', 'info');
    $('.popup, .overlay, body').removeClass('active');
}
function declOfNum(number, titles)  
{  
    cases = [2, 0, 1, 1, 1, 2];  
    return titles[ (number%100>4 && number%100<20)? 2 : cases[(number%10<5)?number%10:5] ];  
}