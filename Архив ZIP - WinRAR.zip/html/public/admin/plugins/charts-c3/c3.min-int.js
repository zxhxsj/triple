/*
Template Name: Xtreamer
Author: UXLiner
*/
(function ($) {
	"use strict";

//statistics-chart
var chart = c3.generate({
	bindto: '#statistics-chart',
	padding: {
        top: 0,
        right: 0,
        bottom: -1,
        left: 0,
    },
	point: {
        	show: false
    	},
    data: {
        columns: [
            ['data1', 0, 1, 20, 200, 20, 180, 60, 200, 5, 3, 0],
            ['data2', 0, 2, 10, 120, 10, 50, 0, 100, 3, 2, 1]
        ],
		names: {
            data1: 'Sales',
            data2: 'Revenue'
        },
        types: {
            data1: 'area-spline',
            data2: 'area-spline'
            // 'line', 'spline', 'step', 'area', 'area-step' are also available to stack
        },
		colors: {
			data1: '#c2adef',
			data2: '#4eb6f7'
    	},
	}
});

//orders-chart
var chart = c3.generate({
	bindto: '#orders-chart',
	padding: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 15,
    },
    data: {
        columns: [
            ['data1', 180, 200, 250, 400, 150, 250],
            ['data2', 80, 150, 80, 200, 70, 285]
        ],
		names: {
            data1: 'This month',
            data2: 'Last month'
        },
        type: 'bar',
        colors: {
            data1: '#1e88e5',
            data2: '#23d3d6'
        },
    },
});

//donut-chart
var chart = c3.generate({
	bindto: '#donut-chart',
    data: {
        columns: [
            ["2016", 18],
            ["2017", 30],
            ["2018", 52],
        ],
        type : 'donut',
        onclick: function (d, i) { console.log("onclick", d, i); },
        onmouseover: function (d, i) { console.log("onmouseover", d, i); },
        onmouseout: function (d, i) { console.log("onmouseout", d, i); },
		colors: {
            2016: '#4a90e2',
			2017: '#23d3d6',
            2018: '#7460ee'
        },
    },
    donut: {
        title: "Revenue statistics"
    }
});



})(jQuery);