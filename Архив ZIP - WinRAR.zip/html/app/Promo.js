const db = require('../app/Database');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const DateFormat = require('dateformat');
const Roulette = require('../app/Roulette');
const ws = require('../app/WebSockets');

exports.register = async function(req, res) {
    let transaction = await db.transaction();
    let createResult = false;
    try {
        let user = await db.Users.findById(req.user.id, {
            transaction : transaction
        });
        if(!user) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Не удалось найти вас в базе данных!'
            });
        }
        
        if(isNaN(user.balance)) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неверный баланс!'
            });
        }
    
        // already exist
        let promo = await db.Promo.find({
            where : {
                promo : req.body.promo,
                status : 0
            },
            transaction : transaction
        });
        if(promo) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Такой промокод уже существует!'
            });
        }
    
        // check string length
        if(req.body.promo.length < 3) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Минимальная длина промокода - 3 символа'
            });
        }
    
        if(req.body.promo.length > 10) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Максимальная длина промокода - 10 символов'
            });
        }
        
        // check string by html tags
        let allowed = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        
        for(var i = 0; i < req.body.promo.length; i++)
        {
            var access = false;
            for(var u = 0; u < allowed.length; u++) if(allowed[u] == req.body.promo[i]) access = true;
    
            if(!access) 
            {
                await transaction.rollback();
                return res.json({
                    success : false,
                    msg : 'Промокод не должен содержать запрещенные символы ('+req.body.promo[i]+')'
                });
            }
        }
    
        let numString = req.body.amount + ''; // number to string
        for(var i = 0; i < numString.length; i++) if(isNaN(parseInt(numString[i]))) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неверно введена сумма!'
            });
        }
    
    
        // check price and count
        if(isNaN(req.body.amount) || parseFloat(req.body.amount) <= 0 || parseInt(req.body.amount) < 1) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Минимальная сумма - 1'
            });
        }
    
        if(req.body.count <= 0) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Кол-во активаций не может быть равно нулю!'
            });
        }
    
        // check user balance
        let result = (req.body.amount*req.body.count);
        if(isNaN(result) || result <= 0) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Ошибка при вычислениях!'
            });
        }
        if(user.balance < result) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Недостаточно баланса!'
            });
        }
    
        // remove balance
        let balance = parseFloat((user.balance-result).toFixed(2));
        // await user.save();
        await db.Users.update({
            balance : balance
        }, {
            where : {
                id : user.id
            },
            transaction : transaction
        });
    
        // create promo
        createResult = await db.Promo.create({
            user_id : user.id,
            promo : req.body.promo,
            count : req.body.count,
            amount : req.body.amount,
            activated : [],
            date : Roulette.getDate(),
            status : 0
        }, {
            transaction : transaction
        });

        await db.PromoActives.create({
            user_id : req.user.id,
            promo : req.body.promo,
            owner_id : req.user.id,
            cost : req.body.amount*req.body.count
        }, {
            transaction : transaction
        });

        await transaction.commit();

        Roulette.updateBalance(user.id);
    } catch (error) {
        await transaction.rollback();
    }

    return res.json({
        success : true,
        msg : 'Промокод "' + req.body.promo + '" успешно создан!',
        result : createResult.get({plain:true})
    });
}

exports.activate = async function(req, res) {
    let transaction = await db.transaction();
    try {
        let user = await db.Users.findById(req.user.id, {
            transaction : transaction
        });
        if(!user) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Не удалось найти вас в базе данных!'
            });
        }
    
        if(isNaN(user.balance)) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неверный баланс!'
            });
        }
    
        let promo = await db.Promo.find({
            where : {
                promo : req.body.promo
            },
            order : [['id', 'desc']],
            transaction : transaction
        });
    
        // find this promo
        if(!promo) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Не удалось найти промокод "' + req.body.promo + '"'
            });
        }
    
        // check promo active
        if(promo.activated.length >= promo.count)
        {
            promo.status = 1;
            // await promo.save();
            await db.Promo.update({
                status : promo.status
            }, {
                where : {
                    id : promo.id
                },
                transaction : transaction
            });
    
            await transaction.commit();
    
            return res.json({
                success : false,
                msg : 'Этот промокод исчерпан!'
            });
        }
    
        // check for already activated
        for(var i in promo.activated) if(promo.activated[i] == req.user.id) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Вы уже активировали этот промокод!'
            });
        }
    
        // active promo
        user.balance = parseFloat((user.balance+promo.amount).toFixed(2));
        // await user.save();
        await db.Users.update({
            balance : user.balance
        }, {
            where : {
                id : user.id
            },
            transaction : transaction
        });
    
        promo.activated.push(req.user.id);
        if(promo.activated.length >= promo.count) promo.status = 1;
        
        await db.Promo.update({
            activated : promo.activated,
            status : promo.status
        }, {
            where : {
                id : promo.id
            },
            transaction : transaction
        });

        await db.PromoActives.create({
            user_id : req.user.id,
            promo : promo.promo,
            owner_id : promo.user_id,
            cost : promo.amount
        }, {
            transaction : transaction
        });
    
        await transaction.commit();

        Roulette.updateBalance(user.id);

        ws.send({
            action : 'message',
            to : promo.user_id,
            msg : req.user.username + ' активировал промокод "' + promo.promo + '" на ' + promo.amount + ' монет!' ,
            type : 'info'
        });
		
		redis.publish('message', JSON.stringify({
            to : promo.user_id,
            msg : req.user.username + ' активировал промокод "' + promo.promo + '" на ' + promo.amount + ' монет!' ,
            type : 'info'
        }));

        return res.json({
            success : true,
            msg : 'Промокод "' + req.body.promo + '" на '+promo.amount+' монет успешно активирован!'
        });
    } catch(error) {
        await transaction.rollback();
        console.log(error);
        return res.json({
            success : false,
            msg : 'Попробуйте позже!'
        });
    }
}