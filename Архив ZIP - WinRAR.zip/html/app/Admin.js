const db = require('../app/Database');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const DateFormat = require('dateformat');
const Roulette = require('./Roulette');
const ws = require('../app/WebSockets');

exports.getOnlineDiagrams = () => { 
    return new Promise(async(res, rej) => {
        result = await db.Online.findAll({
            attributes : ['time'],
            where : {
                time : {
                    [db.Sequelize.Op.gte] : (new Date(DateFormat(new Date(), 'yyyy-mm-01 00:00:00')).getTime()).toString()
                }
            },
            group : [['time']]
        });

        list = [];
        for(var i = 0; i < result.length; i++) 
        {
            cels = await db.Online.findAll({
                where : {
                    time : result[i].time
                }
            });

            list.push({
                time : parseInt(result[i].time),
                count : cels.length
            });
        }


        list = Roulette.sort(list, 'time', 'asc');

       // for(var i = 0; i < list.length; i++) list[i].time = await this.getDate(list[i].time);

        return res(list);
    });
}

exports.getProfitStats = () => {
    return new Promise(async(res, rej) => {
        let stats = {today:{}, eday : {}};
        let dates = [
            DateFormat(new Date(), 'yyyy-mm-dd 00:10:00'),
            DateFormat(new Date().getTime()-(21*60*60*1000), 'yyyy-mm-dd 00:10:00')
        ];
        let rooms = await db.Rooms.findAll();
    
        for(var i = 0; i < dates.length; i++)
        {
            let section = (i == 0) ? 'today' : 'eday';
            stats[section].sends = await db.Send.sum('value', {
                where : {
                    createdAt : {
                        [db.Sequelize.Op.gte] : dates[i],
                        [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:10:00')
                    }
                }
            }) || 0;
    
            stats[section].rooms = [];
            for(var u in rooms)
            {
                let games = await db.Games.sum('comission', {
                    where : {
                        room : rooms[u].id,
                        status : 3,
                        updatedAt : {
                            [db.Sequelize.Op.gte] : dates[i],
                            [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:10:00')   
                        }
                    }
                }) || 0;
    
                // if(games > 0) games = parseFloat((games*0.1).toFixed(2));
    
                stats[section].rooms.push({
                    name : rooms[u].name,
                    value : Roulette.numberFormat(games)
                });
            }
    
            if(stats[section].sends > 0) {
                let percent = stats[section].sends/95;
                stats[section].sends = parseFloat((percent*5).toFixed(2));    
            }

            stats[section].fish = await db.Fishing.sum('final', {
                where : {
                    status: 1,
                    updatedAt : {
                        [db.Sequelize.Op.gte] : dates[i],
                        [db.Sequelize.Op.lte] : DateFormat(new Date(dates[i]).getTime()+(24*60*60*1000), 'yyyy-mm-dd 00:00:00')   
                    }
                }
            }) || 0;
        }

        return res(stats);
    });
}

exports.getDatev2 = now => {
    return new Promise((res, rej) => {
        now = parseInt(now);
        months = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря'];
        var date = DateFormat(now, 'dd / в HH:MM').replace('/', months[parseInt(DateFormat(now, 'mm'))-1]);
        return res(date);
    });
}

exports.getDate = now => {
    return new Promise((res, rej) => {
        now = parseInt(now);
        months = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря'];
        var date = DateFormat(now, 'dd /').replace('/', months[parseInt(DateFormat(now, 'mm'))-1]);
        return res(date);
    });
}

exports.getStats = () => {
    return new Promise(async(res, rej) => {
        var returnValue = {};

        returnValue.days = {};
        returnValue.days.deposits = Roulette.numberFormat(await db.Deposit.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')
                }
            }
        }) || 0);
        returnValue.days.withdraws = Roulette.numberFormat(await db.Withdraw.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')
                }
            }
        }) || 0);

        returnValue.week = {};
        returnValue.week.day = DateFormat((new Date().getTime()), 'dddd');
        let MinusTime = (1000*3600*24*6);
        if(returnValue.week.day == 'Monday') MinusTime = 0;
        if(returnValue.week.day == 'Tuesday') MinusTime *= 1;
        if(returnValue.week.day == 'Wednesday') MinusTime *= 2;
        if(returnValue.week.day == 'Thursday') MinusTime *= 3;
        if(returnValue.week.day == 'Friday') MinusTime *= 4;
        if(returnValue.week.day == 'Saturday') MinusTime *= 5;
        if(returnValue.week.day == 'Sunday') MinusTime *= 6;
        
        returnValue.week.deposits = Roulette.numberFormat(await db.Deposit.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat((new Date().getTime()-MinusTime), 'yyyy-mm-dd 00:00:00')
                }
            }
        }) || 0);

        returnValue.week.withdraws = Roulette.numberFormat(await db.Withdraw.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat((new Date().getTime()-MinusTime), 'yyyy-mm-dd 00:00:00')
                }
            }
        }) || 0);

        returnValue.month = {};

        returnValue.month.deposits = Roulette.numberFormat(await db.Deposit.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-mm-01 00:00:00')
                }
            }
        }) || 0);

        returnValue.month.withdraws = Roulette.numberFormat(await db.Withdraw.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-mm-01 00:00:00')
                }
            }
        }) || 0);

        returnValue.year = {};

        returnValue.year.deposits = Roulette.numberFormat(await db.Deposit.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-01-01 00:00:00')
                }
            }
        }) || 0);

        returnValue.year.withdraws = Roulette.numberFormat(await db.Withdraw.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : DateFormat(new Date(), 'yyyy-01-01 00:00:00')
                }
            }
        }) || 0);

        return res(returnValue);
    });
}

exports.getWD = () => {
    return new Promise(async(res, rej) => {
        var dates = await this.getDates(),
            list = {};
        
        // deposits
        list.deposits = [];
        for(var i in dates) list.deposits.push(await db.Deposit.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(dates[i]),
                    [db.Sequelize.Op.lt] : (new Date(dates[i]).getTime()+24*3600*1000)
                }
            }
        }) || 0);

        // withdraws
        list.withdraws = [];
        for(var i in dates) list.withdraws.push(await db.Withdraw.sum('amount', {
            where : {
                status : 1,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(dates[i]),
                    [db.Sequelize.Op.lt] : (new Date(dates[i]).getTime()+24*3600*1000)
                }
            }
        }) || 0);

        list.x = [];
        for(var i in dates) list.x.push(await this.getDate(new Date(dates[i]).getTime()));

        let returnValue = [];
        for(var i in dates) returnValue[i] = {
            x : list.x[i],
            deposite : list.deposits[i],
            withdraw : list.withdraws[i]
        };


        return res(returnValue);
    });
}


exports.getDates = () => {
    return new Promise(async(res, rej) => {
        var dates = [],
            days = 0,
            chekced = true,
            start = DateFormat(new Date(), 'yyyy-mm-01 00:00:00');
        while(chekced)
        {
            let date = DateFormat(new Date(start).getTime()+(days*24*3600*1000), 'yyyy-mm-dd 00:00:00');
            let month = DateFormat(new Date(start).getTime()+(days*24*3600*1000), 'mm');
            let nowMonth = DateFormat(new Date(), 'mm');
            days++;
            if(nowMonth != month || new Date(date) >= new Date()) chekced = false;
            if(chekced) dates.push(date);
        }

        return res(dates);
        
    });
}