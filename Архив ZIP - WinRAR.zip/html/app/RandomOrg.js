var request = require('request');

const RandomOrg = function()
{
    this.apikey = '1e78d1c5-b486-4429-8701-5639d4f6c983';
}

RandomOrg.prototype.generateInteger = function(min, max, id)
{
    return new Promise((response, reject) => {
        request.post({
            url : 'https://api.random.org/json-rpc/1/invoke',
            headers : {
               'content-type' : 'application/json'
            },     
            json : {
               "jsonrpc": "2.0",
               "method": "generateSignedIntegers",
               "params": {
                   "apiKey": this.apikey,
                   "n": 1,
                   "min": min,
                   "max": max,
                   "replacement": true
               },
               "id": id
           }
        }, (err, res, body) => {
            if(err) return response(false);
            return response(body);
        });
    });
}

module.exports = RandomOrg;