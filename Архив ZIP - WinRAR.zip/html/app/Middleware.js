const Redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const {promisify} = require('util');
const getAsync = promisify(Redis.get).bind(Redis);
const db = require('../app/Database');

exports.auth = function(req, res, next)
{
    if(!req.isAuthenticated()) 
        if(req.method == 'GET') return res.redirect('/login') 
        else return res.json({
            success : false,
            msg : 'Вы должны авторизироваться на сайте!'
        });
    return next();
}

exports.deposit = async function(req, res, next) {
    if(!req.isAuthenticated()) return res.json({
        success : false,
        msg : 'Вы должны авторизироваться на сайте!'
    });

    if(req.user.is_admin > 0) return next();

    let depositSum = await db.Deposit.sum('amount', {
        where : {
            user_id : req.user.id,
            status : 1
        }
    }) || 0;

    // if(req.path == '/chat/sendMessage' && depositSum < 1) return res.json({
        // success : false,
        // msg : 'Пополните свой счёт на 1 и более рублей что бы написать в чате!'
    // });
    
    //if(req.path == '/sendWithdraw' && depositSum < 10) return res.send('Пополните счёт в сумме на 10 рублей и более что бы вывести средства!');

    return next();
}

exports.time = async function(req, res, next) {
    Time = 1;
    if(req.path == '/chat/sendMessage') 
    {
        Time = 2;
        if(req.user.is_admin > 0) Time = 0;
    }
    if(req.path == '/addBet') Time = 2;
    if(req.path == '/registerPromo') Time = 5;
    if(req.path == '/activePromo') Time = 1;
    if(req.path == '/sendMoney') Time = 20;

    result = await getAsync(req.path + '#' + req.headers['x-real-ip'] || req.connection.remoteAddress);
    if(req.path == '/activePromo' || req.path == '/registerPromo') result = await getAsync(req.path);
    if(result == null)
    {
        // нет последней записи
        let value = req.path + '#' + req.headers['x-real-ip'] || req.connection.remoteAddress;
        if(req.path == '/activePromo' || req.path == '/registerPromo') value = req.path;
        Redis.set(value, Math.floor(new Date().getTime()/1000));
        return next();
    }
    if((Math.floor(new Date().getTime()/1000)-result) < Time) return res.json({
        success : false,
        msg : 'Попробуйте позже'
    });
    let value = req.path + '#' + req.headers['x-real-ip'] || req.connection.remoteAddress;
    if(req.path == '/activePromo' || req.path == '/registerPromo') value = req.path;
    Redis.set(value, Math.floor(new Date().getTime()/1000));

    return next();
}

exports.moder = function(req, res, next) {
    if(!req.isAuthenticated()) return res.json({
        success : false,
        msg : 'Вы должны авторизироваться на сайте!'
    });

    if(req.user.is_admin < 1) return res.json({
        success : false,
        msg : 'Доступ запрещен'
    });

    return next();
}

exports.admin = function(req, res, next) {
    if(!req.isAuthenticated() && req.method == 'POST') return res.json({
        success : false,
        msg : 'Вы должны авторизироваться на сайте!'
    });

    if(!req.isAuthenticated() && req.method == 'GET') return res.send('Доступ запрещён!');

    if(req.user.is_admin != 2) 
    {
        if(req.method == "POST") return res.json({
            success : false,
            msg : 'Доступ запрещён!'
        });

        if(req.method == "GET") return res.send('Доступ запрещён!');
    }

    return next();
}

exports.FreeKassa = function(req, res, next) {
    return next();
}