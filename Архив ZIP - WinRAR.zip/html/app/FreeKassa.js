const Requestify = require('requestify');
const db = require('./Database');
const Url = require('url');
const XML2JSON = require('xml2json');
const Crypto = require('crypto');
const Request = require('request');

exports.events = [1,1,1,1,1,1];
exports.eventsKey = -1;

exports.makeApiRequest = (query) => {
    return new Promise(async(res, rej) => {

        let RequestParams = Url.format({
            protocol : 'http',
            hostname : 'www.free-kassa.ru',
            pathname : '/api.php',
            query : query
        });

        let RequestResponse = await Requestify.get(RequestParams.toString());
            RequestResponse = JSON.parse(XML2JSON.toJson(RequestResponse.body)).root;

        if(RequestResponse.answer == 'info' && query.action == 'get_balance') return res({
            success : true,
            balance : parseFloat(RequestResponse.balance)
        });

        if(RequestResponse.answer == 'info' && query.action == 'payment') return res({
            success : true,
            PaymentId : RequestResponse.PaymentId
        });

        if(RequestResponse.answer == 'info' && query.action == 'check_order_status') return res({
            success : true,
            info : {
                status : RequestResponse.status,
                id : RequestResponse.id,
                date : RequestResponse.date,
                amount : RequestResponse.amount
            }
        });

        if(RequestResponse.answer == 'error') return res({
            success : false,
            error : RequestResponse.desc
        });
        
        return res({
            success : false,
            error : false
        });
    });
}

exports.makeRequest = (url, form) => {
    return new Promise((res, rej) => {
        let RequestResponse = Request.post({
            url : url,
            form : form
        }, (err, response, body) => {
            if(err) return res(false, err);
            return res(JSON.parse(body), false);
        });
    });
}

exports.makeApiV1Request = (query) => {
    return new Promise(async(res, rej) => {

        let RequestResponse = await this.makeRequest('https://www.fkwallet.ru/api_v1.php', query);

        if(RequestResponse.status == 'info' && query.action == 'get_balance') return res({
            success : true,
            balance : RequestResponse.data.RUR
        });

        if(query.action == 'cashout') console.log(RequestResponse);

        if(RequestResponse.status == 'info' && query.action == 'cashout') return res({
            success : true,
            id : RequestResponse.data.payment_id
        });

        if(RequestResponse.status == 'error') return res({
            success : false,
            error : RequestResponse.desc
        });
    });
}

exports._fkSend  = (purse, currency, amount, withdrawID) => {
    if(currency == 'Qiwi') 
    {
        currency = 63;
        amount *= 0.95;
    }
    if(currency == 'Yandex Money') currency = 175;
    if(currency == 'Card') 
    {
        currency = 94;
        amount *= 0.96;
        amount -= 50;
    }

    return new Promise(async(res, rej) => {

        let cfg = await db.cfg();

        let RequestParams = {
            wallet_id : cfg.fk_wallet,
            purse : purse,
            amount : amount,
            desc : 'Вывод #' + withdrawID,
            disable_exchange : 1,
            currency : currency,
            sign : Crypto.createHash('md5').update(cfg.fk_wallet + currency + '' + amount + '' + purse + cfg.fk_api).digest('hex'),
            action : 'cashout'
        }

        return res(await this.makeApiV1Request(RequestParams));
    });
}

exports._fkGetBalance = () => {
    return new Promise(async(res, rej) => {
        let cfg = await db.cfg();
        let RequestParams = {
            wallet_id : cfg.fk_wallet,
            sign : Crypto.createHash('md5').update(cfg.fk_wallet + cfg.fk_api).digest('hex'),
            action : 'get_balance'
        }

        return res(await this.makeApiV1Request(RequestParams));
    });
}

exports.getBalance = () => {
    
    return new Promise(async(res, rej) => {
        let cfg = await db.cfg(); // Получаем конфиг
        let RequestParams = {
            merchant_id : cfg.fk_id,
            s : Crypto.createHash('md5').update(cfg.fk_id+cfg.fk_secret).digest('hex'),
            action : 'get_balance'
        }
        
        return res(await this.makeApiRequest(RequestParams));
    });
}



exports.sendToWallet = (amount) => {
    return new Promise(async(res, rej) => {
        let cfg = await db.cfg(); // Получаем конфиг
        let RequestParams = {
            merchant_id : cfg.fk_id,
            s : Crypto.createHash('md5').update(cfg.fk_id+cfg.fk_secret).digest('hex'),
            amount : amount,
            currency : 'fkw',
            action : 'payment'
        }
        
        return res(await this.makeApiRequest(RequestParams));
    });
}

exports.checkOrder = (id) => {
    return new Promise(async(res, rej) => {
        let cfg = await db.cfg();
        let RequestParams = {
            merchant_id : cfg.fk_id,
            s : Crypto.createHash('md5').update(cfg.fk_id+cfg.fk_secret).digest('hex'),
            intid : id,
            order_id : id,
            action : 'check_order_status'
        }

        return res(await this.makeApiRequest(RequestParams));
    });
}

exports.checkBalance = async() => {
    this.log('Проверка баланса...');
    let balance = await this.getBalance();
    let fk_balance = await this._fkGetBalance();
    let cfg = await db.cfg();
    if(fk_balance.success) cfg.fk_balance = fk_balance.balance;
    if(balance.success) cfg.kassa_balance = balance.balance;
    await cfg.save();
    if(balance.success) console.log('[FreeKassa] Баланс : ' + balance.balance + 'руб.');
    if(fk_balance.success) console.log('[FKWallet] Баланс : ' + fk_balance.balance + 'руб.');
    if(balance.success && balance.balance >= 50)
    {   
        setTimeout(async() => {
            let result = await this.sendToWallet(balance.balance);
            if(result.success) console.log('[FreeKassa] Перевели ' + balance.balance + 'руб. на FK кошелек!');
            return setTimeout(this.init, 10001);
        }, 10001);
    } else {
        return setTimeout(this.init, 10001);
    }
}

exports.getOrder = async() => {
    let order = await db.Deposit.find({
        where : {
            status : 0,
            check : false
        }
    });

    if(!order)
    {
        await db.Deposit.update({
            check : false
        }, {
            where : {
                status : 0
            }
        });
        return setTimeout(this.init, 10001);
    }

    if((new Date().getTime() - new Date(order.createdAt).getTime()) < (7*60*1000)) 
    {
        await db.Deposit.update({
            check : true
        }, {
            where : {
                id : order.id
            }
        });
        return this.init();
    }

    this.log('Проверка платежа #' + order.order_id);

    // console.log('Order user_id : ' + order.user_id + ' / ' + order.amount);

    let result = await this.checkOrder(order.order_id);
    console.log(result);
    if(result.success)
    {
        if(result.info.status == 'completed')
        {
            let user = await db.Users.findById(order.user_id);
            if(user)
            {
                user.balance = parseFloat((user.balance+order.amount).toFixed(2));
                await user.save();
            }
            // order.status = 1;
            // order.check = true;
            // await order.save();
            await db.Deposit.update({
                status : 1,
                check : true
            }, {
                where : {
                    id : order.id
                }
            });
            this.log('Зачислили ' + order.amount + ' игроку ' + user.username);
        } else {
            await db.Deposit.update({
                check : true
            }, {
                where : {
                    id : order.id
                }
            });
        }
    } else {
        // console.log(result);
        let status = order.status;
        if(result.error == 'Order not found') status = 2;
        await db.Deposit.update({
            check : true,
            status : status
        }, {
            where : {
                id : order.id
            }
        });
    }

    return setTimeout(this.init, 10001);
}

exports.init = async() => {
    this.log('Инициализация...');
    // return this.log('Отмена инициализации! Режим разработчика!');
    this.eventsKey++;
    if(typeof this.events[this.eventsKey] == 'undefined') this.eventsKey = 0;
    let event = this.events[this.eventsKey];
    if(event == 1) 
        return this.checkBalance(); 
    // else
        // return this.getOrder();
}

exports.log = (log) => {
    console.log('[FreeKassa] ' + log);
}