const Sequelize = require('sequelize');
const Crypto = require('crypto');
const Database = new Sequelize('mg24', 'mg24pw', '23bZmfRM9ZW2PXT2ybRQBCJZ9GVX6jth', {
    host : 'localhost',
    dialect : 'postgres',
    pool : {
        min : 0,
        max : 20,
        acquire : 100000,
        idle : 10000
    },
    logging : false,
    debug : false
});

exports.getTransaction = function() {
    return Database.transaction({
        isolationLevel : Sequelize.Transaction.ISOLATION_LEVELS.REPEATABLE_READ
    });
}

exports.Sequelize = Sequelize;

exports.Fish = Database.define('fish', {
    name: Sequelize.STRING,
    img: Sequelize.STRING,
    min: {
        type: Sequelize.DOUBLE,
        defaultValue: 0.01
    },
    max: {
        type: Sequelize.DOUBLE,
        defaultValue: 1
    }
});

exports.Fishing = Database.define('fishing', {
    user_id: Sequelize.INTEGER,
    user: Sequelize.JSON,
    fish: Sequelize.JSON,
    price: Sequelize.DOUBLE,
    result: Sequelize.DOUBLE,
    final: Sequelize.DOUBLE,
    line: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
    },
    status: {
        type: Sequelize.INTEGER,
        defaultValue: 0
    }
});

exports.TopRewards = Database.define('top', {
    date : Sequelize.STRING,
    value : Sequelize.DOUBLE,
    username : Sequelize.STRING,
    avatar : Sequelize.STRING,
    vk_id : Sequelize.INTEGER
});

exports.test = Database.define('test', {
    balance : Sequelize.DOUBLE,
    bets : Sequelize.INTEGER
});

exports.Profit = Database.define('profit', {
    value : {
        type : Sequelize.DOUBLE,
        defaultValue : 0
    }
});

exports.Users = Database.define('users', {
    vk_id : Sequelize.INTEGER,
    username : Sequelize.STRING,
    avatar : Sequelize.STRING,
    balance : {
        type : Sequelize.DOUBLE,
        defaultValue : 0
    },
    rate: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
    },
    rate_date: Sequelize.STRING,
    is_admin : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    ref_id : Sequelize.INTEGER,
    ban_chat : {
        type : Sequelize.BOOLEAN,
        defaultValue : false
    },
    ban_chat_reason : Sequelize.STRING,
    ban_chat_time : Sequelize.INTEGER,
    ban_chat_time_date : Sequelize.STRING,
    rate: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
    },
    rate_date: Sequelize.STRING,
    fish_profit: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
    }
});

exports.Online = Database.define('online', {
    ip : Sequelize.STRING,
    time : Sequelize.STRING
});

exports.RefRewards = Database.define('refRewards', {
    user_id : Sequelize.INTEGER,
    value : Sequelize.DOUBLE
});

exports.Rooms = Database.define('rooms', {
    timer : Sequelize.INTEGER,
    ng_timer : {
        type : Sequelize.INTEGER,
        defaultValue : 15
    },
    min_bet : Sequelize.INTEGER,
    max_bet : Sequelize.INTEGER,
    name : Sequelize.STRING,
    min_users : {
        type : Sequelize.INTEGER,
        defaultValue : 2
    },
    team : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    team_at : {
        type : Sequelize.INTEGER,
        defaultValue : 3
    },
    short_url : Sequelize.STRING
});

exports.Games = Database.define('games', {
    room : Sequelize.INTEGER,
    price : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    comissionPrice : {
        type : Sequelize.DOUBLE,
        defaultValue : 0
    },
    random : Sequelize.INTEGER,
    status : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    timer : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    secret : Sequelize.STRING,
    randomOrg : Sequelize.JSON,
    winner_id : {
        type : Sequelize.INTEGER,
        defaultValue : null
    },
    winner : {
        type : Sequelize.JSON,
        defaultValue : null
    },
    comission : Sequelize.DOUBLE
});

exports.Config = Database.define('settings', {
    title : {
        type : Sequelize.STRING,
        defaultValue : 'MG by P4R4P3T'
    },
    descriptions : {
        type : Sequelize.STRING,
        defaultValue : 'P4R4P3T'
    },
    keywords : {
        type : Sequelize.STRING,
        defaultValue : 'p4r4p3t, P4R4P3T'
    },
    chat_min : {
        type : Sequelize.INTEGER,
        defaultValue : 10
    },
    chat_max : {
        type : Sequelize.INTEGER,
        defaultValue : 100
    },
    jackpot_comission : {
        type : Sequelize.INTEGER,
        defaultValue : 10
    },
    send_comission : {
        type : Sequelize.INTEGER,
        defaultValue : 5
    },
    send_min : {
        type : Sequelize.INTEGER,
        defaultValue : 1
    },
    currency : {
        type : Sequelize.INTEGER,
        defaultValue : 10
    },
    min_deposit : {
        type : Sequelize.INTEGER,
        defaultValue : 30
    },
    fk_secret : Sequelize.STRING,
    fk_id : Sequelize.INTEGER,
    fk_api : Sequelize.STRING,
    fk_wallet : Sequelize.STRING,
    profit : {
        type : Sequelize.DOUBLE,
        defaultValue : 0
    },
    rename_price : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    top_revards : {
        type : Sequelize.DOUBLE,
        defaultValue : 0
    },
    fk_order : {
        type : Sequelize.INTEGER,
        defaultValue : 1
    },
    ro_api : Sequelize.STRING,
    lastRevard : Sequelize.STRING,
    kassa_balance : Sequelize.DOUBLE,
    fk_balance : Sequelize.DOUBLE,
    gif : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    gif_path : Sequelize.STRING,
    technical : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    fish_okup: {
        type: Sequelize.INTEGER,
        defaultValue: 50
    }
});

exports.createSecret = function() {
    var chars = 'abcdefghijklmnopqrstyvwxyz1234567890',
        string = '';
    for(var i = 0; i < 25; i++) string += chars[Math.floor(Math.random()*chars.length)];
    return Crypto.createHmac('sha1', 'abcdefgh').update(string).digest('hex');
}

exports.transaction = function() {
    return Database.transaction({
        isolationLevel : Sequelize.Transaction.ISOLATION_LEVELS.REPEATABLE_READ
        // isolationLevel : 
    });
}

exports.Bets = Database.define('bets', { 
    room : Sequelize.INTEGER,
    user : Sequelize.INTEGER,
    game : Sequelize.INTEGER,
    price : Sequelize.INTEGER,
    color : Sequelize.STRING,
    from : Sequelize.INTEGER,
    to : Sequelize.INTEGER
});

exports.Send = Database.define('send', {
    user_id : Sequelize.INTEGER,
    to : Sequelize.JSON,
    value : Sequelize.DOUBLE,
    date : Sequelize.STRING
});

exports.Chat = Database.define('chat', {
    user : Sequelize.INTEGER,
    username : Sequelize.STRING,
    avatar : Sequelize.STRING,
    vk : Sequelize.INTEGER,
    admin : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    message : Sequelize.STRING
});

exports.Withdraw = Database.define('withdraws', {
    user_id : Sequelize.INTEGER,
    user : Sequelize.JSON,
    amount : Sequelize.DOUBLE,
    wallet : Sequelize.STRING,
    wallet2 : Sequelize.STRING,
    type : Sequelize.STRING,
    date : Sequelize.STRING,
    paymentID : Sequelize.INTEGER,
    status : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    }
});

exports.Deposit = Database.define('deposits', {
    secret : Sequelize.STRING,
    merchant_id : Sequelize.INTEGER,
    order_id : Sequelize.INTEGER,
    amount : Sequelize.DOUBLE,
    user_id : Sequelize.INTEGER,
    status : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    check : {
        type : Sequelize.BOOLEAN,
        defaultValue : false
    }
});

exports.Mates = Database.define('mates', {
    user_from : Sequelize.INTEGER,
    user_to : Sequelize.INTEGER,
    game : Sequelize.INTEGER,
    room : Sequelize.INTEGER,
    status : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    }
});

exports.Promo = Database.define('promos', {
    user_id : Sequelize.INTEGER,
    promo : Sequelize.STRING,
    count : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    },
    amount : Sequelize.DOUBLE,
    activated : Sequelize.JSON,
    date : Sequelize.STRING,
    status : {
        type : Sequelize.INTEGER,
        defaultValue : 0
    }
});

exports.PromoActives = Database.define('promos_activates', {
    user_id : Sequelize.INTEGER,
    promo : Sequelize.STRING,
    owner_id : Sequelize.INTEGER,
    cost : Sequelize.DOUBLE
});

exports.cfg = () => {
    return new Promise(async(res, rej) => {
        config = await this.Config.find({
            order : [['id', 'desc']]
        });
        if(!config) {
            this.Config.create();
            config = await this.Config.find({
                order : [['id', 'desc']]
            });
        }
        return res(config);
    });
}

exports.pLogs = Database.define('profit_logs', {
    value : Sequelize.DOUBLE,
    log : Sequelize.STRING,
    type : Sequelize.BOOLEAN,
    date : Sequelize.STRING,
    real_date : Sequelize.DATE
});

exports.pLog = (value, log, type, date) => {
    return new Promise(async(res, rej) => {
        value = (!type) ? (value-(value*2)) : value;
        await this.pLogs.create({
            value : value,
            log : log,
            type : type,
            date : date
        });
        return res(true);
    });
}

exports.Op = Sequelize.Op;

// exports.own = Database;

Database.sync().then(() => {
    console.log('[DATABASE] База данных успешно запущена');
});