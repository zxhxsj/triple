const db = require('../app/Database');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const DateFormat = require('dateformat');
const Roulette = require('../app/Roulette');
const ws = require('../app/WebSockets');

exports.sendMoney = async function(req, res) {
    let transaction = await db.transaction();
    try {
        if(parseInt(req.body.to) == req.user.id) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Вы не можете перевести сами себе!'
            });
        }

        let amount = parseFloat(parseFloat(req.body.amount).toFixed(2)); 
    
        var cfg = await db.cfg();

        if(isNaN(amount)) 
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неправильно введена сумма!'
            });
        }
    
        if(amount < cfg.send_min) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Минимальная сумма перевода - ' + cfg.send_min
            });
        }
    
        let to = await db.Users.findById(parseInt(req.body.to));
        if(!to) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Не удалось найти пользователя #' + req.body.to
            });
        }
    
        let me = await db.Users.findById(req.user.id);
        if(!me) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Не удалось найти вас в базе данных!'
            });
        }
    
        if(isNaN(me.balance) || me.balance < 0) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неверный баланс!'
            });
        }

        if(isNaN(to.balance) || to.balance < 0) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Неверный баланс у человека, которому вы хотите перевести средства!'
            });
        }
    
        if(me.balance < amount) {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Недостаточно баланса!'
            });
        }

        let toBalance = parseFloat((to.balance+parseFloat((amount*0.95).toFixed(2))).toFixed(2));
        let meBalance = parseFloat((me.balance-amount).toFixed(2));

        if(isNaN(toBalance) || toBalance < 0 || isNaN(meBalance) || meBalance < 0)
        {
            await transaction.rollback();
            return res.json({
                success : false,
                msg : 'Ошибка при рассчетах!'
            });
        }
    
        // проверка на сумму выводов
        await db.Users.update({
            balance : meBalance
        }, {
            where : {
                id : me.id
            },
            transaction : transaction
        });
    
        await db.Users.update({
            balance : toBalance
        }, {
            where : {
                id : to.id
            },
            transaction : transaction
        });
    
        await db.pLog(parseFloat((amount*0.05).toFixed(2)), 'Комиссия при переводе', true, Roulette.getDate());
    
        let sendQuery = await db.Send.create({
            user_id : me.id,
            to : {
                id : to.id,
                username : to.username
            },
            value : parseFloat((amount*0.95).toFixed(2)),
            date : Roulette.getDate()
        }, {
            transaction : transaction
        });
    
        let config = await db.cfg();
        config.profit += parseFloat((amount*0.95).toFixed(2));
        await config.save();
        // await db.Cofig
        ws.send({
            action : 'message',
            to : to.id,
            msg : me.username + ' перевел вам ' + parseFloat((amount*0.95).toFixed(2)) + ' монет!',
            type : 'success'
        });
        redis.publish('message', JSON.stringify({
            to : to.id,
            msg : me.username + ' перевел вам ' + parseFloat((amount*0.95).toFixed(2)) + ' монет!',
            type : 'success'
        }));

        await transaction.commit();

        Roulette.updateBalance(to.id);
        Roulette.updateBalance(me.id);

        return res.json({
            success : true,
            msg : 'Вы перевели ' + parseFloat((amount*0.95).toFixed(2)) + ' монет игроку #' + to.id,
            query : sendQuery.get({plain:true})
        });
    } catch(error) {
        await transaction.rollback();
        console.log(error);
        return res.json({
            success : false,
            msg : 'Попробуйте позже!'
        });
    }
}