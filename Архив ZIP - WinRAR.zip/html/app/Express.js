var Passport = require('./Passport'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    session = require('express-session'),
    path = require('path'),
    express = require('express');

const app = express();
const router = require('./Routes');
const Redis = require('connect-redis')(session);
const Crypto = require('crypto');

app.disable('x-powered-by');
app.enable('trust proxy');
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(session({
    secret : Crypto.createHash('sha1').update('_p4r4p3t_').digest('hex'),
    resave : true,
    saveUninitialized : true,
    store : new Redis({
        path : '/var/run/redis/redis.sock'
    }),
    cookie: { secure: false, maxAge:86400000 }
}));
app.use(Passport.initialize());
app.use(Passport.session());
app.use("/public", express.static(`${__dirname}/../public`));

app.use(require('express-edge'));
app.set('views', `${__dirname}/../views`);

app.use('/test', router.test);
app.use('/chat', router.chat);
app.use('/login', router.auth);
app.use('/admin', router.admin);
app.use('/', router.index);
app.use('/fish', router.fish);
app.use('/dev', router.p4);

module.exports = app;