const fs = require('fs');
const https = require('https');

exports.createServer = () => {
    return new https.createServer({
        key : fs.readFileSync('./app/Certificate/key.pem'),
        cert : fs.readFileSync('./app/Certificate/cert.pem')
    });
}