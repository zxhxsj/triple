const db = require('../app/Database');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const listener = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const RandomOrg = new(require('../app/RandomOrg'))();
const DateFormat = require('dateformat');
const FreeKassa = require('../app/FreeKassa');
const ws = require('../app/WebSockets');


exports.timers = [],


exports.getRoomsContent = () => {
    return new Promise(async(res, rej) => {
        var rooms = await db.Rooms.findAll({
            attributes : ['id', 'name', 'min_bet', 'max_bet', 'short_url'],
            order:[['id', 'DESC']]
        });
    
        var html = '';
        for(var i in rooms) 
        {
            let game = await this.lastGame(rooms[i].id);
            // html += '<a href="'+rooms[i].short_url+'">'+rooms[i].name+' | '+this.numberFormat(game.price)+' <i class="icon icon-goldcoin"></i></a>';
            html += '<li><a title="Комната '+rooms[i].name+' от '+this.numberFormat(rooms[i].min_bet)+' до '+((rooms[i].max_bet == 0) ? 'неогр.' : this.numberFormat(rooms[i].max_bet))+' | '+game.price+'" href="'+rooms[i].short_url+'" ><i class="fas fa-life-ring"></i><div class="name">Комната '+rooms[i].name+' | <span style="font-weight:bold;color:gold;">'+this.numberFormat(game.price)+'</span> <span class="fab fa-monero mgmoney"></span></div></a></li>';
        }

        return res(html);
    });
}

exports.numberFormat = function(number)
{
    let minus = (number < 0) ? true : false;
    if(number < 0) number = number-number-number;
    beforeDot = Math.floor(number).toFixed(0);
    afterDot = (number-beforeDot).toFixed(2).replace('0.', '');
    array = [];
    count = 0;
    for(var i = 0; i < beforeDot.length; i++)
    {
        if(Math.floor(count/3) == (count/3) && count > 0) array.push(' ');
        array.push(beforeDot[(beforeDot.length-i-1)]);
        count++;
    }

    string = '';
    for(var i = 0; i < array.length; i++) string += array[(array.length-i-1)];
    return ((minus) ? '-' : '') + string + ((afterDot == '00') ? '' : ('.' + afterDot));
}

exports.getRefsPercent = (id) => {
    return new Promise(async(res, rej) => {
        var CountRefs = await db.Users.findAll({
            where : {
                ref_id : id
            }
        });
        CountRefs = CountRefs.length;
        $percent = 0.5;
        if(CountRefs > 500) $percent = 3;
        if(CountRefs >= 201 && CountRefs < 500) $percent = 2.5;
        if(CountRefs >= 101 && CountRefs <= 200) $percent = 2;
        if(CountRefs >= 21 && CountRefs <= 100) $percent = 1.5;
        if(CountRefs >= 10 && CountRefs <= 20) $percent = 1;

        return res($percent);
    });
}

exports.giveRevards = async(game) => {
    if(game.status < 3) return;
    var user = await db.Users.findById(game.winner_id);

    var room = await db.Rooms.findById(game.room);

    var WinnerMate = await db.Mates.find({
        where : {
            [db.Sequelize.Op.or] : [
                {
                    user_from : game.winner_id
                },
                {
                    user_to : game.winner_id
                }
            ],
            game : game.id,
            status : 1
        }
    });

    var MateID = null;
    if(WinnerMate) MateID = (WinnerMate.user_from == game.winner_id) ? WinnerMate.user_to : WinnerMate.user_from; 


    game.winner.mate_id = MateID;
    game = await game.save();

    // ищем ставку мейта
    if(WinnerMate)
    {
        var MateBetSum = await db.Bets.sum('price', {
            where : {
                room : game.room,
                game : game.id,
                user : MateID
            }
        });

        var Mate = await db.Users.find({
            where : {
                id : MateID
            }
        });

        if(Mate)
        {
            game.price -= MateBetSum;
            if(MateBetSum > 0)
            {
                Mate.balance += parseFloat((MateBetSum*0.9).toFixed(2));
                Mate.balance = parseFloat(Mate.balance.toFixed(2));
                // if(isNaN)
                // проверка на правильность баланса
                if(!isNaN(Mate.balance) && Mate.balance >= 0) 
                {
                    Mate = await Mate.save();
                    this.updateBalance(Mate.id);
                    ws.send({
                        action : 'message',
                        to : MateID,
                        msg : 'Ваша ставка из игры #' + game.id + ' вернулась с учетом комиссии!',
                        type : 'info'
                    });
                    
                    setTimeout(() => {
                        redis.publish('message', JSON.stringify({
                            to : MateID,
                            msg : 'Ваша ставка из игры #' + game.id + ' вернулась с учетом комиссии!',
                            type : 'info'
                        }));
                    });
                }
            }
        }
    }


    var MyRef = await db.Users.find({
        where : {id:user.ref_id}
    });

    var ComissionPrice = parseFloat((game.price*0.9).toFixed(2)), // 90%
        ReturnPrice = 0;
    var Comission = 0;

    var PlayerPlus = ComissionPrice;
    if(MyRef)
    {
        var CountRefs = await db.Users.findAll({
            where : {
                ref_id : MyRef.id
            }
        });
        CountRefs = CountRefs.length;

        $percent = 0.5;
        if(CountRefs > 500) $percent = 3;
        if(CountRefs >= 201 && CountRefs < 500) $percent = 2.5;
        if(CountRefs >= 101 && CountRefs <= 200) $percent = 2;
        if(CountRefs >= 21 && CountRefs <= 100) $percent = 1.5;
        if(CountRefs >= 10 && CountRefs <= 20) $percent = 1;

        var RefPlus = parseFloat((ComissionPrice*($percent/100)).toFixed(2));
        // PlayerPlus = parseFloat((ComissionPrice-(ComissionPrice*($percent/100))).toFixed(2));
        Comission = parseFloat(((game.price-ComissionPrice)-RefPlus).toFixed(2));

        if(RefPlus > 0)
        {
            MyRef.balance += RefPlus;
            MyRef.balance = parseFloat(MyRef.balance.toFixed(2));
            // проверка на правильность баланса
            if(!isNaN(MyRef.balance) && MyRef.balance >= 0) 
            {
                MyRef = await MyRef.save();

                await db.RefRewards.create({
                    user_id : MyRef.id,
                    value : RefPlus
                });
    
                ws.send({
                    action : 'message',
                    to : MyRef.id,
                    msg : 'Вы заработали ' + this.numberFormat(RefPlus) + ' коинов с победы игрока "' + user.username + '"',
                    type : 'info'
                });

                setTimeout(() => {
                    redis.publish('message', JSON.stringify({
                        to : MyRef.id,
                        msg : 'Вы заработали ' + this.numberFormat(RefPlus) + ' коинов с победы игрока "' + user.username + '"',
                        type : 'info'
                    }));
    
                    this.updateBalance(MyRef.id);
                }, 1);
            }
        }
    } else {
        Comission = parseFloat(game.price-ComissionPrice).toFixed(2);
    }

    user.balance += PlayerPlus;
    if(user.rate_date == '' || user.rate_date != DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
    {
        user.rate_date = DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')
        user.rate = 0;
    }
    user.rate += PlayerPlus;
    user.rate = parseFloat(user.rate.toFixed(2));
    user.balance = parseFloat(user.balance.toFixed(2));

    // проверка на правильность баланса
    if(!isNaN(user.balance) && user.balance >= 0) 
    {
        user = await user.save();
        ws.send({
            action : 'message',
            to : user.id,
            msg : 'Победа! | Выигрыш - ' + this.numberFormat(PlayerPlus),
            type : 'success'
        });
        setTimeout(() => {
            redis.publish('message', JSON.stringify({
                to : user.id,
                msg : 'Поздравляем, вы выигрыли! Ваш выигрыш - ' + this.numberFormat(PlayerPlus),
                type : 'success'
            }));
    
            this.updateBalance(user.id);
        }, 1);
    }

    await db.pLog(Comission, 'Комиссия из игры #' + game.id + ' комната ' + room.name, true, this.getDate());

    game.comission = Comission;
    await game.save();

    return true;
}

exports.createGame = async function(roomID) {
    var room = await db.Rooms.find({where:{'id' : roomID}});
    if(!room) return this.log('Не удалось найти комнату #' + roomID);

    var lastGame = await this.lastGame(roomID);
    if(lastGame && lastGame.status < 3)
    {
        this.warn('Последняя игра не закончилась! Изменили статус на 3.');
        lastGame.status = 3;
        lastGame.save();
        this.giveRevards(lastGame);
    }

    var game = await db.Games.create({
        room : roomID,
        secret : db.createSecret()
    });

    game = await this.lastGame(roomID);

    for(var i in this.timers[roomID].timerInterval) clearInterval(this.timers[roomID].timerInterval[i]);

    if(game)
    {
        this.timers[roomID] = {
            timer : true,
            timerInterval : [],
            time : 0,
            slider : false
        }
        var cfg = await db.cfg();
        ws.send({
            action : 'newGame',
            id : game.id,
            secret : game.secret,
            room : roomID,
            global : await this.globalInfo(),
            winner : await this.getLastWinner(roomID),
            timer : this.getTimer(room.timer),
            title : cfg.title + ' ' + (await this.getTitle(roomID)),
            content : await this.getRoomsContent()
        });
        redis.publish('newGame', JSON.stringify({
            id : game.id,
            secret : game.secret,
            room : roomID,
            global : await this.globalInfo(),
            winner : await this.getLastWinner(roomID),
            timer : this.getTimer(room.timer),
            title : cfg.title + ' ' + (await this.getTitle(roomID)),
            content : await this.getRoomsContent()
        }));
        return this.log('Новая игра успешно создана!');
    }
    return this.log('Ошибка при создании новой игры!');
}

exports.getTimer = function(time) {
    min = Math.floor(time/60);
    sec = time-(min*60);
    min = (min < 10) ? '0' + min : min;
    sec = (sec < 10) ? '0' + sec : sec;
    return {
        sec : sec,
        min : min
    }
}

exports.lastGame = async function(room) {
    return new Promise((res, rej) => {
        db.Games.find({
            where : {
                room : room
            },
            order : [['id', 'DESC']]
        }).then(async(game) => {
            if(game) return res(game);
            this.log('Не удалось найти последнюю игру в комнате #' + room);
            return res(false);
        });
    });
}

exports.createRoom = async function(mib, mab, name, timer) {
    var room = await db.Rooms.create({
        timer : timer,
        min_bet : mib,
        max_bet : mab,
        name : name
    });
    if(room) return this.log('Новая комната успешно создана!');
    return this.log('Ошибка при создании новой комнаты!');
}

exports.getBets = function(roomID) {
    return new Promise(async(res, rej) => {
        // get game
        var game = await this.lastGame(roomID);
        if(!game) return res([]);
        // get users colors
        var ColorsList = [];
        var Colors = 1;
        var users = await db.Bets.findAll({
            attributes : ['user', 'id'],
            where : {
                game : game.id,
                room : roomID
            },
            group : ['user', 'id'],
            order : [['id', 'ASC']]
        });
        for(var i in users) 
        {
            var IssetUser = false;
            for(var u in ColorsList) if(ColorsList[u].user == users[i].user) IssetUser = true;
            if(!IssetUser)
            {
                ColorsList.push({
                    user : users[i].user,
                    color : Colors
                });
                Colors++;
            }
        }
        // get bets
        var bets = await db.Bets.findAll({
            where : {room : roomID, game : game.id},
            order : [['id', 'ASC']]
        });
        
        var from = 0;
        for(var i in bets)
        {
            bets[i].color = 20;
            for(var u in ColorsList) if(ColorsList[u].user == bets[i].user) bets[i].color = ColorsList[u].color;
            bets[i].from = from+1;
            bets[i].to = bets[i].from+bets[i].price-1;

            from = bets[i].to;
        }

        bets.sort((a,b) => {
            if(a.id < b.id) return 1;
            if(b.id < a.id) return -1;
            return 0;
        });

        // get users list
        var users = [], gamePrice = 0; // game.price
        for(var i =0; i < bets.length; i++)
        {
            var found = false;
            for(var u = 0; u < users.length; u++) if(users[u] != null && users[u].id == bets[i].user) found = true;
            if(!found) users[bets[i].user] = await db.Users.findById(bets[i].user);
            gamePrice += bets[i].price;
        }

        var chances = [], list = [];
        for(var i=0; i<bets.length; i++) 
        {
            var found = false;
            for(var u=0; u<chances.length; u++) if(chances[u].user.id == bets[i].user) {
                chances[u].chance += bets[i].price
                found = true;
            }
            if(!found) chances.push({
                user : {
                    id : bets[i].user,
                    username : users[bets[i].user].username,
                    avatar : users[bets[i].user].avatar,
                    vk : users[bets[i].user].vk_id
                },
                chance : bets[i].price,
                color : bets[i].color,
                bet : await db.Bets.sum('price', {
                    where : {
                        room : roomID,
                        game : game.id,
                        user : bets[i].user
                    }
                })
            });

            list.push({
                user : {
                    id : bets[i].user,
                    username : users[bets[i].user].username,
                    avatar : users[bets[i].user].avatar
                },
                price : this.numberFormat(bets[i].price),
                from : bets[i].from,
                to : bets[i].to,
                color : bets[i].color
            });
        }

        for(var i=0; i<chances.length; i++) 
        {
            var chance = (chances[i].chance/gamePrice)*100
            chances[i].chance = (chance == 100) ? 100 : chance.toFixed(2);
            chances[i].bet = this.numberFormat(chances[i].bet);
        }

        chances.sort((a,b) => {
            if(b.chance > a.chance) return 1;
            if(b.chance < a.chance) return -1;
            return 0;
        });

        return res({
            bets : list,
            chances : chances,
            price : game.price
        });
    });
}

exports.getTopWinners = async() => {
    var list = await db.TopRewards.findAll({
        limit : 10,
        order : [['id', 'desc']]
    });
    
    for(var i in list) list[i].value = this.numberFormat(list[i].value);

    return list;
}

exports.getDate = () => {
    months = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря'];
    now = new Date().getTime();
    date = DateFormat(now, 'dd / в HH:MM').replace('/', months[parseInt(DateFormat(now, 'mm'))-1]);
    return date;
}

exports.adminRevards = async() => {
    let cfg = await db.cfg();
    let lastTopReward = await db.TopRewards.find({
        where : {
            date : DateFormat((new Date() - (24*60*60*1000)), 'yyyy-mm-dd')
        }
    });
    if(cfg.lastRevard == DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
    {
        console.log('[admin] сегодня уже выдавали приз администраторам!');
        return setTimeout(this.adminRevards, (5*60*1000));
    }

    if(!lastTopReward) 
    {
        console.log('[admin] ждем, пока найдется топ 1 за день');
        return setTimeout(this.adminRevards, (5*60*1000));
    }


    let w = await db.Withdraw.sum('amount', {
        where : {
            status : 0
        }
    }) || 0;

    let u = await db.Users.sum('balance') || 0;
    let fk = parseFloat(cfg.fk_balance);
    let g = await db.Games.sum('price', {
        where : {
            status : {
                [db.Sequelize.Op.lt] : 3
            }
        }
    }) || 0;
    g *= 0.9;

    let promos = await db.Promo.findAll({
        where : {
            status : 0
        }
    });
    let sum = 0;
    for(var i in promos) sum += promos[i].amount*(promos[i].count-promos[i].activated.length);

    let result = parseFloat(((parseFloat(cfg.kassa_balance)+parseFloat(cfg.fk_balance))-(u+w+g+sum)).toFixed(2));

    await db.Profit.create({
        value : result
    });

    // if(result <= 0) return this.log('Прибыль сайта - ' + result);
    
    let admins = await db.Users.findAll({
        where : {
            vk_id : {
                [db.Sequelize.Op.or] : [397542188]
            }
        }
    });

    result = parseFloat((result/admins.length).toFixed(2));
    if(isNaN(result))
    {
        console.log(admins.length);
        console.log(result);
        return setTimeout(this.adminRevards, (5*60*1000));
    }

    for(var i in admins) 
    {
        admins[i].balance = parseFloat((admins[i].balance+result).toFixed(2));
        await admins[i].save();
        ws.send({
            action : 'message',
            to : admins[i].id,
            msg : '[SERVER] Сударь, ваша з/п: ' + result + 'рублей!',
            type : 'info'
        });
        redis.publish('message', JSON.stringify({
            to : admins[i].id,
            msg : '[SERVER] Сударь, ваша з/п: ' + result + 'рублей!',
            type : 'info'
        }));
    }

    cfg.lastRevard = DateFormat(new Date(), 'yyyy-mm-dd 00:00:00');
    await cfg.save();

    this.log('Выдали ' + admins.length + ' администраторам по ' + result + 'руб.');

    return setTimeout(this.adminRevards, (5*60*1000));
}

exports.topRewards = async() => {
    lastTopReward = await db.TopRewards.find({
        where : {
            date : DateFormat((new Date() - (24*60*60*1000)), 'yyyy-mm-dd')
        }
    });

    if(!lastTopReward)
    {
        var top = await this.getTop((new Date() - (24*60*60*1000)));
        if(top.length == 0 || top.length < 1) return; // недостаточно игроков для выдачи
        winner = await db.Users.find({
            where : {
                vk_id : top[0].vk
            }
        });
        
        var cfg = await db.cfg();

        if(!winner) return;
        
        winner.balance = parseFloat((winner.balance+cfg.top_revards).toFixed(2));
        // проверка на правильность баланса
        if(!isNaN(winner.balance) && winner.balance >= 0)
        {
            await winner.save(); // save user

            await db.pLog(cfg.top_revards, 'Выдали приз игроку ' + winner.username, false, this.getDate());
    
            await db.TopRewards.create({
                date : DateFormat((new Date() - (24*60*60*1000)), 'yyyy-mm-dd'),
                value : cfg.top_revards,
                username : winner.username,
                avatar : winner.avatar,
                vk_id : winner.vk_id.toString()
            });

            this.log('[TOP] Победил ' + winner.username + ' и выиграл сумму в размере ' + cfg.top_revards);
        } else {
            this.log('Ошибка при выдаче приза игроку ' + winner.username + ' : неправильный баланс!');
        }
    }
}

exports.getTop = (time) => {
    return new Promise(async(res, rej) => {
        let users = await db.Users.findAll({
            where: {
                rate: {
                    [db.Sequelize.Op.gt]: 0
                }
            },
            order: [['rate', 'desc']],
            limit: 10
        });

        let place = 1, list = [];
        for(let i in users)
        {
            list.push({
                place : place,
                username : users[i].username,
                avatar : users[i].avatar,
                all : this.numberFormat(users[i].rate),
                wins : (await db.Games.findAll({
                    where : {
                        winner_id : users[i].id,
                        updatedAt : {
                            [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')).toISOString()
                        }
                    }
                })).length || 0,
                vk : users[i].vk_id
            });
            place++;
        }

        return res(list);
        // let Top30Jackpot = await db.Games.findAll({
        //     attributes : ['winner_id', [db.Sequelize.fn('sum', db.Sequelize.col('comissionPrice')), 'price']],
        //     where : {
        //         status : 3,
        //         updatedAt : {
        //             [db.Sequelize.Op.gte] : new Date(DateFormat(time, 'yyyy-mm-dd 00:00:00')).toISOString()
        //         }
        //     },
        //     group : ['winner_id']
        // });

        // let Top30Fishing = await db.Fishing.findAll({
        //     attributes: ['user_id', [db.Sequelize.fn('sum', db.Sequelize.col('final')), 'price']],
        //     where: {
        //         status: 1,
        //         updatedAt : {
        //             [db.Sequelize.Op.gte] : new Date(DateFormat(time, 'yyyy-mm-dd 00:00:00')).toISOString()
        //         }
        //     },
        //     group: ['user_id']
        // });

        // Top30Jackpot = this.sort(Top30Fishing, 'price', 'desc');
        // Top30Fishing = this.sort(Top30Fishing, 'price', 'desc');

        // let users = [];
        // for(let i in Top30Jackpot)
        // {
        //     let found = false;
        //     for(let u in users) if(users[u].user_id == Top30Jackpot[i].winner_id) {
        //         found = true;
        //         users[u].price += Top30Jackpot[i].price;
        //     }
        //     if(!found) users.push({
        //         user_id: Top30Jackpot[i].winner_id,
        //         price: Top30Jackpot[i].price
        //     });
        // }

        // for(let i in Top30Fishing)
        // {
        //     let found = false;
        //     for(let u in users) if(users[u].user_id == Top30Fishing[i].user_id) {
        //         found = true;
        //         users[u].price += Top30Fishing[i].price;
        //     }
        //     if(!found) users.push({
        //         user_id: Top30Fishing[i].user_id,
        //         price: Top30Fishing[i].price
        //     });
        // }

        // users = this.sort(users, 'price', 'desc');

        // UsersList = [];
        // let place = 0;
        // for(var i = 0; i < 10; i++) if(typeof users[i] != 'undefined') {
        //     user = await db.Users.findById(users[i].user_id);
        //     if(user && users[i].price > 0)
        //     {
        //         wins = await db.Games.findAll({
        //             where : {
        //                 winner_id : user.id,
        //                 updatedAt : {
        //                     [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')).toISOString()
        //                 }
        //             }
        //         });
        //         UsersList.push({
        //             place : (place+1),
        //             username : user.username,
        //             avatar : user.avatar,
        //             all : this.numberFormat(users[i].price),
        //             wins : this.numberFormat(wins.length),
        //             vk : user.vk_id
        //         });
        //         place++;
        //     }
        // }

        return res(UsersList);

    });
    return new Promise(async(res, rej) => {
        if(!time) time = new Date().getTime();
        users = await db.Games.findAll({
            attributes : ['winner_id', [db.Sequelize.fn('sum', db.Sequelize.col('comissionPrice')), 'price']],
            where : {
                status : 3,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(time, 'yyyy-mm-dd 00:00:00')).toISOString()
                }
            },
            group : ['winner_id']
        });

        for(var i = 0; i < users.length; i++) users[i].price = parseFloat(users[i].price);

        // users.sort((a,b) => {
        //     if(b.price < a.price) return 1;
        //     if(b.price > a.price) return -1;
        //     return 0;
        // });

        users = this.sort(users, 'price', 'desc');

        UsersList = [];
        for(var i = 0; i < 10; i++) if(typeof users[i] != 'undefined') {
            user = await db.Users.findById(users[i].winner_id);
            if(user)
            {
                wins = await db.Games.findAll({
                    where : {
                        winner_id : user.id,
                        updatedAt : {
                            [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')).toISOString()
                        }
                    }
                });
                UsersList.push({
                    place : (i+1),
                    username : user.username,
                    avatar : user.avatar,
                    all : this.numberFormat(users[i].price),
                    wins : this.numberFormat(wins.length),
                    vk : user.vk_id
                });
            }
        }

        return res(UsersList);
    });
}

exports.startTimer = async function(roomID, time, type) {
    if(!this.timers[roomID].timer) return this.warn('Таймер в комнате #'+roomID+' уже запущен!');
    this.log('Таймер в комнате #' + roomID + ' запущен!');
    this.timers[roomID].timer = false;
    this.timers[roomID].time = time;
    this.timers[roomID].timerInterval.push(setInterval(() => {
        this.timers[roomID].time--;
        ws.send({
            action : 'timer',
            room : roomID,
            timer : this.getTimer(this.timers[roomID].time)
        });
        redis.publish('timer', JSON.stringify({
            room : roomID,
            timer : this.getTimer(this.timers[roomID].time)
        }));
        this.log('Таймер : ' + this.timers[roomID].time + ' сек. ' + roomID);
        if(this.timers[roomID].time <= 0)
        {
            for(var i in this.timers[roomID].timerInterval) clearInterval(this.timers[roomID].timerInterval[i]);
            if(type) this.getSlider(roomID);
            this.timers[roomID].timer = true;
            return;
        }
    }, 1000));
}

exports.addOnline = ip => {
    return new Promise(async(res, rej) => {
        today = (new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00')).getTime()).toString();

        check = await db.Online.find({
            where : {
                ip : ip,
                time : today
            }
        });
        if(check) return res(false);

        await db.Online.create({
            ip : ip,
            time : today
        });

        return res(true);
    });
}

exports.postSlider = function(roomID) {
    if(typeof this.timers[roomID] == 'undefined') return {};
    var time = (this.timers[roomID].time-3 > 0) ? this.timers[roomID].time-3 : 0;
    this.timers[roomID].slider.start = (1-(time/7))*this.timers[roomID].slider.rotate;
    this.timers[roomID].slider.time = time*1000;
    return this.timers[roomID].slider;
}

exports.getSlider = async function(roomID) {
    this.log('Поиск победителя в комнате #' + roomID);
    var game = await this.lastGame(roomID);
    if(!game) return;

    game.status = 2;
    game = await game.save();

    // IMPORTANT, NOT Ctrl+C/V
    var bets = await this.getBets(roomID);

    let fromRand = parseInt(bets.bets[bets.bets.length-1].from),
        toRand = parseInt(bets.bets[0].to);

    if(fromRand == toRand) toRand++;

    randomResult = await RandomOrg.generateInteger(fromRand, toRand, game.secret);
    if(!randomResult)
    {
        this.warn('Ошибка при получении случайного чилса от random.org!');
        this.getSlider(roomID);
        return;
    }
    game.randomOrg = randomResult;
    console.log(game.randomOrg);
    game.random = randomResult.result.random.data[0];

    // ищем победную ставку в диапазоне билетов
    var winnerBet = false;
    for(var i in bets.bets) if(parseInt(bets.bets[i].from) <= game.random && parseInt(bets.bets[i].to) >= game.random) winnerBet = bets.bets[i];
    if(!winnerBet) 
    {
        let checked = false;
        for(var i in bets.bets) if(parseInt(bets.bets[i].from) <= game.random && (parseInt(bets.bets[i].to)+1) >= game.random) checked = bets.bets[i];
        if(!checked) return this.warn('Не удалось найти победителя!'); else winnerBet = checked;
    }
    // ищем победителя и сумму его ставок
    var user = await db.Users.findById(winnerBet.user.id);
    var winnerSum = await db.Bets.sum('price', {
        where : {
            game : game.id,
            room : roomID,
            user : user.id
        }
    });

    // сохраняем победителя
    game.winner_id = user.id;
    game.winner = {
        username : user.username,
        avatar : user.avatar,
        chance : ((winnerSum/game.price)*100).toFixed(2),
        chances : bets.chances,
        mate_id : null
    }

    // тут мы возвращаем ставку тимейту

    var config = await db.cfg();
    config.profit += parseFloat((game.price*0.1).toFixed(2));
    await config.save();

    game.comissionPrice = parseFloat((game.price*0.9).toFixed(2));
    game = await game.save(); 

    var list = [], to = 0, need = false;
    bets.chances.forEach(u => {
        if(u.user.id == user.id) need = {
            start : to+5,
            end : (to+parseFloat(u.chance)*3.6)-5,
            random : this.random(to+5, ((to+parseFloat(u.chance)*3.6)-5))
        }

        to += parseFloat(u.chance)*3.6;
    });

    var room = await db.Rooms.findById(roomID),
        cfg = await db.cfg();

    var dataSlider = {
        room : room.id,
        rotate : need.random+3600,
        time : 12000,
        winner : {
            avatar : user.avatar,
            username : user.username,
            bet : await this.getMyInfo(roomID, user.id),
            id : user.id
        },
        ticket : game.random,
        price : game.price,
        secret : game.secret,
        title : cfg.title + ' ' + await this.getTitle(room.id),
        timer : this.getTimer(room.ng_timer)
    };

    this.timers[roomID].slider = dataSlider;
    ws.send({
        action : 'timer',
        room : room.id,
        rotate : need.random+3600,
        time : 12000,
        winner : {
            avatar : user.avatar,
            username : user.username,
            bet : await this.getMyInfo(roomID, user.id),
            id : user.id
        },
        ticket : game.random,
        price : game.price,
        secret : game.secret,
        title : cfg.title + ' ' + await this.getTitle(room.id),
        timer : this.getTimer(room.ng_timer)
    });
    redis.publish('slider', JSON.stringify(dataSlider));

    for(var i in this.timers[roomID].timerInterval) clearInterval(this.timers[roomID].timerInterval[i]);
    this.timers[roomID].timer = true;
    this.startTimer(roomID, room.ng_timer, false);

    

    setTimeout(() => {
        this.createGame(roomID);
    }, room.ng_timer*1000);
}

exports.getTitle = (roomID) => {
    return new Promise(async(res, rej) => {
        var room = await db.Rooms.findById(roomID);
        var game = await this.lastGame(room.id);
        var cfg = await db.cfg();
        if(game.status > 1) return res('– ' + room.name +  ' | 🔄Крутим..')
        if(game.status == 0 && game.price == 0) return res('– ' + room.name + ' | ⌛Ожидание..')
        return res('– ' + room.name + ' | ' + this.numberFormat(game.price) + '💎')
    });
}

exports.getUserInfo = async ids => {
    BetsList = [];
    ids.forEach(async id => {
        game = await db.Games.findById(id);
        if(game)
        {
            BetsList.push(game.winner_id);
        }
    });
}

exports.getLastWinner = function(roomID) {
    return new Promise(async(res,rej) => {
        var game = await db.Games.find({
            where : {
                room : roomID,
                status : 3
            },
            order : [['id', 'DESC']]
        });

        if(!game) return res(false);

        var user = await db.Users.findById(game.winner_id);
        if(!user) return res(false);

        var bets = await db.Bets.findAll({
            where : {
                game : game.id,
                room : roomID,
                user : user.id
            }
        });

        var price = 0;
        for(var i in bets) price += bets[i].price;

        return res({
            avatar : user.avatar,
            username : user.username,
            vk : user.vk_id,
            chance : ((price/game.price)*100).toFixed(2),
            price : this.numberFormat(game.comissionPrice)
        });
    });
}

exports.globalInfo = function() {
    return new Promise(async(res, rej) => {
        var users = await db.Bets.findAll({
            attributes : ['user', [db.Sequelize.fn('count', db.Sequelize.col('user')), 'user']],
            group : ['user']
        });

        var games = await db.Games.findOne({
            order: [['id', 'desc']]
        });

        let fishing = await db.Fishing.findOne({
            order: [['id', 'desc']]
        });

        games = (games) ? games.id : 0;
        fishing = (fishing) ? fishing.id : 0;

        console.log(games, fishing);

        var biggest = await db.Games.find({
            where : {status:3},
            order : [['price', 'DESC']]
        });

        return res({
            players : this.numberFormat(users.length),
            games : this.numberFormat(games+fishing),
            biggest : (biggest) ? this.numberFormat(biggest.price) : 0,
            users : this.numberFormat(await db.Users.count('id') || 0)
        });
    });
}

exports.random = (n1, n2) => {
    return Math.floor(Math.random()*((n2+1)-n1))+n1;
}

exports.getToday = () => {
    var date = new Date().getFullYear()+'-'+new Date().getMonth()+'-'+new Date().getDay();
    new Date("2018-08-29 00:00:00").toISOString();
}

exports.createBet = async function(roomID, user, price) {
    return new Promise(async(res, rej) => {
        let transaction = await db.transaction();
        try {
            if(!this.timers[roomID].timer && this.timers[roomID].time <= 5) 
            {
                await transaction.rollback();
                return res({
                    success : false,
                    msg : 'Ставки в игру закрыты!'
                });
            }
            price = parseInt(price) || 0;
    
            user = await db.Users.findById(user);
            if(!user) 
            {
                await transaction.rollback();
                return res({
                    success : false,
                    msg : 'Не удалось найти вас в базе данных! Обратитесь в службу тех. поддержки.'
                });
            }
			
			userinit = await this.getBets(roomID);
			//Проверка на максимальное количество игроков в комнате
            if(userinit.chances.length >= 10 ) 
			{               
				await transaction.rollback();
                return res({
                    success : false,
                    msg : 'Максимальное количество игроков! Или принятых ставок!'
                });
				
			}
			
			if(isNaN(user.balance)) 
            {
                await transaction.rollback();
                return res.json({
                    success : false,
                    msg : 'Неверный баланс!'
                });
            }
    
            var room = await db.Rooms.find({where:{'id' : roomID}});
            if(!room) 
            {
                await transaction.rollback();
                return res({
                    'success' : false,
                    'msg' : 'Не удалось найти комнату #' + roomID
                });
            }
        
            var game = await this.lastGame(roomID);
            if(!game)
            {
                await transaction.rollback();
                this.warn('Отмена ставки!');
                return res({
                    'success' : false,
                    'msg' : 'Ваша ставка была отменена! Обратитесь в техническую поддержку по данному вопросу'
                });
            }
    
            var myBet = await db.Bets.find({
                where : {
                    room : roomID,
                    game : game.id,
                    user : user.id
                },
                order : [['id', 'DESC']]
            });
    
            // if(myBet && Math.floor((new Date().getTime()/1000)-(new Date(myBet.createdAt).getTime()/1000)) < 3) {
            //     await transaction.rollback();
            //     return res({
            //         success : false,
            //         msg : 'Мы можете делать ставки каждые 3 секунды!'
            //     });
            // }
        
            if(game.status > 1) {
                await transaction.rollback();
                return res({
                    'success' : false,
                    'msg' : 'Ставки в игру #' + game.id + ' закрыты!'
                });
            }
        
            if(price < room.min_bet) {
                await transaction.rollback();
                return res({
                    'success' : false,
                    'msg' : 'Минимальная сумма ставки в комнате «'+room.name+'» - ' + room.min_bet + ' монет!'
                });
            }
    
            var mySum = await db.Bets.sum('price', {
                where : {
                    user : user.id,
                    room : room.id,
                    game : game.id 
                }
            });
    
            if(isNaN(mySum)) mySum = 0;
        
            if(room.max_bet != 0 && (mySum+price) > room.max_bet) {
                await transaction.rollback();
                return res({
                    'success' : false,
                    'msg' : 'Максимальная сумма ставки в комнате «'+room.name+'» - ' + room.max_bet + ' монет!'
                });
            }
        
            if(price > user.balance) {
                await transaction.rollback();
                return res({
                    success : false,
                    msg : 'Недостаточно монет!'
                });
            }
    
    
            game.price += price;
            // game = await game.save();
            await db.Games.update({
                price : game.price,
                status : game.status
            }, {
                where : {
                    id : game.id
                },
                transaction : transaction
            });
        
            user.balance -= price;
            user.balance = parseFloat(user.balance.toFixed(2));
            // user = await user.save();
            await db.Users.update({
                balance : user.balance
            }, {
                where : {
                    id : user.id
                },
                transaction : transaction
            })
    
            await db.Bets.create({
                room : roomID,
                game : game.id,
                user : user.id,
                price : price
            }, {
                transaction : transaction
            });
            
            await transaction.commit();

            setTimeout(async() => {
                let bets = await this.getBets(roomID);
                if(bets.chances.length >= room.min_users && game.status < 1 ) {
                    game.status = 1;
                    await db.Games.update({
                        price : game.price,
                        status : game.status
                    }, {
                        where : {
                            id : game.id
                        }
                    });
                    if(this.timers[roomID].timer) this.startTimer(roomID, room.timer, true);
                }
                var cfg = await db.cfg();
                ws.send({
                    action : 'bets',
                    room : roomID,
                    bets : bets,
                    price : game.price,
                    title : cfg.title + ' ' +await this.getTitle(roomID),
                    content : await this.getRoomsContent()
                });
                redis.publish('bets', JSON.stringify({
                    room : roomID,
                    bets : bets,
                    price : game.price,
                    title : cfg.title + ' ' +await this.getTitle(roomID),
                    content : await this.getRoomsContent()
                }));
                this.updateBalance(user.id);
            },2);

            return res({
                success : true,
                msg : 'Ваша ставка одобрена!',
                data : await this.getMyInfo(roomID, user.id)
            });
        } catch(error) {
            console.log(error);
            await transaction.rollback();

            return res({
                success : false,
                msg : 'Ошибка при отправке данных на сервер!'
            });
        }
    }); 
}

exports.init = async function() {
    var rooms = await db.Rooms.findAll();
    rooms.forEach(async(room) => {
        await this.initRoom(room.id);
    });
    setInterval(this.topRewards, 15000);
    this.adminRevards();
    // this.adminRevards();
}

exports.initRoom = id => {
    return new Promise(async(res, rej) => {
        var room = await db.Rooms.findById(id);
        if(!room) return this.warn('Не удалось найти комнату #' + id);

        this.timers[id] = {
            timer : true,
            timerInterval : [],
            time : 0,
            slider : 0
        }

        var game = await this.lastGame(id);

        if(game)
        {
            this.log('Комната "'+room.name+'" игра #' + game.id);
            if(game.status == 1) this.startTimer(room.id, room.timer, true);
            if(game.status == 2) this.getSlider(room.id);
            if(game.status == 3) this.createGame(room.id);
            return res(true);
        } else {
            this.createGame(room.id);
            return res(false);
        }
    });
}

exports.getMyInfo = function(roomID, user) {
    return new Promise(async(res, rej) => {
        var game = await this.lastGame(roomID);
        if(!game) return res({
            chance : 0,
            bet : 0
        });
    
        var bet = await db.Bets.sum('price', {
            where : {
                room : roomID,
                game : game.id,
                user : user
            }
        });
    
        var chance = (bet/game.price)*100 || 0;
    
        return res({
            chance : (chance == 100) ? 100 : chance.toFixed(2),
            bet : (isNaN(bet)) ? 0 : this.numberFormat(bet)
        });
    });
}

exports.getColor = async function(roomID, gameID) {
    var bet = await db.Bets.find({
        where : {
            room : roomID,
            game : gameID
        },
        order : [['color', 'DESC']]
    });

    return (bet) ? (parseInt(bet.color)+1) : 1;
}

exports.log = function(log) {
    console.log('[Roulette] ' + log);
}

exports.warn = function(warn) {
    console.log('[WARNING Roulette] ' + warn);
}

exports.getMyMates = (userID, roomID) => {
    return new Promise(async(res, rej) => {
        var game = await this.lastGame(roomID);

        if((!this.timers[roomID].timer && this.timers[roomID].time <= 5) || game.status > 1) return res([]);

        var mates = await db.Mates.findAll({
            where : {
                room : roomID,
                game : game.id,
                user_to : userID,
                status : 0
            }
        });
        list = [];
        for(var i = 0; i < mates.length; i++)
        {
            var userFrom = await db.Users.findById(mates[i].user_from);
            if(userFrom) list.push({
                query : mates[i].id,
                sender : {
                    username : userFrom.username,
                    avatar : userFrom.avatar,
                    vk : userFrom.vk_id
                }
            });
            userFrom = false;
        }

        return res(list);
    });
}

exports.disableRoom = id => {
    // Отключаем таймер
    clearInterval(this.timers[id].timerInterval);

    // Удаляем init
    delete this.timers[id];
}

exports.updateBalance = async function(user) {
    user = await db.Users.findById(user);
    if(!user) return false;
    ws.send({
        action : 'balance',
        user_id : user.id,
        balance : this.numberFormat(user.balance),
        rate : this.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })),
    });
    redis.publish('updateBalance', JSON.stringify({
        user_id : user.id,
        balance : this.numberFormat(user.balance),
        rate : this.numberFormat((await db.Games.sum('comissionPrice', {
            where : {
                winner_id : user.id,
                updatedAt : {
                    [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
                }
            }
        }) || 0)+await db.Fishing.sum('result', {
          where: {
            user_id: user.id,
            updatedAt : {
              [db.Sequelize.Op.gte] : new Date(DateFormat(new Date(), 'yyyy-mm-dd 00:00:00'))
          }
          }
        })),
    }));
    return true;
}

exports.sort = (array, key, sort) => {
    var max = 0, min = 0 , returnValue = [];

    // set id
    var maxItem = undefined;
    var maxItemID = undefined;
    for(var i = 0; i < array.length; i++) 
    {
        if(typeof maxItem == 'undefined') maxItem = array[i];

        var aValue = (!key) ? array[i] : array[i][key];
        var mValue = (!key) ? maxItem : maxItem[key];
        let result = (sort == 'desc') ? (aValue < mValue) : (aValue > mValue);
        if(result) 
        {
            maxItem = array[i];
            maxItemID = i;
        }
    }

    returnValue.push(maxItem);

    for(var i = 0; i < array.length; i++)
    {
        var list = [];
            placed = false;
        for(var u = 0; u < returnValue.length; u++)
        {
            var aValue = (!key) ? array[i] : array[i][key];
            var rValue = (!key) ? returnValue[u] : returnValue[u][key];
            let result = (sort == 'desc') ? (aValue > rValue) : (aValue < rValue);
            if(result && !placed) 
            {
                list.push(array[i]);
                placed = true;
            }
            list.push(returnValue[u]);
        }
        returnValue = list;
    }

    

    return returnValue;
}