const db = require('../app/Database');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const DateFormat = require('dateformat');
const Roulette = require('../app/Roulette');
const ws = require('../app/WebSockets');

exports.sendNotify = async function(req, res) {
    if(req.body.to == req.user.id) return res.json({
        success : false,
        msg : 'Вы не можете играть в паре с собой!'
    });
    
    var room = await db.Rooms.findById(parseInt(req.body.room));
    if(!room) return res.json({
        success : false,
        msg : 'Не удалось найти комнату, в которой вы находитесь!'
    });

    var bets = await Roulette.getBets(room.id);
    if(bets.chances.length < room.team_at) return res.json({
        success : false,
        msg : 'Командный режим в комнате ' + room.name + ' доступен от ' + room.team_at + ' игроков!'
    });

    var game = await Roulette.lastGame(room.id);
    if(!game) return res.json({
        success : false,
        msg : 'Не удалось найти последнюю игру в комнате «'+room.name+'»'
    });

    if((!Roulette.timers[room.id].timer && Roulette.timers[room.id].time <= 5) || game.status > 1) return res.json({
        success : false,
        msg : 'Вы уже не можете отправлять предложения!'
    });
 
    var bet = await db.Bets.find({
        where : {
            game : game.id,
            room : room.id,
            user : req.user.id
        }
    });

    if(!bet) return res.json({
        success : false,
        msg : 'Вы не сделали ставку!'
    });

    var MateBet = await db.Bets.find({
        where : {
            game : game.id,
            room : room.id,
            user : parseInt(req.body.to)
        }
    });

    if(!MateBet) return res.json({
        success : false,
        msg : 'Этот игрок не сделал ставку!'
    });

    var MyMate = await db.Mates.find({
        where : {
            [db.Sequelize.Op.or] : [
                {
                    user_from : req.user.id
                },
                {
                    user_to : req.user.id
                }
            ],
            game : game.id,
            status : 1
        }
    });

    if(MyMate) return res.json({
        success : false,
        msg : 'Вы уже играете в паре!'
    });

    var toMate = await db.Mates.find({
        where : {
            [db.Sequelize.Op.or] : [
                {
                    user_from : parseInt(req.body.to)
                },
                {
                    user_to : parseInt(req.body.to)
                }
            ],
            game : game.id,
            status : 1
        }
    });

    if(toMate) 
    {
        if(toMate.user_from == req.user.id || toMate.user_to == req.user.id) return res.json({
            success : true,
            msg : 'Вы уже играете в паре с этим игроком!'
        });

        return res.json({
            success : false,
            msg : 'Этот пользователь уже играет в паре!'
        });
    }

    var AlreadySend = await db.Mates.find({
        where : {
            user_from : req.user.id,
            user_to : parseInt(req.body.to),
            game : game.id
        }
    });

    if(AlreadySend) return res.json({
        success : false,
        msg : 'Вы уже отправляли запрос этому игроку!'
    });

    var mateQuery = await db.Mates.create({
        user_from : req.user.id,
        user_to : req.body.to,
        game : game.id,
        room : room.id
    });

    // Get created object
    mateQuery = mateQuery.get({plain:true});

    // redis отправка
    ws.send({
        action : 'mateNotify',
        query : mateQuery.id,
        to : parseInt(req.body.to),
        room : game.room,
        sender : {
            username : req.user.username,
            avatar : req.user.avatar,
            vk : req.user.vk_id
        }
    });
    redis.publish('mateNotify', JSON.stringify({
        query : mateQuery.id,
        to : parseInt(req.body.to),
        room : game.room,
        sender : {
            username : req.user.username,
            avatar : req.user.avatar,
            vk : req.user.vk_id
        }
    }));

    return res.json({
        success : true,
        msg : 'Предложение отправлено!'
    });
}

exports.acceptNotify = async function(req, res) {
    var mate = await db.Mates.findById(parseInt(req.body.query));
    if(!mate) return res.json({
        success : false,
        msg : 'Не удалось найти предложение!'
    });

    let isMate = await db.Mates.find({
        where : {
            [db.Sequelize.Op.or] : [
                {
                    user_from : req.user.id
                },
                {
                    user_to : req.user.id
                }
            ],
            game : mate.game,
            status : 1
        }
    });

    if(isMate) return res.json({
        success : false,
        msg : 'Вы уже играете в паре!'
    });

    // check
    var fromMate = await db.Mates.find({
        where : {
            [db.Sequelize.Op.or] : [
                {
                    user_from : mate.user_from
                },
                {
                    user_to : mate.user_from
                }
            ],
            game : mate.game,
            status : 1
        }
    });

    if(fromMate) 
    {
        mate.status = 2;
        mate.save();
        return res.json({
            success : false,
            msg : 'Этот пользователь уже играет в паре!'
        });
    }

    if(mate.status != 0) 
    {
        mate.status = 2;
        mate.save();
        return res.json({
            success : false,
            msg : 'Срок предложение истек!'
        });
    }

    var game = await db.Games.findById(mate.game);
    if(!game) 
    {
        mate.status = 2;
        mate.save();
        return res.json({
            success : false,
            msg : 'Не удалось найти игру!'
        });
    }

    if((!Roulette.timers[room.id].timer && Roulette.timers[room.id].time <= 5) || game.status > 1) {
        mate.status = 2;
        mate.save();
        return res.json({
            success : false,
            msg : 'Время предложения истекло!'
        });
    }

    mate.status = parseInt(req.body.status);
    mate.save();
    ws.send({
        action : 'message',
        to : mate.user_from,
        msg : req.user.username + ((mate.status == 1) ? ' принял' : ' отклонил' + ' ваше предложение!'),
        type : (mate.status == 1) ? 'success' : 'error'
    });
    redis.publish('message', JSON.stringify({
        to : mate.user_from,
        msg : req.user.username + ((mate.status == 1) ? ' принял' : ' отклонил' + ' ваше предложение!'),
        type : (mate.status == 1) ? 'success' : 'error'
    }));

    return res.json({
        success : true,
        msg : 'Предложение ' + ((mate.status == 1) ? 'принято!' : 'отклонено!')
    });
}