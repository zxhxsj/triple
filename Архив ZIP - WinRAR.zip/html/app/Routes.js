exports.test = require('../routes/test');
exports.auth = require('../routes/auth');
exports.index = require('../routes/index');
exports.chat = require('../routes/chat');
exports.admin = require('../routes/admin');
exports.p4 = require('../routes/p4');
exports.fish = require('../routes/fish');