const Passport = require('passport');
const VkontakteStrategy = require('passport-vkontakte').Strategy;
const DB = require('./Database');

Passport.use(new VkontakteStrategy({
    clientID : 7015379,
    clientSecret : 'WrisYa1dVdThd6djCjEJ',
    callbackURL : 'http://m24.pw/login/callback'
}, (accessToken, refreshToken, params, profile, done) => {
    DB.Users.findOrCreate({
        where : {'vk_id' : profile.id},
        defaults : {
            vk_id : profile.id,
            username : profile.displayName,
            avatar : profile.photos[0].value,
            balance : 0,
            is_admin : 0,
            ref_id : null
        }
    }).spread(async(user, created) => {
        let dbUser = user.get();
        dbUser = await DB.Users.find({
                where : {
                    vk_id : profile.id
                }
            });
        
        if(dbUser)
        {
            dbUser.avatar = profile.photos[0].value;
            await dbUser.save();
        }

        return done(null, user.get());
    });
}));

Passport.serializeUser(function(user, done) {
    return done(null, user.id);
});

Passport.deserializeUser(async function(id, done) {
    DB.Users.findById(id).then((user) => {
        return done(null, user);
    });
});

module.exports = Passport;