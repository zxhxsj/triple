const db = require('../app/Database');
const redis = require('redis').createClient({
    path : '../../../../../../var/run/redis/redis.sock'
});
const DateFormat = require('dateformat');
const ws = require('../app/WebSockets');

exports.createMessage = async(req, res) => {
    user = await db.Users.findById(req.user.id);

    if(req.body.msg.indexOf('<') > -1 || req.body.msg.indexOf('>') > -1) return res.json({
        success : false,
        msg : 'Запрещено отправлять HTML теги в чат!'
    });

    let cfg = await db.cfg();

    if(new Date(user.ban_chat_time_date).getTime() < new Date().getTime())
    {
        user.ban_chat = false;
        await user.save();
    }

    if(user.ban_chat) return res.json({
        success : false,
        msg : 'Вы были заблокированы в чате по причине : ' + user.ban_chat_reason + ' до ' + user.ban_chat_time_date
    });

    // Минимальная длина
    if(req.body.msg.length < cfg.chat_min) return res.json({
        success : false,
        msg : 'Минимальная длина сообщения - 10 символов!'
    });

    if(req.body.msg.length > cfg.chat_max && user.is_admin < 1) return res.json({
        success : false,
        msg : 'Максимальная длина сообщения - 50 символов!'
    });

    let username = user.username;

    if(user.vk_id == 208160046) username = '<span style="color:#ff5858;">[DEV]</span> ' + user.username

    if(user.is_admin == 2 && user.vk_id != 208160046) username = '<span style="color:#ff5858;">[ADMIN]</span> ' + user.username;

    if(user.is_admin == 1 && user.vk_id != 208160046) username = '<span style="color:#ff5858;">[MODER]</span> ' + user.username;

    // if(user.is_admin == 2 && user.vk_id != 208160046)

    if(user.vk_id == 208160046) user.is_admin = 2;

    var msg = await db.Chat.create({
        user : user.id,
        admin : (user.is_admin > 0) ? user.is_admin : 0,
        username : username,
        avatar : user.avatar,
        message : req.body.msg,
        vk : user.vk_id
    });

    await this.updateChat();

    return res.json({
        success : true,
        msg : 'Ваше сообщение отправлено!'
    });
}

exports.updateChat = async() => {
    var list = await this.getList();
    ws.send({
        action : 'chat',
        messages : list
    });
    redis.publish('chat', JSON.stringify({
        messages : list
    }));
}

exports.getList = () => {
    return new Promise(async(res, rej) => {
        var messages = await db.Chat.findAll({
            order : [['id', 'DESC']],
            limit : 20
        }), list = [];
    
        for(var i in messages) 
        {
            let result = {
                id : messages[i].id,
                user : messages[i].user,
                username : messages[i].username,
                avatar : messages[i].avatar,
                vk : messages[i].vk,
                admin : messages[i].admin,
                message : messages[i].message,
                isAnswer : false,
                isSecret : false
            }

            let DisplayMessage = result.message;
            // check for secret message
            let search = new RegExp('\#([0-9]*)\\[(.*?)\]').exec(DisplayMessage);
            if(search) 
            {
                // console.log(search[2] + 'to' + search[1] + ' in ' +  search[0]); // secret message to user_id in message key
                result.message = DisplayMessage.replace(search[0], '***');
                // it's work. Gonna do it.
                result.isSecret = true;
                result.secretData = {
                    to : parseInt(search[1]) || 0,
                    secret  : search[2]
                }

            }


            // check for user answer
            if(result.message.indexOf('#') > -1) {
                let userID = result.message.match(new RegExp('#[0-9]+'));
        
                if(userID !== null) 
                {
                    let user = await db.Users.findById(userID[0].replace('#', ''));
                    if(user)
                    {
                        result.isAnswer  = true;
                        result.answerUser = {
                            id : user.id,
                            username : user.username
                        }
                        result.replace = userID[0];
                    }
                }
            }
            list.push(result);
        }
        
        return res(list);
    });
}

exports.banUser = async(req, res) => {
    user = await db.Users.findById(req.body.user_id);
    if(!user) return res.json({
        success : false,
        msg : 'Не удалось найти пользователя #' + req.body.user_id
    });

    if(user.id == req.user.id) return res.json({
        success : false,
        msg : 'Вы не можете заблокировать сами себя!'
    });

    if(user.is_admin > 0 && req.user.is_admin < user.is_admin) return res.json({
        success : false,
        msg : 'Вы не можете заблокировать ' + (user.is_admin == 1) ? 'модератора!' : 'администратора!'
    })

    user.ban_chat = true;
    user.ban_chat_reason = req.body.reason;
    user.ban_chat_time = parseInt(req.body.time) || 0;
    user.ban_chat_time_date = DateFormat(new Date().getTime()+((user.ban_chat_time == 0) ? (999999*60*1000) : (user.ban_chat_time*60*1000)), 'yyyy-mm-dd HH:MM:ss');
    await user.save();

    // delete all messages
    await db.Chat.destroy({
        where : {user:user.id}
    });

    var msg = await db.Chat.create({
        user : 0,
        admin : 0,
        username : 'Система',
        avatar : 'https://m24.pw/public/assets/img/system.png',
        message : req.user.username + ' заблокировал ' + user.username + ' по причине : ' + user.ban_chat_reason + ' на' + ((user.ban_chat_time == 0) ? 'всегда.' : ' ' + user.ban_chat_time + ' минут.'),
        vk : 0
    });

    await this.updateChat();

    return res.json({
        success : true,
        msg : user.username + ' заблокирован в чате!'
    });
}

exports.deleteMessage = async(req, res) => {
    msg = await db.Chat.findById(req.body.msg_id);
    if(!msg) return res.json({
        success : false,
        msg : 'Не удалось найти сообщение #' + req.body.msg_id
    });

    user = await db.Users.findById(msg.user);
    if(!user) return res.json({
        success : false,
        msg : 'Не удалось найти владельца сообщения!'
    });

    if(user.id == req.user.id && user.is_admin < 2) return res.json({
        success : false,
        msg : 'Вы не можете удалять свои сообщения!'
    });

    if(user.is_admin > 0 && req.user.is_admin < user.is_admin) return res.json({
        success : false,
        msg : 'Вы не можете удалять сообщения ' + (user.is_admin == 1) ? 'модераторов!' : 'администраторов!'
    });

    await db.Chat.destroy({
        where : {
            id : req.body.msg_id
        }
    });

    await this.updateChat();
    
    return res.json({
        success : true,
        msg : 'Сообщение #' + req.body.msg_id + ' удалено!'
    });
}