const fs = require('fs');
const server = require('../app/Https').createServer();
const WebSocket = require('ws');
const wss = new WebSocket.Server({ server });

exports.onlineIPS = []; // ip => connection
exports.onlineUsers = []; // object => object


var self = this;
wss.on('connection', function connection(ws, req) {
    let remoteAddres = (ws._socket.remoteAddress || req.connection.remoteAddress).replace('::ffff:', '');

    // // // // console.log(ws);

    self.connect(remoteAddres);

    ws.on('message', function incoming(res) {
        res = JSON.parse(res);
        if(res.action == 'register') self.register(remoteAddres, res.user);
        if(res.action == 'upd_online') self.updateOnline();
    });

    ws.on('close', () => {
        self.disconnect(remoteAddres);
    });
});

exports.send = (res) => {
    wss.clients.forEach(client => {
        client.send(JSON.stringify(res));
    });
}

exports.connect = (adress) => {
    let exist = false;
    for(var i in this.onlineIPS) 
        if(typeof this.onlineIPS[i] !== 'undefined' && this.onlineIPS[i].connection == adress)
        {
            this.onlineIPS[i].count += 1;
        }

    if(!exist) this.onlineIPS.push({
        connection : adress,
        count : 0
    });

    this.updateOnline();
}

exports.disconnect = (adress) => {
    for(var i in this.onlineIPS)
        if(typeof this.onlineIPS[i] !== 'undefined' && this.onlineIPS[i].connection == adress)
        {
            this.onlineIPS[i].count -= 1;
            if(this.onlineIPS[i].count <= 0) this.onlineIPS[i] = undefined;
        }

    this.updateOnline();
}

exports.register = (adress, user) => {
    for(var i in this.onlineIPS)
        if(typeof this.onlineIPS[i] !== 'undefined' && this.onlineIPS[i].connection == adress) this.onlineIPS[i].user = user;

    this.updateOnline();
}

exports.updateOnline = () => {
    let count = 0, users = [];
    for(var i in this.onlineIPS)
        if(typeof this.onlineIPS[i] != 'undefined') 
        {
            count++;
            if(typeof this.onlineIPS[i].user != 'undefined') users.push({
                id : this.onlineIPS[i].user.id,
                username : this.onlineIPS[i].user.username,
                avatar : this.onlineIPS[i].user.avatar,
                permission : this.onlineIPS[i].user.perm,
                connection : this.onlineIPS[i].connection,
                count : this.onlineIPS[i].count
            });
        }

    // // // console.log(this.onlineIPS);

    this.send({
        action : 'online',
        count : count,
        users : users
    });
}



server.listen(8080);